'use strict';
/**
 * قنوات IPC الخاصة بالطباعة (الصامتة وغير الصامتة) وحفظ الملفات والنسخ الاحتياطي/الاستعادة.
 */
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const { validateBackupFile, stamp } = require('./db.cjs');

const state = { restoring: false };

function registerSystemIpc({ getWindow, getStore, isTrusted }) {
  const guard = (e) => { if (!isTrusted(e)) throw new Error('untrusted'); };

  /* ------------------------------ الطباعة ------------------------------ */

  ipcMain.handle('print:list', async (e) => {
    guard(e);
    const printers = await e.sender.getPrintersAsync();
    return printers.map((p) => ({
      name: p.name,
      displayName: p.displayName || p.name,
      isDefault: !!p.isDefault,
      description: p.description || '',
    }));
  });

  // طباعة الصفحة الحالية (الإيصال الظاهر) — صامتة أو بنافذة النظام
  ipcMain.handle('print:page', (e, opts = {}) => {
    guard(e);
    return new Promise((resolve) => {
      const options = {
        silent: !!opts.silent,
        printBackground: true,
        copies: Math.max(1, Math.min(10, Number(opts.copies) || 1)),
        margins: { marginType: 'none' },
      };
      if (opts.deviceName) options.deviceName = String(opts.deviceName);
      if (opts.pageSize === 'A4') options.pageSize = 'A4';
      // الإيصال الحراري: نترك مقاس الورق لإعدادات الطابعة (لفة 80mm)
      e.sender.print(options, (success, reason) => resolve({ ok: success, reason: reason || '' }));
    });
  });

  // يبني نافذة مخفية من HTML جاهز (تذاكر المطبخ، التقارير)
  async function withHiddenWindow(html, fn) {
    const tmp = path.join(os.tmpdir(), `ledger-print-${Date.now()}-${Math.random().toString(36).slice(2)}.html`);
    fs.writeFileSync(tmp, html, 'utf8');
    const win = new BrowserWindow({
      show: false,
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, javascript: false },
    });
    try {
      await win.loadFile(tmp);
      return await fn(win);
    } finally {
      if (!win.isDestroyed()) win.destroy();
      fs.rm(tmp, { force: true }, () => {});
    }
  }

  ipcMain.handle('print:html', (e, opts = {}) => {
    guard(e);
    return withHiddenWindow(String(opts.html || ''), (win) =>
      new Promise((resolve) => {
        const options = {
          silent: !!opts.silent,
          printBackground: true,
          copies: Math.max(1, Math.min(10, Number(opts.copies) || 1)),
          margins: { marginType: opts.pageSize === 'A4' ? 'default' : 'none' },
        };
        if (opts.deviceName) options.deviceName = String(opts.deviceName);
        if (opts.pageSize === 'A4') options.pageSize = 'A4';
        // مقاس مخصص بالملّيمتر (ملصقات الباركود): Electron يطلبه بالميكرون
        const mm = opts.pageSizeMm;
        if (mm && Number(mm.width) > 0 && Number(mm.height) > 0) {
          options.pageSize = { width: Math.round(Number(mm.width) * 1000), height: Math.round(Number(mm.height) * 1000) };
        }
        if (opts.landscape) options.landscape = true;
        win.webContents.print(options, (success, reason) => resolve({ ok: success, reason: reason || '' }));
      })
    );
  });

  ipcMain.handle('print:pdf', async (e, opts = {}) => {
    guard(e);
    const win = getWindow();
    const res = await dialog.showSaveDialog(win, {
      defaultPath: String(opts.defaultName || 'report.pdf'),
      filters: [{ name: 'PDF', extensions: ['pdf'] }],
    });
    if (res.canceled || !res.filePath) return { ok: false, canceled: true };
    return withHiddenWindow(String(opts.html || ''), async (hidden) => {
      const buf = await hidden.webContents.printToPDF({
        pageSize: 'A4',
        printBackground: true,
        landscape: !!opts.landscape,
        margins: { marginType: 'default' },
      });
      fs.writeFileSync(res.filePath, buf);
      return { ok: true, path: res.filePath };
    });
  });

  /* ------------------------------ الملفات ------------------------------ */

  ipcMain.handle('file:saveText', async (e, opts = {}) => {
    guard(e);
    const res = await dialog.showSaveDialog(getWindow(), {
      defaultPath: String(opts.defaultName || 'export.csv'),
      filters: opts.filters || [{ name: 'CSV', extensions: ['csv'] }],
    });
    if (res.canceled || !res.filePath) return { ok: false, canceled: true };
    fs.writeFileSync(res.filePath, String(opts.content ?? ''), 'utf8');
    return { ok: true, path: res.filePath };
  });

  /* ------------------------ النسخ الاحتياطي والاستعادة ------------------------ */

  ipcMain.handle('backup:list', (e) => { guard(e); return getStore().listBackups(); });

  ipcMain.handle('backup:export', async (e) => {
    guard(e);
    const res = await dialog.showSaveDialog(getWindow(), {
      defaultPath: `SmartLedger-backup-${stamp()}.db`,
      filters: [{ name: 'Smart Ledger backup', extensions: ['db'] }],
    });
    if (res.canceled || !res.filePath) return { ok: false, canceled: true };
    await getStore().backupTo(res.filePath);
    return { ok: true, path: res.filePath };
  });

  async function restoreFrom(src) {
    const win = getWindow();
    let info;
    try {
      info = validateBackupFile(src);
    } catch (err) {
      return { ok: false, error: String((err && err.message) || err) };
    }
    const answer = await dialog.showMessageBox(win, {
      type: 'warning',
      buttons: ['استعادة وإعادة التشغيل', 'إلغاء'],
      defaultId: 1,
      cancelId: 1,
      message: 'استعادة نسخة احتياطية',
      detail:
        'سيتم استبدال كل بيانات البرنامج الحالية ببيانات هذه النسخة، ثم يُعاد تشغيل البرنامج.\n' +
        'ستُحفظ نسخة أمان من بياناتك الحالية تلقائياً قبل الاستبدال.\n\n' +
        `عدد السجلات في النسخة: ${info.records}`,
    });
    if (answer.response !== 0) return { ok: false, canceled: true };

    const store = getStore();
    try {
      await store.backupTo(path.join(store.backupsDir, `pre-restore-${stamp()}.db`));
      state.restoring = true;
      store.close();
      for (const ext of ['-wal', '-shm']) fs.rmSync(store.file + ext, { force: true });
      fs.copyFileSync(src, store.file);
    } catch (err) {
      return { ok: false, error: String((err && err.message) || err) };
    }
    app.relaunch();
    app.exit(0); // خروج فوري: لا نسمح للواجهة بحفظ حالتها القديمة فوق النسخة المستعادة
    return { ok: true };
  }

  ipcMain.handle('backup:restoreFile', async (e) => {
    guard(e);
    const res = await dialog.showOpenDialog(getWindow(), {
      properties: ['openFile'],
      filters: [{ name: 'Smart Ledger backup', extensions: ['db'] }],
    });
    if (res.canceled || !res.filePaths[0]) return { ok: false, canceled: true };
    return restoreFrom(res.filePaths[0]);
  });

  ipcMain.handle('backup:restoreAuto', async (e, name) => {
    guard(e);
    const safe = path.basename(String(name || ''));
    const item = getStore().listBackups().find((b) => b.name === safe);
    if (!item) return { ok: false, error: 'النسخة غير موجودة.' };
    return restoreFrom(item.path);
  });
}

module.exports = { registerSystemIpc, state };
