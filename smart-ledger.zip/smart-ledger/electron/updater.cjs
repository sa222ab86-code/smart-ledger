'use strict';
const { app, ipcMain } = require('electron');
const { autoUpdater } = require('electron-updater');

const CHECK_EVERY_MS = 4 * 60 * 60 * 1000; // كل 4 ساعات
const FIRST_CHECK_DELAY_MS = 8 * 1000;

function initUpdater({ getWindow, beforeInstall }) {
  let state = { status: 'idle', version: app.getVersion(), manual: false };
  let manualCheck = false;

  const publish = (patch) => {
    state = { ...state, ...patch };
    const win = getWindow();
    if (win && !win.isDestroyed()) win.webContents.send('update:status', state);
  };

  autoUpdater.autoDownload = true;           // ينزّل التحديث في الخلفية
  autoUpdater.autoInstallOnAppQuit = true;   // ويثبّته تلقائياً عند الإغلاق التالي
  autoUpdater.allowPrerelease = false;
  autoUpdater.logger = console;

  autoUpdater.on('checking-for-update', () =>
    publish({ status: 'checking', manual: manualCheck, error: undefined })
  );
  autoUpdater.on('update-available', (info) =>
    publish({ status: 'available', newVersion: info.version, manual: manualCheck })
  );
  autoUpdater.on('update-not-available', () => {
    publish({ status: manualCheck ? 'not-available' : 'idle', manual: manualCheck });
    manualCheck = false;
  });
  autoUpdater.on('download-progress', (p) =>
    publish({ status: 'downloading', percent: Math.round(p.percent) })
  );
  autoUpdater.on('update-downloaded', (info) =>
    publish({ status: 'downloaded', newVersion: info.version })
  );
  autoUpdater.on('error', (err) => {
    // الفحص الصامت في الخلفية (مثلاً بدون إنترنت) لا يزعج الكاشير بأي رسالة
    if (manualCheck) {
      publish({ status: 'error', manual: true, error: String((err && err.message) || err) });
    } else if (state.status === 'checking') {
      publish({ status: 'idle' });
    }
    manualCheck = false;
  });

  async function check({ manual = false } = {}) {
    if (!app.isPackaged) {
      if (manual) publish({ status: 'error', manual: true, error: 'التحديث التلقائي يعمل في النسخة المثبتة فقط وليس في وضع التطوير.' });
      return;
    }
    manualCheck = manual;
    try {
      await autoUpdater.checkForUpdates();
    } catch {
      /* يُعالَج في حدث error */
    }
  }

  ipcMain.handle('update:getState', () => state);
  ipcMain.handle('update:check', () => check({ manual: true }));
  ipcMain.handle('update:install', async () => {
    try { await beforeInstall(); } catch (e) { console.error('Backup before install failed:', e); }
    autoUpdater.quitAndInstall(false, true);
  });

  if (app.isPackaged) {
    setTimeout(() => check(), FIRST_CHECK_DELAY_MS);
    setInterval(() => check(), CHECK_EVERY_MS);
  }

  return { check };
}

module.exports = { initUpdater };
