'use strict';
const { app, BrowserWindow, ipcMain, shell, Menu, dialog } = require('electron');
const path = require('node:path');
const { openStore } = require('./db.cjs');
const { initUpdater } = require('./updater.cjs');

const DEV_URL = process.env.VITE_DEV_SERVER_URL || '';
const isDev = !app.isPackaged;

// نسخة التطوير تستعمل قاعدة بيانات منفصلة حتى لا تلوّث بيانات النسخة المثبتة
if (isDev) app.setPath('userData', `${app.getPath('userData')}-dev`);

let mainWindow = null;
let store = null;
let updater = null;

function isTrusted(event) {
  return mainWindow && !mainWindow.isDestroyed() && event.sender === mainWindow.webContents;
}

function isAppUrl(url) {
  if (DEV_URL && url.startsWith(DEV_URL)) return true;
  return url.startsWith('file://');
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 850,
    minWidth: 1024,
    minHeight: 640,
    show: false,
    autoHideMenuBar: true, // القائمة تظهر بالضغط على Alt
    backgroundColor: '#0f172a',
    title: 'الدفتر الذكي',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!isAppUrl(url)) {
      event.preventDefault();
      if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; });

  if (DEV_URL) mainWindow.loadURL(DEV_URL);
  else mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
}

function registerIpc() {
  ipcMain.handle('db:load', (e) => { if (!isTrusted(e)) throw new Error('untrusted'); return store.loadAll(); });
  ipcMain.handle('db:saveCollection', (e, name, items) => { if (!isTrusted(e)) throw new Error('untrusted'); store.saveCollection(name, items); return true; });
  ipcMain.handle('db:saveKv', (e, key, value) => { if (!isTrusted(e)) throw new Error('untrusted'); store.saveKv(key, value); return true; });

  ipcMain.on('db:saveCollectionSync', (e, name, items) => {
    try { if (!isTrusted(e)) throw new Error('untrusted'); store.saveCollection(name, items); e.returnValue = true; }
    catch (err) { console.error(err); e.returnValue = false; }
  });
  ipcMain.on('db:saveKvSync', (e, key, value) => {
    try { if (!isTrusted(e)) throw new Error('untrusted'); store.saveKv(key, value); e.returnValue = true; }
    catch (err) { console.error(err); e.returnValue = false; }
  });

  ipcMain.handle('app:version', () => app.getVersion());
}

function buildMenu() {
  const template = [
    {
      label: 'ملف',
      submenu: [
        {
          label: 'نسخة احتياطية الآن',
          click: async () => {
            try {
              const dest = await store.backupNow();
              dialog.showMessageBox(mainWindow, { type: 'info', message: 'تم إنشاء النسخة الاحتياطية', detail: dest });
            } catch (err) {
              dialog.showErrorBox('تعذر إنشاء النسخة الاحتياطية', String(err && err.message || err));
            }
          },
        },
        { label: 'فتح مجلد النسخ الاحتياطية', click: () => shell.openPath(store.backupsDir) },
        { label: 'فتح مجلد البيانات', click: () => shell.openPath(app.getPath('userData')) },
        { type: 'separator' },
        { role: 'quit', label: 'خروج' },
      ],
    },
    {
      label: 'مساعدة',
      submenu: [
        { label: 'التحقق من وجود تحديث', click: () => updater && updater.check({ manual: true }) },
        {
          label: 'عن البرنامج',
          click: () =>
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              message: 'الدفتر الذكي',
              detail: `الإصدار ${app.getVersion()}\nقاعدة البيانات: ${store.file}`,
            }),
        },
      ],
    },
  ];
  if (isDev) {
    template.push({ label: 'تطوير', submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }] });
  }
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

if (!app.requestSingleInstanceLock()) {
  // لا نسمح بنسختين تكتبان على نفس قاعدة البيانات
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(async () => {
    try {
      store = openStore(app.getPath('userData'));
    } catch (err) {
      dialog.showErrorBox('تعذر فتح قاعدة البيانات', String((err && err.message) || err));
      app.quit();
      return;
    }
    try { await store.backupIfNeeded(); } catch (err) { console.error('Daily backup failed:', err); }

    registerIpc();
    buildMenu();
    createWindow();
    updater = initUpdater({
      getWindow: () => mainWindow,
      beforeInstall: () => store.backupNow(),
    });

    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });

  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
  app.on('will-quit', () => { if (store) store.close(); });
}
