'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// واجهة محدودة وآمنة: الصفحة لا ترى Node ولا ipcRenderer مباشرة.
contextBridge.exposeInMainWorld('ledger', {
  isElectron: true,
  db: {
    loadAll: () => ipcRenderer.invoke('db:load'),
    saveCollection: (name, items) => ipcRenderer.invoke('db:saveCollection', name, items),
    saveKv: (key, value) => ipcRenderer.invoke('db:saveKv', key, value),
    // نسخ متزامنة تُستعمل عند إغلاق النافذة فقط لضمان عدم ضياع آخر تعديل
    saveCollectionSync: (name, items) => ipcRenderer.sendSync('db:saveCollectionSync', name, items),
    saveKvSync: (key, value) => ipcRenderer.sendSync('db:saveKvSync', key, value),
  },
  app: {
    getVersion: () => ipcRenderer.invoke('app:version'),
  },
  update: {
    getState: () => ipcRenderer.invoke('update:getState'),
    check: () => ipcRenderer.invoke('update:check'),
    install: () => ipcRenderer.invoke('update:install'),
    onStatus: (cb) => {
      const handler = (_event, state) => cb(state);
      ipcRenderer.on('update:status', handler);
      return () => ipcRenderer.removeListener('update:status', handler);
    },
  },
});
