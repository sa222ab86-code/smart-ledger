'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// واجهة محدودة وآمنة: الصفحة لا ترى Node ولا ipcRenderer مباشرة.
contextBridge.exposeInMainWorld('ledger', {
  isElectron: true,
  db: {
    loadAll: () => ipcRenderer.invoke('db:load'),
    saveCollection: (name, items) => ipcRenderer.invoke('db:saveCollection', name, items),
    patchCollection: (name, patch) => ipcRenderer.invoke('db:patchCollection', name, patch),
    saveKv: (key, value) => ipcRenderer.invoke('db:saveKv', key, value),
    // نسخ متزامنة تُستعمل عند إغلاق النافذة فقط لضمان عدم ضياع آخر تعديل
    saveCollectionSync: (name, items) => ipcRenderer.sendSync('db:saveCollectionSync', name, items),
    saveKvSync: (key, value) => ipcRenderer.sendSync('db:saveKvSync', key, value),
    patchCollectionSync: (name, patch) => ipcRenderer.sendSync('db:patchCollectionSync', name, patch),
  },
  print: {
    list: () => ipcRenderer.invoke('print:list'),
    page: (opts) => ipcRenderer.invoke('print:page', opts),
    html: (opts) => ipcRenderer.invoke('print:html', opts),
    pdf: (opts) => ipcRenderer.invoke('print:pdf', opts),
  },
  files: {
    saveText: (opts) => ipcRenderer.invoke('file:saveText', opts),
  },
  backup: {
    list: () => ipcRenderer.invoke('backup:list'),
    exportTo: () => ipcRenderer.invoke('backup:export'),
    restoreFromFile: () => ipcRenderer.invoke('backup:restoreFile'),
    restoreFromAuto: (name) => ipcRenderer.invoke('backup:restoreAuto', name),
  },
  app: {
    getVersion: () => ipcRenderer.invoke('app:version'),
    setIcon: (dataUrl) => ipcRenderer.invoke('app:setIcon', dataUrl),
  },
  update: {
    getState: () => ipcRenderer.invoke('update:getState'),
    check: () => ipcRenderer.invoke('update:check'),
    install: () => ipcRenderer.invoke('update:install'),
    onStatus: (cb) => {
      const handler = (_event, state) => cb(state);
      ipcRenderer.on('update:status', handler);
      return () => ipcRenderer.removeListener('update:status', handler);
    },
  },
});
