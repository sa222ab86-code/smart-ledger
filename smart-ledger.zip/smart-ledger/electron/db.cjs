'use strict';
/**
 * طبقة SQLite (better-sqlite3) — تعمل في العملية الرئيسية فقط.
 *
 * التصميم:
 *  - records(collection, id, pos, data): كل عنصر (فاتورة/صنف/عميل...) صف مستقل،
 *    والبيانات كاملة في عمود data بصيغة JSON، و pos يحفظ الترتيب.
 *  - collections: تسجّل المجموعات التي حُفظت فعلاً، لنميّز "لم تُحفظ بعد" (نستخدم البيانات الابتدائية)
 *    عن "حُفظت وهي فارغة" (المستخدم حذف كل شيء عمداً).
 *  - kv: الإعدادات والقيم المفردة (إعدادات الشركة، الوضع الليلي...).
 *  - PRAGMA user_version يتتبع إصدار المخطط لترحيل البيانات عند التحديثات.
 */
const path = require('node:path');
const fs = require('node:fs');
const Database = require('better-sqlite3');

const MIGRATIONS = [
  // v1
  (db) =>
    db.exec(`
      CREATE TABLE collections (
        name     TEXT PRIMARY KEY,
        saved_at TEXT NOT NULL
      );
      CREATE TABLE records (
        collection TEXT    NOT NULL,
        id         TEXT    NOT NULL,
        pos        INTEGER NOT NULL,
        data       TEXT    NOT NULL,
        updated_at TEXT    NOT NULL,
        PRIMARY KEY (collection, id)
      );
      CREATE INDEX idx_records_order ON records (collection, pos);
      CREATE TABLE kv (
        key        TEXT PRIMARY KEY,
        value      TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `),
  // لإضافة تغيير مستقبلاً: أضف دالة جديدة هنا (لا تعدّل القديمة أبداً).
];

const MAX_BACKUPS = 15;

function stamp(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function openStore(userDataDir) {
  fs.mkdirSync(userDataDir, { recursive: true });
  const file = path.join(userDataDir, 'ledger.db');
  const backupsDir = path.join(userDataDir, 'backups');
  fs.mkdirSync(backupsDir, { recursive: true });

  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = FULL'); // أمان أعلى عند انقطاع الكهرباء
  db.pragma('foreign_keys = ON');

  // ---- ترحيل المخطط (مع نسخة احتياطية قبل أي ترحيل على بيانات موجودة) ----
  let version = db.pragma('user_version', { simple: true });
  if (version > MIGRATIONS.length) {
    db.close();
    throw new Error(
      `قاعدة البيانات أحدث (v${version}) من هذا الإصدار من التطبيق (v${MIGRATIONS.length}). حدّث التطبيق.`
    );
  }
  if (version > 0 && version < MIGRATIONS.length) {
    db.pragma('wal_checkpoint(TRUNCATE)');
    fs.copyFileSync(file, path.join(backupsDir, `pre-migration-v${version}-${stamp()}.db`));
  }
  while (version < MIGRATIONS.length) {
    const target = version + 1;
    db.transaction(() => {
      MIGRATIONS[version](db);
      db.pragma(`user_version = ${target}`);
    })();
    version = target;
  }

  // ---- العبارات الجاهزة ----
  const q = {
    listCollections: db.prepare('SELECT name FROM collections'),
    readRecords: db.prepare('SELECT data FROM records WHERE collection = ? ORDER BY pos'),
    existing: db.prepare('SELECT id, pos, data FROM records WHERE collection = ?'),
    upsert: db.prepare(`
      INSERT INTO records (collection, id, pos, data, updated_at) VALUES (?, ?, ?, ?, ?)
      ON CONFLICT (collection, id) DO UPDATE SET
        pos = excluded.pos, data = excluded.data, updated_at = excluded.updated_at`),
    remove: db.prepare('DELETE FROM records WHERE collection = ? AND id = ?'),
    positions: db.prepare('SELECT id, pos FROM records WHERE collection = ?'),
    setPos: db.prepare('UPDATE records SET pos = ? WHERE collection = ? AND id = ?'),
    count: db.prepare('SELECT COUNT(*) AS c FROM records WHERE collection = ?'),
    posRange: db.prepare('SELECT MIN(pos) AS lo, MAX(pos) AS hi FROM records WHERE collection = ?'),
    updateData: db.prepare('UPDATE records SET data = ?, updated_at = ? WHERE collection = ? AND id = ?'),
    markSaved: db.prepare(`
      INSERT INTO collections (name, saved_at) VALUES (?, ?)
      ON CONFLICT (name) DO UPDATE SET saved_at = excluded.saved_at`),
    readKv: db.prepare('SELECT key, value FROM kv'),
    upsertKv: db.prepare(`
      INSERT INTO kv (key, value, updated_at) VALUES (?, ?, ?)
      ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`),
  };

  function loadAll() {
    const collections = {};
    for (const { name } of q.listCollections.all()) {
      collections[name] = q.readRecords.all(name).map((r) => JSON.parse(r.data));
    }
    const kv = {};
    for (const { key, value } of q.readKv.all()) kv[key] = JSON.parse(value);
    return { collections, kv };
  }

  const saveCollectionTx = db.transaction((name, items) => {
    const now = new Date().toISOString();
    const existing = new Map(q.existing.all(name).map((r) => [r.id, r]));
    const seen = new Set();

    items.forEach((item, i) => {
      let id = item && item.id != null ? String(item.id) : `__idx_${i}`;
      if (seen.has(id)) id = `${id}__dup${i}`;
      seen.add(id);
      const json = JSON.stringify(item);
      const prev = existing.get(id);
      if (!prev || prev.data !== json || prev.pos !== i) {
        q.upsert.run(name, id, i, json, now);
      }
    });
    for (const id of existing.keys()) {
      if (!seen.has(id)) q.remove.run(name, id);
    }
    q.markSaved.run(name, now);
  });

  function saveCollection(name, items) {
    if (typeof name !== 'string' || !name) throw new Error('اسم المجموعة غير صالح');
    if (!Array.isArray(items)) throw new Error('المجموعة يجب أن تكون مصفوفة');
    saveCollectionTx(name, items);
  }

  /**
   * حفظ تفاضلي: يكتب فقط العناصر التي تغيّرت بدل إعادة كتابة المجموعة كلها.
   * patch = { upserts: [[id, index, item]], removes: [id], order?: [id...], head?, tail?, count }
   *  - order: ترتيب جديد كامل (تبديل/إدراج في المنتصف) → إعادة ترقيم pos
   *  - بدون order: الترتيب النسبي للعناصر الموجودة لم يتغيّر؛ نعدّل البيانات فقط،
   *    والعناصر الجديدة في البداية (head) تأخذ pos أصغر من الحالي، وفي النهاية (tail) أكبر.
   *    (pos لا يلزم أن يكون متتالياً، المهم الترتيب)
   *  - count للتحقق: إن لم يطابق عدد الصفوف بعد التطبيق نلغي المعاملة ويُعاد الحفظ كاملاً
   */
  const patchCollectionTx = db.transaction((name, patch) => {
    const now = new Date().toISOString();
    for (const id of patch.removes || []) q.remove.run(name, String(id));
    if (Array.isArray(patch.order)) {
      for (const [id, pos, item] of patch.upserts || []) {
        q.upsert.run(name, String(id), pos, JSON.stringify(item), now);
      }
    } else {
      const head = patch.head | 0;
      const tail = patch.tail | 0;
      const count = patch.count | 0;
      const range = head || tail ? q.posRange.get(name) : null;
      const lo = range && range.lo != null ? range.lo : 0;
      const hi = range && range.hi != null ? range.hi : -1;
      for (const [id, i, item] of patch.upserts || []) {
        const json = JSON.stringify(item);
        if (i < head) q.upsert.run(name, String(id), lo - head + i, json, now);
        else if (i >= count - tail) q.upsert.run(name, String(id), hi + 1 + (i - (count - tail)), json, now);
        else if (q.updateData.run(json, now, name, String(id)).changes === 0) {
          throw new Error(`PATCH_MISMATCH ${name}: missing ${id}`);
        }
      }
    }
    if (Array.isArray(patch.order)) {
      const want = new Map(patch.order.map((id, i) => [String(id), i]));
      for (const r of q.positions.all(name)) {
        const p = want.get(r.id);
        if (p !== undefined && p !== r.pos) q.setPos.run(p, name, r.id);
      }
    }
    if (typeof patch.count === 'number') {
      const c = q.count.get(name).c;
      if (c !== patch.count) throw new Error(`PATCH_MISMATCH ${name}: ${c} != ${patch.count}`);
    }
    q.markSaved.run(name, now);
  });

  function patchCollection(name, patch) {
    if (typeof name !== 'string' || !name) throw new Error('اسم المجموعة غير صالح');
    if (!patch || typeof patch !== 'object') throw new Error('بيانات الحفظ غير صالحة');
    patchCollectionTx(name, patch);
  }

  function saveKv(key, value) {
    if (typeof key !== 'string' || !key) throw new Error('مفتاح غير صالح');
    q.upsertKv.run(key, JSON.stringify(value === undefined ? null : value), new Date().toISOString());
  }

  function rotateBackups() {
    const files = fs
      .readdirSync(backupsDir)
      .filter((f) => /^ledger-\d{8}-\d{6}\.db$/.test(f))
      .sort(); // الاسم يحتوي الوقت فالترتيب الأبجدي = زمني
    for (const f of files.slice(0, Math.max(0, files.length - MAX_BACKUPS))) {
      try { fs.unlinkSync(path.join(backupsDir, f)); } catch { /* تجاهل */ }
    }
  }

  async function backupNow() {
    const dest = path.join(backupsDir, `ledger-${stamp()}.db`);
    await db.backup(dest);
    rotateBackups();
    return dest;
  }

  /** نسخة احتياطية تلقائية: مرة واحدة على الأقل كل يوم عند التشغيل */
  async function backupIfNeeded() {
    const today = stamp().slice(0, 8);
    const has = fs.readdirSync(backupsDir).some((f) => f.startsWith(`ledger-${today}`));
    if (!has) return backupNow();
    return null;
  }

  function close() {
    try { db.close(); } catch { /* تجاهل */ }
  }

  /** نسخة احتياطية إلى مسار يختاره المستخدم (ملف .db) */
  async function backupTo(dest) {
    await db.backup(dest);
    return dest;
  }

  /** قائمة النسخ التلقائية الموجودة في مجلد backups */
  function listBackups() {
    return fs
      .readdirSync(backupsDir)
      .filter((f) => f.endsWith('.db'))
      .map((f) => {
        const st = fs.statSync(path.join(backupsDir, f));
        return { name: f, path: path.join(backupsDir, f), size: st.size, mtime: st.mtime.toISOString() };
      })
      .sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
  }

  return { file, backupsDir, loadAll, saveCollection, patchCollection, saveKv, backupNow, backupIfNeeded, backupTo, listBackups, close };
}

/**
 * يتحقق أن الملف قاعدة بيانات صالحة لهذا التطبيق قبل استعادتها.
 * يرمي خطأ برسالة عربية واضحة إن لم تكن صالحة.
 */
function validateBackupFile(file) {
  let probe;
  try {
    probe = new Database(file, { readonly: true, fileMustExist: true });
  } catch {
    throw new Error('الملف ليس قاعدة بيانات SQLite صالحة.');
  }
  try {
    const version = probe.pragma('user_version', { simple: true });
    if (version > MIGRATIONS.length) {
      throw new Error('هذه النسخة أحدث من إصدار البرنامج الحالي. حدّث البرنامج أولاً.');
    }
    const tables = probe
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
      .all()
      .map((r) => r.name);
    for (const t of ['records', 'collections', 'kv']) {
      if (!tables.includes(t)) throw new Error('الملف ليس نسخة احتياطية من الدفتر الذكي.');
    }
    const check = probe.pragma('quick_check', { simple: true });
    if (check !== 'ok') throw new Error('ملف النسخة الاحتياطية تالف.');
    const n = probe.prepare('SELECT COUNT(*) AS c FROM records').get().c;
    return { version, records: n };
  } finally {
    probe.close();
  }
}

module.exports = { openStore, validateBackupFile, stamp };
