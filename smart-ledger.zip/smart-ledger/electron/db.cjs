'use strict';
/**
 * طبقة SQLite (better-sqlite3) — تعمل في العملية الرئيسية فقط.
 *
 * التصميم:
 *  - records(collection, id, pos, data): كل عنصر (فاتورة/صنف/عميل...) صف مستقل،
 *    والبيانات كاملة في عمود data بصيغة JSON، و pos يحفظ الترتيب.
 *  - collections: تسجّل المجموعات التي حُفظت فعلاً، لنميّز "لم تُحفظ بعد" (نستخدم البيانات الابتدائية)
 *    عن "حُفظت وهي فارغة" (المستخدم حذف كل شيء عمداً).
 *  - kv: الإعدادات والقيم المفردة (إعدادات الشركة، الوضع الليلي...).
 *  - PRAGMA user_version يتتبع إصدار المخطط لترحيل البيانات عند التحديثات.
 */
const path = require('node:path');
const fs = require('node:fs');
const Database = require('better-sqlite3');

const MIGRATIONS = [
  // v1
  (db) =>
    db.exec(`
      CREATE TABLE collections (
        name     TEXT PRIMARY KEY,
        saved_at TEXT NOT NULL
      );
      CREATE TABLE records (
        collection TEXT    NOT NULL,
        id         TEXT    NOT NULL,
        pos        INTEGER NOT NULL,
        data       TEXT    NOT NULL,
        updated_at TEXT    NOT NULL,
        PRIMARY KEY (collection, id)
      );
      CREATE INDEX idx_records_order ON records (collection, pos);
      CREATE TABLE kv (
        key        TEXT PRIMARY KEY,
        value      TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `),
  // لإضافة تغيير مستقبلاً: أضف دالة جديدة هنا (لا تعدّل القديمة أبداً).
];

const MAX_BACKUPS = 15;

function stamp(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function openStore(userDataDir) {
  fs.mkdirSync(userDataDir, { recursive: true });
  const file = path.join(userDataDir, 'ledger.db');
  const backupsDir = path.join(userDataDir, 'backups');
  fs.mkdirSync(backupsDir, { recursive: true });

  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = FULL'); // أمان أعلى عند انقطاع الكهرباء
  db.pragma('foreign_keys = ON');

  // ---- ترحيل المخطط (مع نسخة احتياطية قبل أي ترحيل على بيانات موجودة) ----
  let version = db.pragma('user_version', { simple: true });
  if (version > MIGRATIONS.length) {
    db.close();
    throw new Error(
      `قاعدة البيانات أحدث (v${version}) من هذا الإصدار من التطبيق (v${MIGRATIONS.length}). حدّث التطبيق.`
    );
  }
  if (version > 0 && version < MIGRATIONS.length) {
    db.pragma('wal_checkpoint(TRUNCATE)');
    fs.copyFileSync(file, path.join(backupsDir, `pre-migration-v${version}-${stamp()}.db`));
  }
  while (version < MIGRATIONS.length) {
    const target = version + 1;
    db.transaction(() => {
      MIGRATIONS[version](db);
      db.pragma(`user_version = ${target}`);
    })();
    version = target;
  }

  // ---- العبارات الجاهزة ----
  const q = {
    listCollections: db.prepare('SELECT name FROM collections'),
    readRecords: db.prepare('SELECT data FROM records WHERE collection = ? ORDER BY pos'),
    existing: db.prepare('SELECT id, pos, data FROM records WHERE collection = ?'),
    upsert: db.prepare(`
      INSERT INTO records (collection, id, pos, data, updated_at) VALUES (?, ?, ?, ?, ?)
      ON CONFLICT (collection, id) DO UPDATE SET
        pos = excluded.pos, data = excluded.data, updated_at = excluded.updated_at`),
    remove: db.prepare('DELETE FROM records WHERE collection = ? AND id = ?'),
    markSaved: db.prepare(`
      INSERT INTO collections (name, saved_at) VALUES (?, ?)
      ON CONFLICT (name) DO UPDATE SET saved_at = excluded.saved_at`),
    readKv: db.prepare('SELECT key, value FROM kv'),
    upsertKv: db.prepare(`
      INSERT INTO kv (key, value, updated_at) VALUES (?, ?, ?)
      ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`),
  };

  function loadAll() {
    const collections = {};
    for (const { name } of q.listCollections.all()) {
      collections[name] = q.readRecords.all(name).map((r) => JSON.parse(r.data));
    }
    const kv = {};
    for (const { key, value } of q.readKv.all()) kv[key] = JSON.parse(value);
    return { collections, kv };
  }

  const saveCollectionTx = db.transaction((name, items) => {
    const now = new Date().toISOString();
    const existing = new Map(q.existing.all(name).map((r) => [r.id, r]));
    const seen = new Set();

    items.forEach((item, i) => {
      let id = item && item.id != null ? String(item.id) : `__idx_${i}`;
      if (seen.has(id)) id = `${id}__dup${i}`;
      seen.add(id);
      const json = JSON.stringify(item);
      const prev = existing.get(id);
      if (!prev || prev.data !== json || prev.pos !== i) {
        q.upsert.run(name, id, i, json, now);
      }
    });
    for (const id of existing.keys()) {
      if (!seen.has(id)) q.remove.run(name, id);
    }
    q.markSaved.run(name, now);
  });

  function saveCollection(name, items) {
    if (typeof name !== 'string' || !name) throw new Error('اسم المجموعة غير صالح');
    if (!Array.isArray(items)) throw new Error('المجموعة يجب أن تكون مصفوفة');
    saveCollectionTx(name, items);
  }

  function saveKv(key, value) {
    if (typeof key !== 'string' || !key) throw new Error('مفتاح غير صالح');
    q.upsertKv.run(key, JSON.stringify(value === undefined ? null : value), new Date().toISOString());
  }

  function rotateBackups() {
    const files = fs
      .readdirSync(backupsDir)
      .filter((f) => /^ledger-\d{8}-\d{6}\.db$/.test(f))
      .sort(); // الاسم يحتوي الوقت فالترتيب الأبجدي = زمني
    for (const f of files.slice(0, Math.max(0, files.length - MAX_BACKUPS))) {
      try { fs.unlinkSync(path.join(backupsDir, f)); } catch { /* تجاهل */ }
    }
  }

  async function backupNow() {
    const dest = path.join(backupsDir, `ledger-${stamp()}.db`);
    await db.backup(dest);
    rotateBackups();
    return dest;
  }

  /** نسخة احتياطية تلقائية: مرة واحدة على الأقل كل يوم عند التشغيل */
  async function backupIfNeeded() {
    const today = stamp().slice(0, 8);
    const has = fs.readdirSync(backupsDir).some((f) => f.startsWith(`ledger-${today}`));
    if (!has) return backupNow();
    return null;
  }

  function close() {
    try { db.close(); } catch { /* تجاهل */ }
  }

  return { file, backupsDir, loadAll, saveCollection, saveKv, backupNow, backupIfNeeded, close };
}

module.exports = { openStore };
