export interface Variant {
  id: string;
  name: string;
  price: number;
}

export interface ProductUnit {
  id: string;
  name: string;
  factor: number;
  price: number;
  barcode: string;
  unitType?: 'size' | 'volume' | 'pack' | 'weight' | 'unit';
  cost?: number;
}

export interface BundleItem {
  productId: string;
  productName: string;
  qty: number;
}

export interface ProductGroup {
  id: string;
  nameAr: string;
  nameEn?: string;
  color?: string; // Hex color (e.g. #06b6d4, #f59e0b, #ef4444, #10b981, #8b5cf6, #ec4899)
  icon?: string;  // Icon name (e.g. 'Coffee', 'Utensils', 'Sandwich', 'Flame', 'Boxes', 'Package', 'Sparkles', 'Tag')
  description?: string;
  printerId?: string; // Linked printer for kitchen/station routing
  displayOrder?: number;
  isActive?: boolean;
}

export interface Product {
  id: string;
  nameAr: string;
  nameEn: string;
  price: number;
  cost: number;
  categoryAr: string;
  categoryEn: string;
  groupId?: string; // Reference to ProductGroup.id
  subCategoryAr?: string;
  stock: number;
  minStock?: number; // Minimum stock threshold for alert
  barcode: string;
  image?: string; // Product photo URL or data URL
  description?: string; // وصف الصنف (يظهر في الفاتورة تحت الاسم)
  variants?: Variant[];
  units?: ProductUnit[];
  isBundle?: boolean; // True if this item is a combo bundle of multiple items
  bundleItems?: BundleItem[]; // Sub-items included in this bundle
}
export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  balance: number;
  vatNumber?: string;
}

export interface CurrencyConfig {
  code: string;         // e.g. 'SAR', 'USD', 'EUR', 'AED', 'KWD', 'EGP', 'GBP'
  nameAr: string;       // e.g. 'ريال سعودي', 'دولار أمريكي', 'يورو'
  nameEn?: string;      // e.g. 'Saudi Riyal', 'US Dollar'
  symbol: string;       // e.g. '﷼', '$', '€', 'د.إ'
  exchangeRate: number; // 1 Unit of this currency = exchangeRate SAR (base currency). For SAR: 1.0. For USD: 3.75.
  isBase?: boolean;
  isEnabled: boolean;
  lastUpdated?: string;
}

export interface MultiCurrencySettings {
  enabled: boolean;
  baseCurrency: string; // Default 'SAR'
  currencies: CurrencyConfig[];
}

export interface InvoiceItem {
  productId?: string; // الصنف المباع (للفواتير الجديدة — يُستخدم لمنع حذف صنف عليه حركة)
  factor?: number;    // عدد الحبات في التعبئة المباعة (كرتون = 12 مثلاً) — لحساب الخصم من المخزون
  sourceLine?: number; // في المرتجع: رقم السطر في الفاتورة الأصلية
  name: string;
  description?: string;
  qty: number;
  price: number; // Pre-tax price
  tax: number;   // Tax amount for this item
  total: number; // Total inclusive of tax
}

export interface Invoice {
  id: string;
  /** نوع المستند: بيع (الافتراضي) أو مرتجع مبيعات — المرتجع قيمه سالبة فيُطرح تلقائياً من الإجماليات */
  docType?: 'sale' | 'return';
  originalInvoiceId?: string;     // المرتجع: الفاتورة الأصلية
  originalInvoiceNumber?: string;
  /** المرتجع: الجزء الذي خُصم من مديونية العميل على الفاتورة الأصلية بدل ردّه نقداً */
  debtOffset?: number;
  restocked?: boolean;            // المرتجع: هل أُعيدت الكميات للمخزون
  number: string;
  invoiceNumber: string; // Keep both number and invoiceNumber to support all components
  date: string;
  customerName: string;
  items: InvoiceItem[];
  subtotal: number;
  rawSubtotal?: number;       // Pre-discount subtotal
  tax: number;
  total: number;
  discount?: number;          // Discount amount in base currency
  discountType?: 'fixed' | 'percent'; // Type of discount
  discountValue?: number;     // Original discount value entered (e.g., 10 for 10% or 10 SAR)
  discountScope?: 'total' | 'subtotal'; // Applied on final total (inclusive of VAT) or pre-tax subtotal
  paymentMethod: 'cash' | 'card' | 'split';
  paidAmount?: number;        // Cash tendered (e.g. 50, 100, 200 SAR or exact)
  changeAmount?: number;      // Change returned to customer (paidAmount - total)
  isQuickPay?: boolean;       // Completed via Quick Pay
  orderType?: 'dine_in' | 'takeaway' | 'delivery';
  orderNumber?: number;
  currency?: string;          // Currency code when created or viewed (e.g. 'SAR', 'USD')
  exchangeRate?: number;      // Exchange rate applied
  convertedTotal?: number;    // Converted total if not in base currency
  // --- الدفع الجزئي / الآجل ---
  customerId?: string;                      // العميل المسجَّل (مطلوب عند الدفع الجزئي)
  cashierName?: string;                     // من أصدر الفاتورة (لتقرير أداء المستخدمين)
  remainingAmount?: number;                 // المتبقي على العميل (0 أو غير موجود = مسدّدة بالكامل)
  paymentStatus?: 'paid' | 'partial' | 'unpaid';
  note?: string;                            // ملاحظة على الفاتورة
  payments?: InvoicePayment[];              // سجل الدفعات (الأولى عند البيع + السدادات اللاحقة)
}

export interface InvoicePayment {
  id: string;
  date: string;
  amount: number;
  method: 'cash' | 'card';
  note?: string;
}

export interface CartItem {
  id: string;
  cartItemId: string;
  name: string;
  image?: string;
  unitName?: string;
  unitType?: string;
  factor?: number;
  price: number;
  qty: number;
  tax: number;
  total: number;
  description?: string; // وصف الصنف
  isBundle?: boolean;
  bundleDescription?: string;
  bundleItems?: BundleItem[];
}

export interface ParkedOrder {
  id: string;
  orderNumber: number;
  label: string; // e.g. "طلب معلق #1" or "طاولة 3"
  customerName?: string;
  customerId?: string; // العميل المسجَّل المختار وقت التعليق
  items: CartItem[];
  discountType: 'fixed' | 'percent';
  discountValue: number;
  discountScope?: 'total' | 'subtotal';
  rawSubtotal: number;
  discountAmount: number;
  discountedSubtotal: number;
  tax: number;
  total: number;
  createdAt: string;
  note?: string;
  dueTime?: string; // Expected delivery / pickup / customer return time (e.g. "14:30" or "12:15 م")
  dueDate?: string; // Expected due date if specified
}

export interface AppPrinter {
  id: string;
  name: string;
  ip?: string;
  osPrinterName?: string;
  type: 'cashier' | 'kitchen' | 'section';
  template?: 'thermal80' | 'A4' | 'kitchenTicket';
  status: 'online' | 'offline';
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  vatNumber?: string;
}

export interface PurchaseInvoice {
  id: string;
  supplierId: string;
  supplierName: string;
  date: string;
  items: { productId: string; productName: string; qty: number; price: number; total: number }[];
  total: number;
}

export interface AppUser {
  id: string;
  username: string;
  role: 'admin' | 'cashier';
  status: 'active' | 'suspended';
  fullName: string;
}

export interface CompanySettings {
  companyName: string;
  address: string;
  phone: string;
  mobile?: string;
  vatNumber: string;
  grNumber?: string;
  moNumber?: string;
  footer?: string;
  taxRate: number; // tax rate percentage, e.g. 15
  /** هل أسعار البيع المُدخلة للأصناف شاملة الضريبة؟ (افتراضياً: لا — تُضاف الضريبة فوق السعر) */
  pricesIncludeTax?: boolean;
  activityType: 'restaurant' | 'retail' | 'pharmacy' | 'metals' | 'other';
  logoUrl?: string; // Company logo image URL or base64 data URI
  printerSettings: {
    cashierPrinter?: string;
    kitchenPrinter?: string;
    sectionPrinters?: { section: string; printerName: string }[];
  };
  multiCurrency?: MultiCurrencySettings;
}


// ================= عروض الأسعار =================
export type QuotationStatus = 'draft' | 'sent' | 'accepted' | 'rejected' | 'invoiced';

export interface QuotationItem {
  id: string;            // معرّف السطر
  productId?: string;    // الصنف إن اختير من القائمة (البند الحر بدون معرّف)
  name: string;
  qty: number;
  price: number;         // سعر الوحدة قبل الضريبة
}

export interface Quotation {
  id: string;
  number: string;                 // QT-0001
  date: string;                   // تاريخ الإصدار YYYY-MM-DD HH:mm:ss
  validUntil: string;             // صالح حتى YYYY-MM-DD
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  items: QuotationItem[];
  discountType: 'fixed' | 'percent';
  discountValue: number;
  taxRate: number;                // نسبة الضريبة وقت الإصدار (مثلاً 15)
  rawSubtotal: number;            // قبل الخصم
  discount: number;               // قيمة الخصم الفعلية
  subtotal: number;               // بعد الخصم وقبل الضريبة
  tax: number;
  total: number;
  notes?: string;
  terms?: string;
  status: QuotationStatus;
  invoiceId?: string;             // بعد التحويل لفاتورة
  invoiceNumber?: string;
}
