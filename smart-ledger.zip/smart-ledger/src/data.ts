import { CompanySettings, Product, Customer, Invoice, CurrencyConfig, ProductGroup } from './types';
import defaultCompanyLogo from './assets/images/company_logo_1790270110137.jpg';

export const defaultCompanyLogoAsset = defaultCompanyLogo;

export const initialProductGroups: ProductGroup[] = [
  {
    id: 'grp-drinks',
    nameAr: 'مشروبات',
    nameEn: 'Drinks',
    color: '#06b6d4', // cyan
    icon: 'Coffee',
    description: 'المشروبات الساخنة والباردة والعصائر الطازجة',
    printerId: '',
    displayOrder: 1,
    isActive: true,
  },
  {
    id: 'grp-burgers',
    nameAr: 'برجر',
    nameEn: 'Burgers',
    color: '#f59e0b', // amber
    icon: 'Sandwich',
    description: 'ساندوتشات وبرجر اللحم والدجاج الطازج والمميز',
    printerId: 'p3', // Kitchen printer
    displayOrder: 2,
    isActive: true,
  },
  {
    id: 'grp-meals',
    nameAr: 'وجبات سريعة',
    nameEn: 'Fast Food Meals',
    color: '#ef4444', // red
    icon: 'Utensils',
    description: 'الوجبات والكومبو الكامل مع البطاطس والمشروب',
    printerId: 'p3',
    displayOrder: 3,
    isActive: true,
  },
  {
    id: 'grp-appetizers',
    nameAr: 'مقبلات',
    nameEn: 'Appetizers',
    color: '#10b981', // emerald
    icon: 'Flame',
    description: 'المقبلات الخفيفة والبطاطس المقرمشة والموزاريلا والصوصات',
    printerId: 'p3',
    displayOrder: 4,
    isActive: true,
  },
  {
    id: 'grp-desserts',
    nameAr: 'حلويات',
    nameEn: 'Desserts',
    color: '#ec4899', // pink
    icon: 'Cake',
    description: 'الحلويات والكوكيز والمعجنات والمخبوزات اللذيذة',
    printerId: '',
    displayOrder: 5,
    isActive: true,
  },
  {
    id: 'grp-combos',
    nameAr: 'باقات ومجموعات التوفير',
    nameEn: 'Value Bundles',
    color: '#8b5cf6', // purple
    icon: 'Boxes',
    description: 'عروض المجموعات السلعية والكومبو التوفيري',
    printerId: 'p3',
    displayOrder: 6,
    isActive: true,
  },
];

export const defaultCurrencies: CurrencyConfig[] = [
  {
    code: 'SAR',
    nameAr: 'ريال سعودي',
    nameEn: 'Saudi Riyal',
    symbol: '﷼',
    exchangeRate: 1.0,
    isBase: true,
    isEnabled: true,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'USD',
    nameAr: 'دولار أمريكي',
    nameEn: 'US Dollar',
    symbol: '$',
    exchangeRate: 3.75, // 1 USD = 3.75 SAR
    isBase: false,
    isEnabled: true,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'EUR',
    nameAr: 'يورو أوروبي',
    nameEn: 'Euro',
    symbol: '€',
    exchangeRate: 4.12, // 1 EUR = 4.12 SAR
    isBase: false,
    isEnabled: true,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'AED',
    nameAr: 'درهم إماراتي',
    nameEn: 'UAE Dirham',
    symbol: 'د.إ',
    exchangeRate: 1.02, // 1 AED = 1.02 SAR
    isBase: false,
    isEnabled: true,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'KWD',
    nameAr: 'دينار كويتي',
    nameEn: 'Kuwaiti Dinar',
    symbol: 'د.ك',
    exchangeRate: 12.25, // 1 KWD = 12.25 SAR
    isBase: false,
    isEnabled: true,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'BHD',
    nameAr: 'دينار بحريني',
    nameEn: 'Bahraini Dinar',
    symbol: 'د.ب',
    exchangeRate: 9.95, // 1 BHD = 9.95 SAR
    isBase: false,
    isEnabled: false,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'OMR',
    nameAr: 'ريال عماني',
    nameEn: 'Omani Rial',
    symbol: 'ر.ع',
    exchangeRate: 9.75, // 1 OMR = 9.75 SAR
    isBase: false,
    isEnabled: false,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'QAR',
    nameAr: 'ريال قطري',
    nameEn: 'Qatari Riyal',
    symbol: 'ر.ق',
    exchangeRate: 1.03, // 1 QAR = 1.03 SAR
    isBase: false,
    isEnabled: false,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'EGP',
    nameAr: 'جنيه مصري',
    nameEn: 'Egyptian Pound',
    symbol: 'ج.م',
    exchangeRate: 0.077, // 1 EGP = 0.077 SAR
    isBase: false,
    isEnabled: true,
    lastUpdated: '2026-09-23 12:00',
  },
  {
    code: 'GBP',
    nameAr: 'جنيه إسترليني',
    nameEn: 'British Pound',
    symbol: '£',
    exchangeRate: 4.88, // 1 GBP = 4.88 SAR
    isBase: false,
    isEnabled: false,
    lastUpdated: '2026-09-23 12:00',
  },
];

export const initialProducts: Product[] = [
  {
    id: 'p1',
    nameAr: 'قهوة عربية',
    nameEn: 'Arabic Coffee',
    price: 15.00,
    cost: 8.00,
    categoryAr: 'مشروبات',
    categoryEn: 'Drinks',
    groupId: 'grp-drinks',
    stock: 50,
    minStock: 15,
    barcode: '123456789',
    image: 'https://images.unsplash.com/photo-1578374173705-969cbe6f2d6b?w=600&auto=format&fit=crop&q=80',
    variants: [
      { id: 'v1-1', name: 'فنجان صغير', price: 15.00 },
      { id: 'v1-2', name: 'دلة وسط', price: 30.00 },
      { id: 'v1-3', name: 'دلة كبيرة', price: 45.00 }
    ],
    units: [
      { id: 'u1-1', name: 'فنجان صغير', factor: 1, price: 15.00, barcode: '123456789-1', unitType: 'size' },
      { id: 'u1-2', name: 'دلة وسط (3 فناجين)', factor: 3, price: 30.00, barcode: '123456789-2', unitType: 'volume' },
      { id: 'u1-3', name: 'دلة كبيرة (5 فناجين)', factor: 5, price: 45.00, barcode: '123456789-3', unitType: 'volume' }
    ]
  },
  {
    id: 'p2',
    nameAr: 'عصير برتقال طبيعي',
    nameEn: 'Fresh Orange Juice',
    price: 12.00,
    cost: 5.00,
    categoryAr: 'مشروبات',
    categoryEn: 'Drinks',
    groupId: 'grp-drinks',
    stock: 80,
    minStock: 20,
    barcode: '987654321',
    image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600&auto=format&fit=crop&q=80',
    units: [
      { id: 'u2-1', name: 'كوب صغير 250 مل', factor: 1, price: 12.00, barcode: '987654321-1', unitType: 'volume' },
      { id: 'u2-2', name: 'كوب وسط 400 مل', factor: 1.5, price: 16.00, barcode: '987654321-2', unitType: 'volume' },
      { id: 'u2-3', name: 'جالون عائلي 1 لتر', factor: 2.5, price: 28.00, barcode: '987654321-3', unitType: 'pack' }
    ]
  },
  {
    id: 'p3',
    nameAr: 'برجر لحم كلاسيك',
    nameEn: 'Classic Beef Burger',
    price: 22.00,
    cost: 11.50,
    categoryAr: 'برجر',
    categoryEn: 'Burger',
    groupId: 'grp-burgers',
    stock: 120,
    minStock: 25,
    barcode: '456123789',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
    variants: [
      { id: 'v3-1', name: 'سنجل', price: 22.00 },
      { id: 'v3-2', name: 'دبل', price: 29.00 }
    ],
    units: [
      { id: 'u3-1', name: 'سنجل (Single)', factor: 1, price: 22.00, barcode: '456123789-1', unitType: 'size' },
      { id: 'u3-2', name: 'دبل (Double)', factor: 1.5, price: 29.00, barcode: '456123789-2', unitType: 'size' },
      { id: 'u3-3', name: 'تربل عملاق (Triple)', factor: 2, price: 36.00, barcode: '456123789-3', unitType: 'size' }
    ]
  },
  {
    id: 'p4',
    nameAr: 'برجر دجاج مقرمش',
    nameEn: 'Crispy Chicken Burger',
    price: 19.00,
    cost: 9.00,
    categoryAr: 'برجر',
    categoryEn: 'Burger',
    groupId: 'grp-burgers',
    stock: 100,
    minStock: 20,
    barcode: '789123456',
    image: 'https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'p5',
    nameAr: 'بطاطس مقلية مميزة',
    nameEn: 'Special French Fries',
    price: 8.00,
    cost: 3.00,
    categoryAr: 'مقبلات',
    categoryEn: 'Appetizers',
    groupId: 'grp-appetizers',
    stock: 200,
    minStock: 30,
    barcode: '321654987',
    image: 'https://images.unsplash.com/photo-1576107232684-1279f3908594?w=600&auto=format&fit=crop&q=80',
    units: [
      { id: 'u5-1', name: 'حجم صغير (Small)', factor: 1, price: 8.00, barcode: '321654987-1', unitType: 'size' },
      { id: 'u5-2', name: 'حجم وسط (Medium)', factor: 1.5, price: 12.00, barcode: '321654987-2', unitType: 'size' },
      { id: 'u5-3', name: 'حجم عائلي كبير (Large)', factor: 2, price: 16.00, barcode: '321654987-3', unitType: 'size' }
    ]
  },
  {
    id: 'p6',
    nameAr: 'أصابع الموزاريلا',
    nameEn: 'Mozzarella Sticks',
    price: 14.00,
    cost: 6.00,
    categoryAr: 'مقبلات',
    categoryEn: 'Appetizers',
    groupId: 'grp-appetizers',
    stock: 90,
    minStock: 15,
    barcode: '159263487'
  },
  {
    id: 'p-bundle-1',
    nameAr: 'مجموعة التوفير العائلية (كومبو)',
    nameEn: 'Family Value Combo Bundle',
    price: 49.00,
    cost: 24.00,
    categoryAr: 'باقات ومجموعات التوفير',
    categoryEn: 'Value Bundles',
    groupId: 'grp-combos',
    stock: 40,
    minStock: 10,
    barcode: '62899001',
    isBundle: true,
    bundleItems: [
      { productId: 'p3', productName: 'برجر لحم كلاسيك', qty: 2 },
      { productId: 'p5', productName: 'بطاطس مقلية مميزة', qty: 2 },
      { productId: 'p2', productName: 'عصير برتقال طبيعي', qty: 2 }
    ]
  }
];

export const initialCustomers: Customer[] = [
  {
    id: 'c1',
    name: 'محمد أحمد العتيبي',
    phone: '0501234567',
    email: 'mohamed@email.com',
    address: 'الرياض - حي النزهة',
    balance: 0.00
  },
  {
    id: 'c2',
    name: 'سارة خالد الدوسري',
    phone: '0559876543',
    email: 'sara@email.com',
    address: 'الرياض - حي الياسمين',
    balance: 150.00
  }
];

export const initialInvoices: Invoice[] = [
  {
    id: 'inv1',
    number: 'INV-0001',
    invoiceNumber: 'INV-0001',
    date: '2026-07-01',
    customerName: 'نقدي',
    items: [
      { name: 'قهوة عربية', qty: 2, price: 15, tax: 4.5, total: 34.5 },
    ],
    subtotal: 30.00,
    tax: 4.50,
    total: 34.50,
    paymentMethod: 'cash',
    orderType: 'dine_in',
    orderNumber: 1,
  },
];

export const defaultCompanySettings: CompanySettings = {
  companyName: 'شركة البدر للتجارة والمبيعات',
  address: 'الرياض - شارع الملك فهد - حي العليا',
  phone: '0112345678',
  mobile: '0501234567',
  vatNumber: '301234567800003', // 15-digit standard Saudi VAT
  grNumber: '4603014479',
  moNumber: '6598755802',
  footer: 'شكراً لتسوقكم معنا - نأمل زيارتكم مجدداً',
  taxRate: 15,
  activityType: 'restaurant',
  logoUrl: defaultCompanyLogo,
  printerSettings: {
    cashierPrinter: 'طابعة الكاشير الرئيسية',
    kitchenPrinter: 'طابعة المطبخ (الطلبات الساخنة)'
  },
  multiCurrency: {
    enabled: true,
    baseCurrency: 'SAR',
    currencies: defaultCurrencies,
  },
};
