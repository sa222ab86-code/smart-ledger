import { useEffect, useState, type Dispatch, type SetStateAction } from 'react';

/* ------------------------------------------------------------------ *
 * واجهة الجسر (preload) — موجودة فقط داخل Electron
 * ------------------------------------------------------------------ */
export interface UpdateState {
  status: 'idle' | 'checking' | 'available' | 'downloading' | 'downloaded' | 'not-available' | 'error';
  version: string;
  newVersion?: string;
  percent?: number;
  manual?: boolean;
  error?: string;
}

export interface OsPrinter { name: string; displayName: string; isDefault: boolean; description: string }
export interface BackupInfo { name: string; path: string; size: number; mtime: string }

export interface LedgerApi {
  isElectron: true;
  db: {
    loadAll(): Promise<Snapshot>;
    saveCollection(name: string, items: unknown[]): Promise<boolean>;
    patchCollection?(name: string, patch: CollectionPatch): Promise<boolean>;
    patchCollectionSync?(name: string, patch: CollectionPatch): boolean;
    saveKv(key: string, value: unknown): Promise<boolean>;
    saveCollectionSync(name: string, items: unknown[]): boolean;
    saveKvSync(key: string, value: unknown): boolean;
  };
  print: {
    list(): Promise<OsPrinter[]>;
    page(opts: { silent?: boolean; deviceName?: string; pageSize?: 'A4' | 'thermal'; copies?: number }): Promise<{ ok: boolean; reason?: string }>;
    html(opts: { html: string; silent?: boolean; deviceName?: string; pageSize?: 'A4' | 'thermal'; pageSizeMm?: { width: number; height: number }; copies?: number; landscape?: boolean }): Promise<{ ok: boolean; reason?: string }>;
    pdf(opts: { html: string; defaultName: string; landscape?: boolean }): Promise<{ ok: boolean; canceled?: boolean; path?: string }>;
  };
  files: {
    saveText(opts: { defaultName: string; content: string; filters?: { name: string; extensions: string[] }[] }): Promise<{ ok: boolean; canceled?: boolean; path?: string }>;
  };
  backup: {
    list(): Promise<BackupInfo[]>;
    exportTo(): Promise<{ ok: boolean; canceled?: boolean; path?: string }>;
    restoreFromFile(): Promise<{ ok: boolean; canceled?: boolean; error?: string }>;
    restoreFromAuto(name: string): Promise<{ ok: boolean; canceled?: boolean; error?: string }>;
  };
  app: { getVersion(): Promise<string>; setIcon?(dataUrl: string | null): Promise<boolean> };
  update: {
    getState(): Promise<UpdateState>;
    check(): Promise<void>;
    install(): Promise<void>;
    onStatus(cb: (s: UpdateState) => void): () => void;
  };
}

declare global {
  interface Window {
    ledger?: LedgerApi;
  }
}

interface Snapshot {
  collections: Record<string, unknown[]>;
  kv: Record<string, unknown>;
}

type Pending = { kind: 'collection' | 'kv'; value: unknown };

export interface CollectionPatch {
  upserts: [string, number, unknown][];
  removes: string[];
  /** يُرسل فقط عند تغيّر الترتيب بشكل عام (تبديل/إدراج في المنتصف) → إعادة ترقيم */
  order?: string[];
  /** عدد العناصر الجديدة المضافة في بداية القائمة (بدون إعادة ترقيم الباقي) */
  head?: number;
  /** عدد العناصر الجديدة المضافة في نهاية القائمة */
  tail?: number;
  count: number;
}

/* ------------------------------------------------------------------ *
 * الحالة الداخلية
 * ------------------------------------------------------------------ */
const DEBOUNCE_MS = 300;
const RETRY_MS = 2000;
const LS_PREFIX = 'ledger:';

let snapshot: Snapshot = { collections: {}, kv: {} };
const pending = new Map<string, Pending>();
let timer: number | undefined;
let chain: Promise<void> = Promise.resolve();
const errorListeners = new Set<(hasError: boolean) => void>();

export function onSaveError(cb: (hasError: boolean) => void): () => void {
  errorListeners.add(cb);
  return () => errorListeners.delete(cb);
}
const emitError = (v: boolean) => errorListeners.forEach((cb) => cb(v));

/* ------------------------------------------------------------------ *
 * التحميل الأولي — يُستدعى مرة واحدة قبل رسم التطبيق
 * ------------------------------------------------------------------ */
export async function hydrate(): Promise<void> {
  if (window.ledger) {
    // إن فشل التحميل نرمي الخطأ: لا نبدأ بالبيانات الابتدائية كي لا نكتب فوق بيانات حقيقية
    snapshot = await window.ledger.db.loadAll();
    baselines.clear();
    for (const [k, items] of Object.entries(snapshot.collections)) {
      if (Array.isArray(items)) setBaseline(k, items);
    }
    return;
  }
  // وضع المتصفح (التطوير بدون Electron): localStorage
  const next: Snapshot = { collections: {}, kv: {} };
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith(LS_PREFIX)) continue;
      const raw = localStorage.getItem(k);
      if (raw == null) continue;
      const rest = k.slice(LS_PREFIX.length);
      if (rest.startsWith('c:')) next.collections[rest.slice(2)] = JSON.parse(raw);
      else if (rest.startsWith('k:')) next.kv[rest.slice(2)] = JSON.parse(raw);
    }
  } catch (e) {
    console.warn('localStorage read failed', e);
  }
  snapshot = next;
}

/* ------------------------------------------------------------------ *
 * الحفظ التفاضلي للمجموعات
 *   مع ١٨ ألف صنف كان أي تعديل (بيع واحد يُنقص المخزون) يرسل المصفوفة كاملة
 *   إلى العملية الرئيسية فتُحوَّل كلها إلى JSON وتُقارن صفاً صفاً → تهنيج.
 *   الآن نقارن بالمرجع (React لا يغيّر مراجع العناصر التي لم تتعدّل)
 *   ونرسل فقط العناصر المتغيّرة/المحذوفة.
 * ------------------------------------------------------------------ */
interface Baseline { ids: string[]; byId: Map<string, unknown> }
/** آخر نسخة مؤكَّد حفظها في قاعدة البيانات لكل مجموعة */
const baselines = new Map<string, Baseline>();

function idsOf(items: unknown[]): string[] | null {
  const ids = new Array<string>(items.length);
  const seen = new Set<string>();
  for (let i = 0; i < items.length; i++) {
    const it = items[i] as { id?: unknown } | null;
    if (!it || it.id == null) return null; // بلا معرّف → الحفظ الكامل
    const id = String(it.id);
    if (seen.has(id)) return null; // معرّف مكرر → الحفظ الكامل
    seen.add(id);
    ids[i] = id;
  }
  return ids;
}

function makeBaseline(items: unknown[], ids: string[]): Baseline {
  const byId = new Map<string, unknown>();
  for (let i = 0; i < items.length; i++) byId.set(ids[i], items[i]);
  return { ids, byId };
}

function setBaseline(key: string, items: unknown[]) {
  const ids = idsOf(items);
  if (ids) baselines.set(key, makeBaseline(items, ids));
  else baselines.delete(key);
}

/** يُرجع null إن لزم الحفظ الكامل، أو patch (قد يكون فارغاً) */
function diffCollection(key: string, items: unknown[]): { patch: CollectionPatch; next: Baseline } | null {
  const base = baselines.get(key);
  if (!base) return null;
  const ids = idsOf(items);
  if (!ids) return null;
  const upserts: [string, number, unknown][] = [];
  const nextIds = new Set<string>();
  for (let i = 0; i < items.length; i++) {
    const id = ids[i];
    nextIds.add(id);
    if (base.byId.get(id) !== items[i]) upserts.push([id, i, items[i]]);
  }
  const removes: string[] = [];
  for (const id of base.ids) if (!nextIds.has(id)) removes.push(id);

  // الحالات الشائعة لا تحتاج إعادة ترقيم كل الصفوف:
  //   [جديد..., ...القديم بنفس الترتيب (ناقص المحذوف)..., جديد...]
  let head = 0;
  while (head < ids.length && !base.byId.has(ids[head])) head++;
  let tail = 0;
  while (tail < ids.length - head && !base.byId.has(ids[ids.length - 1 - tail])) tail++;
  let sameOrder = true;
  let j = head;
  for (const id of base.ids) {
    if (!nextIds.has(id)) continue; // محذوف
    if (ids[j] !== id) { sameOrder = false; break; }
    j++;
  }
  if (sameOrder && j !== ids.length - tail) sameOrder = false;

  const patch: CollectionPatch = { upserts, removes, count: items.length };
  if (!sameOrder) patch.order = ids;
  else {
    if (head) patch.head = head;
    if (tail) patch.tail = tail;
  }
  return { patch, next: makeBaseline(items, ids) };
}

const isEmptyPatch = (p: CollectionPatch) => p.upserts.length === 0 && p.removes.length === 0 && !p.order;

async function writeCollection(key: string, items: unknown[]): Promise<void> {
  const api = window.ledger!;
  if (api.db.patchCollection) {
    const d = diffCollection(key, items);
    if (d) {
      if (isEmptyPatch(d.patch)) return;
      try {
        const ok = await api.db.patchCollection(key, d.patch);
        if (ok) baselines.set(key, d.next);
        return;
      } catch (err) {
        // عدم تطابق مع القاعدة → نرجع للحفظ الكامل أدناه
        console.warn(`patch "${key}" failed, falling back to full save`, err);
      }
    }
  }
  const ok = await api.db.saveCollection(key, items);
  if (ok) setBaseline(key, items);
}

function writeCollectionSync(key: string, items: unknown[]) {
  const api = window.ledger!;
  if (api.db.patchCollectionSync) {
    const d = diffCollection(key, items);
    if (d) {
      if (isEmptyPatch(d.patch)) return;
      if (api.db.patchCollectionSync(key, d.patch)) { baselines.set(key, d.next); return; }
    }
  }
  if (api.db.saveCollectionSync(key, items)) setBaseline(key, items);
}

/* ------------------------------------------------------------------ *
 * الحفظ
 * ------------------------------------------------------------------ */
async function writeOne(key: string, p: Pending): Promise<void> {
  const api = window.ledger;
  if (api) {
    if (p.kind === 'collection') await writeCollection(key, p.value as unknown[]);
    else await api.db.saveKv(key, p.value);
  } else {
    localStorage.setItem(`${LS_PREFIX}${p.kind === 'collection' ? 'c' : 'k'}:${key}`, JSON.stringify(p.value));
  }
}

function flush(): Promise<void> {
  window.clearTimeout(timer);
  timer = undefined;
  const batch = Array.from(pending.entries());
  pending.clear();
  if (batch.length === 0) return chain;

  chain = chain.then(async () => {
    let failed = false;
    for (const [key, p] of batch) {
      try {
        await writeOne(key, p);
      } catch (err) {
        failed = true;
        console.error(`Failed to save "${key}"`, err);
        // أعد الجدولة إلا إذا وصلت نسخة أحدث لنفس المفتاح
        if (!pending.has(key)) pending.set(key, p);
      }
    }
    emitError(failed);
    if (failed) timer = window.setTimeout(() => void flush(), RETRY_MS);
  });
  return chain;
}

function schedule(key: string, value: unknown) {
  // نُبقي اللقطة محدَّثة: أي مكوّن يُعاد تركيبه لاحقاً (تنقّل بين الشاشات) يقرأ آخر قيمة وليس قيمة بدء التشغيل
  if (Array.isArray(value)) snapshot.collections[key] = value;
  else snapshot.kv[key] = value;
  pending.set(key, { kind: Array.isArray(value) ? 'collection' : 'kv', value });
  window.clearTimeout(timer);
  timer = window.setTimeout(() => void flush(), DEBOUNCE_MS);
}

/** يحفظ كل ما هو معلّق فوراً (قبل تثبيت تحديث مثلاً) */
export function flushNow(): Promise<void> {
  return flush();
}

/** حفظ متزامن عند إغلاق النافذة كي لا يضيع آخر تعديل */
function flushSync() {
  const api = window.ledger;
  if (pending.size === 0) return;
  for (const [key, p] of Array.from(pending.entries())) {
    try {
      if (api) {
        if (p.kind === 'collection') writeCollectionSync(key, p.value as unknown[]);
        else api.db.saveKvSync(key, p.value);
      } else {
        localStorage.setItem(`${LS_PREFIX}${p.kind === 'collection' ? 'c' : 'k'}:${key}`, JSON.stringify(p.value));
      }
      pending.delete(key);
    } catch (e) {
      console.error('flushSync failed', e);
    }
  }
}
window.addEventListener('beforeunload', flushSync);
window.addEventListener('pagehide', flushSync);

/* ------------------------------------------------------------------ *
 * الـ Hook: بديل useState يحفظ في SQLite تلقائياً
 *   - المصفوفات (أصناف، فواتير، عملاء...) → جدول records
 *   - غيرها (إعدادات، تفضيلات) → جدول kv
 * ------------------------------------------------------------------ */
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

export function usePersistentState<T>(key: string, initial: T | (() => T)): [T, Dispatch<SetStateAction<T>>] {
  const [value, setValue] = useState<T>(() => {
    const init = typeof initial === 'function' ? (initial as () => T)() : initial;

    if (Array.isArray(init)) {
      return key in snapshot.collections ? (snapshot.collections[key] as T) : init;
    }
    if (key in snapshot.kv) {
      const saved = snapshot.kv[key];
      // دمج سطحي: الحقول الجديدة التي تضيفها التحديثات تأخذ قيمها الافتراضية
      if (isPlainObject(init) && isPlainObject(saved)) return { ...init, ...saved } as T;
      return saved as T;
    }
    return init;
  });

  useEffect(() => {
    schedule(key, value);
  }, [key, value]);

  return [value, setValue];
}
