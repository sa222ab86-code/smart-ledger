import { useEffect, useState, type Dispatch, type SetStateAction } from 'react';

/* ------------------------------------------------------------------ *
 * واجهة الجسر (preload) — موجودة فقط داخل Electron
 * ------------------------------------------------------------------ */
export interface UpdateState {
  status: 'idle' | 'checking' | 'available' | 'downloading' | 'downloaded' | 'not-available' | 'error';
  version: string;
  newVersion?: string;
  percent?: number;
  manual?: boolean;
  error?: string;
}

export interface LedgerApi {
  isElectron: true;
  db: {
    loadAll(): Promise<Snapshot>;
    saveCollection(name: string, items: unknown[]): Promise<boolean>;
    saveKv(key: string, value: unknown): Promise<boolean>;
    saveCollectionSync(name: string, items: unknown[]): boolean;
    saveKvSync(key: string, value: unknown): boolean;
  };
  app: { getVersion(): Promise<string> };
  update: {
    getState(): Promise<UpdateState>;
    check(): Promise<void>;
    install(): Promise<void>;
    onStatus(cb: (s: UpdateState) => void): () => void;
  };
}

declare global {
  interface Window {
    ledger?: LedgerApi;
  }
}

interface Snapshot {
  collections: Record<string, unknown[]>;
  kv: Record<string, unknown>;
}

type Pending = { kind: 'collection' | 'kv'; value: unknown };

/* ------------------------------------------------------------------ *
 * الحالة الداخلية
 * ------------------------------------------------------------------ */
const DEBOUNCE_MS = 300;
const RETRY_MS = 2000;
const LS_PREFIX = 'ledger:';

let snapshot: Snapshot = { collections: {}, kv: {} };
const pending = new Map<string, Pending>();
let timer: number | undefined;
let chain: Promise<void> = Promise.resolve();
const errorListeners = new Set<(hasError: boolean) => void>();

export function onSaveError(cb: (hasError: boolean) => void): () => void {
  errorListeners.add(cb);
  return () => errorListeners.delete(cb);
}
const emitError = (v: boolean) => errorListeners.forEach((cb) => cb(v));

/* ------------------------------------------------------------------ *
 * التحميل الأولي — يُستدعى مرة واحدة قبل رسم التطبيق
 * ------------------------------------------------------------------ */
export async function hydrate(): Promise<void> {
  if (window.ledger) {
    // إن فشل التحميل نرمي الخطأ: لا نبدأ بالبيانات الابتدائية كي لا نكتب فوق بيانات حقيقية
    snapshot = await window.ledger.db.loadAll();
    return;
  }
  // وضع المتصفح (التطوير بدون Electron): localStorage
  const next: Snapshot = { collections: {}, kv: {} };
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith(LS_PREFIX)) continue;
      const raw = localStorage.getItem(k);
      if (raw == null) continue;
      const rest = k.slice(LS_PREFIX.length);
      if (rest.startsWith('c:')) next.collections[rest.slice(2)] = JSON.parse(raw);
      else if (rest.startsWith('k:')) next.kv[rest.slice(2)] = JSON.parse(raw);
    }
  } catch (e) {
    console.warn('localStorage read failed', e);
  }
  snapshot = next;
}

/* ------------------------------------------------------------------ *
 * الحفظ
 * ------------------------------------------------------------------ */
async function writeOne(key: string, p: Pending): Promise<void> {
  const api = window.ledger;
  if (api) {
    if (p.kind === 'collection') await api.db.saveCollection(key, p.value as unknown[]);
    else await api.db.saveKv(key, p.value);
  } else {
    localStorage.setItem(`${LS_PREFIX}${p.kind === 'collection' ? 'c' : 'k'}:${key}`, JSON.stringify(p.value));
  }
}

function flush(): Promise<void> {
  window.clearTimeout(timer);
  timer = undefined;
  const batch = Array.from(pending.entries());
  pending.clear();
  if (batch.length === 0) return chain;

  chain = chain.then(async () => {
    let failed = false;
    for (const [key, p] of batch) {
      try {
        await writeOne(key, p);
      } catch (err) {
        failed = true;
        console.error(`Failed to save "${key}"`, err);
        // أعد الجدولة إلا إذا وصلت نسخة أحدث لنفس المفتاح
        if (!pending.has(key)) pending.set(key, p);
      }
    }
    emitError(failed);
    if (failed) timer = window.setTimeout(() => void flush(), RETRY_MS);
  });
  return chain;
}

function schedule(key: string, value: unknown) {
  pending.set(key, { kind: Array.isArray(value) ? 'collection' : 'kv', value });
  window.clearTimeout(timer);
  timer = window.setTimeout(() => void flush(), DEBOUNCE_MS);
}

/** يحفظ كل ما هو معلّق فوراً (قبل تثبيت تحديث مثلاً) */
export function flushNow(): Promise<void> {
  return flush();
}

/** حفظ متزامن عند إغلاق النافذة كي لا يضيع آخر تعديل */
function flushSync() {
  const api = window.ledger;
  if (pending.size === 0) return;
  for (const [key, p] of Array.from(pending.entries())) {
    try {
      if (api) {
        if (p.kind === 'collection') api.db.saveCollectionSync(key, p.value as unknown[]);
        else api.db.saveKvSync(key, p.value);
      } else {
        localStorage.setItem(`${LS_PREFIX}${p.kind === 'collection' ? 'c' : 'k'}:${key}`, JSON.stringify(p.value));
      }
      pending.delete(key);
    } catch (e) {
      console.error('flushSync failed', e);
    }
  }
}
window.addEventListener('beforeunload', flushSync);
window.addEventListener('pagehide', flushSync);

/* ------------------------------------------------------------------ *
 * الـ Hook: بديل useState يحفظ في SQLite تلقائياً
 *   - المصفوفات (أصناف، فواتير، عملاء...) → جدول records
 *   - غيرها (إعدادات، تفضيلات) → جدول kv
 * ------------------------------------------------------------------ */
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

export function usePersistentState<T>(key: string, initial: T | (() => T)): [T, Dispatch<SetStateAction<T>>] {
  const [value, setValue] = useState<T>(() => {
    const init = typeof initial === 'function' ? (initial as () => T)() : initial;

    if (Array.isArray(init)) {
      return key in snapshot.collections ? (snapshot.collections[key] as T) : init;
    }
    if (key in snapshot.kv) {
      const saved = snapshot.kv[key];
      // دمج سطحي: الحقول الجديدة التي تضيفها التحديثات تأخذ قيمها الافتراضية
      if (isPlainObject(init) && isPlainObject(saved)) return { ...init, ...saved } as T;
      return saved as T;
    }
    return init;
  });

  useEffect(() => {
    schedule(key, value);
  }, [key, value]);

  return [value, setValue];
}
