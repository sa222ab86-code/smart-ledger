import type { OsPrinter } from '../storage/persistence';

export interface PrintSettings {
  /** طباعة صامتة (بدون نافذة اختيار الطابعة) — تعمل في النسخة المكتبية فقط */
  silent: boolean;
  /** طابعة الإيصالات الافتراضية (اسمها في ويندوز). فارغ = طابعة النظام الافتراضية */
  receiptPrinter: string;
  /** طابعة A4 (الفواتير الكبيرة والتقارير). فارغ = نفس طابعة الإيصالات */
  a4Printer: string;
  /** طابعة ملصقات الباركود. فارغ = طابعة النظام الافتراضية */
  labelPrinter: string;
  /** عدد نسخ الإيصال */
  copies: number;
  /** طباعة تذاكر المطبخ/الأقسام تلقائياً عند البيع (وضع المطعم) */
  autoKitchenTickets: boolean;
}

export const defaultPrintSettings: PrintSettings = {
  silent: false,
  receiptPrinter: '',
  a4Printer: '',
  labelPrinter: '',
  copies: 1,
  autoKitchenTickets: true,
};

export const isElectron = () => typeof window !== 'undefined' && !!window.ledger;

export async function listOsPrinters(): Promise<OsPrinter[]> {
  if (!window.ledger) return [];
  try {
    return await window.ledger.print.list();
  } catch (e) {
    console.error('listOsPrinters failed', e);
    return [];
  }
}

export interface PrintResult { ok: boolean; reason?: string }

/** يطبع الصفحة الحالية (الإيصال الظاهر بقواعد @media print). */
export async function printCurrentPage(
  settings: PrintSettings,
  opts: { template: 'thermal80' | 'A4'; deviceName?: string }
): Promise<PrintResult> {
  const api = window.ledger;
  if (!api) {
    window.print();
    return { ok: true };
  }
  const deviceName =
    opts.deviceName || (opts.template === 'A4' ? settings.a4Printer || settings.receiptPrinter : settings.receiptPrinter) || undefined;
  return api.print.page({
    silent: settings.silent,
    deviceName,
    pageSize: opts.template === 'A4' ? 'A4' : 'thermal',
    copies: settings.copies,
  });
}

/** يطبع مستنداً HTML جاهزاً (تذكرة مطبخ، تقرير...) */
export async function printHtmlDocument(
  html: string,
  opts: { silent?: boolean; deviceName?: string; pageSize?: 'A4' | 'thermal'; pageSizeMm?: { width: number; height: number }; copies?: number; landscape?: boolean }
): Promise<PrintResult> {
  const api = window.ledger;
  if (api) return api.print.html({ html, ...opts });
  // المتصفح: نافذة جديدة ثم طباعة
  const w = window.open('', '_blank', 'width=900,height=700');
  if (!w) return { ok: false, reason: 'blocked' };
  w.document.open();
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => { try { w.print(); } catch { /* تجاهل */ } }, 300);
  return { ok: true };
}

export async function exportHtmlAsPdf(html: string, defaultName: string, landscape = false): Promise<boolean> {
  const api = window.ledger;
  if (!api) {
    // المتصفح: يفتح نافذة الطباعة ويختار المستخدم "حفظ كـ PDF"
    await printHtmlDocument(html, { pageSize: 'A4', landscape });
    return true;
  }
  const res = await api.print.pdf({ html, defaultName, landscape });
  return !!res.ok;
}

/* ---------------- تذكرة المطبخ ---------------- */

const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

export interface KitchenTicket {
  title: string;               // اسم الطابعة/القسم
  invoiceNumber: string;
  orderNumber?: number;
  orderType?: string;
  date: string;
  items: { name: string; qty: number }[];
}

export function kitchenTicketHtml(t: KitchenTicket): string {
  const orderTypeAr: Record<string, string> = { dine_in: 'محلي', takeaway: 'سفري', delivery: 'توصيل' };
  const rows = t.items
    .map((i) => `<div class="row"><span class="q">${esc(i.qty)} ×</span><span class="n">${esc(i.name)}</span></div>`)
    .join('');
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<style>
  @page { margin: 2mm; }
  body { font-family: Tahoma, Arial, sans-serif; margin: 0; padding: 4px; color: #000; width: 100%; }
  h1 { font-size: 20px; text-align: center; margin: 0 0 4px; }
  .meta { text-align: center; font-size: 13px; border-bottom: 2px dashed #000; padding-bottom: 6px; margin-bottom: 6px; }
  .big { font-size: 28px; font-weight: 900; }
  .row { display: flex; gap: 8px; font-size: 18px; font-weight: 800; padding: 3px 0; border-bottom: 1px dotted #888; }
  .q { min-width: 44px; }
</style></head><body>
  <h1>${esc(t.title)}</h1>
  <div class="meta">
    ${t.orderNumber != null ? `<div class="big">#${esc(t.orderNumber)}</div>` : ''}
    <div>${esc(t.invoiceNumber)} ${t.orderType ? '— ' + esc(orderTypeAr[t.orderType] || t.orderType) : ''}</div>
    <div>${esc(t.date)}</div>
  </div>
  ${rows}
</body></html>`;
}
