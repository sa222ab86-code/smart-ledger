/**
 * أيقونة البرنامج القابلة للتغيير من الإعدادات.
 *  - default: أيقونة «الدفتر الذكي»
 *  - logo: شعار المنشأة من إعدادات المنشأة
 *  - custom: صورة يرفعها المستخدم (تُحفظ PNG مربعة 256×256)
 */
export interface AppIconSetting {
  mode: 'default' | 'logo' | 'custom';
  custom?: string;
}
export const defaultAppIconSetting: AppIconSetting = { mode: 'default' };

/** يحوّل أي صورة (PNG/JPG/SVG/WebP) إلى PNG مربعة: تُوضع كاملة في المنتصف بلا قص */
export function toSquarePng(src: string, size = 256): Promise<string | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = size; c.height = size;
        const ctx = c.getContext('2d')!;
        const w = img.naturalWidth || size, h = img.naturalHeight || size;
        const scale = Math.min(size / w, size / h);
        const dw = w * scale, dh = h * scale;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, (size - dw) / 2, (size - dh) / 2, dw, dh);
        resolve(c.toDataURL('image/png'));
      } catch {
        resolve(null); // صورة من موقع خارجي تمنع القراءة
      }
    };
    img.onerror = () => resolve(null);
    img.src = src;
  });
}
