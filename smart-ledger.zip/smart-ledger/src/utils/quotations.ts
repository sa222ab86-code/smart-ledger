import type { Quotation, QuotationItem, QuotationStatus } from '../types';
import { round2 } from './invoiceMath';

export const STATUS_LABEL: Record<QuotationStatus, string> = {
  draft: 'مسودة',
  sent: 'مُرسل للعميل',
  accepted: 'مقبول',
  rejected: 'مرفوض',
  invoiced: 'حُوِّل إلى فاتورة',
};

export const DEFAULT_TERMS =
  'الأسعار المذكورة لا تشمل أي رسوم إضافية غير مذكورة. العرض صالح حتى التاريخ المحدد أعلاه، وقابل للتعديل بعد انتهائه.';

export interface QuotationTotals {
  rawSubtotal: number;
  discount: number;
  subtotal: number;
  tax: number;
  total: number;
}

/** الأسعار قبل الضريبة؛ الخصم يُطبَّق قبل الضريبة (مثل منطق الكاشير) */
export function calcQuotation(
  items: QuotationItem[],
  discountType: 'fixed' | 'percent',
  discountValue: number,
  taxRatePercent: number
): QuotationTotals {
  const raw = round2(items.reduce((s, i) => s + (Number(i.price) || 0) * (Number(i.qty) || 0), 0));
  const want = discountType === 'percent' ? (raw * (Number(discountValue) || 0)) / 100 : Number(discountValue) || 0;
  const discount = round2(Math.min(Math.max(0, want), raw));
  const subtotal = round2(raw - discount);
  const tax = round2(subtotal * ((Number(taxRatePercent) || 0) / 100));
  return { rawSubtotal: raw, discount, subtotal, tax, total: round2(subtotal + tax) };
}

export const todayYmd = (d: Date = new Date()) => {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

export const addDaysYmd = (days: number) => todayYmd(new Date(Date.now() + days * 86400000));

/** منتهي الصلاحية: لم يُقبل ولم يُحوَّل وتجاوز تاريخ الصلاحية */
export function isExpired(q: Quotation): boolean {
  return (q.status === 'draft' || q.status === 'sent') && !!q.validUntil && q.validUntil < todayYmd();
}

export function nextQuotationNumber(all: Quotation[]): string {
  const max = all.reduce((m, q) => {
    const n = parseInt((q.number || '').replace(/\D/g, ''), 10);
    return Number.isFinite(n) && n > m ? n : m;
  }, 0);
  return `QT-${String(max + 1).padStart(4, '0')}`;
}

const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const money = (n: number) => (Number.isFinite(n) ? n.toFixed(2) : '0.00');

export function quotationHtml(
  q: Quotation,
  company: { name: string; vat: string; address?: string; phone?: string; mobile?: string; logoUrl?: string }
): string {
  const rows = q.items
    .map(
      (it, i) => `<tr>
        <td>${i + 1}</td>
        <td class="name">${esc(it.name)}</td>
        <td>${esc(it.qty)}</td>
        <td>${money(it.price)}</td>
        <td>${money(it.price * it.qty)}</td>
      </tr>`
    )
    .join('');
  const contact = [company.phone, company.mobile].filter(Boolean).join(' — ');
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(q.number)}</title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: Tahoma, Arial, sans-serif; color: #0f172a; margin: 0; font-size: 13px; }
  .top { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #0e7490; padding-bottom: 10px; }
  .co { display: flex; gap: 12px; align-items: center; }
  .co img { max-height: 70px; max-width: 120px; object-fit: contain; }
  .co h2 { margin: 0; font-size: 20px; }
  .co small { display: block; color: #475569; margin-top: 2px; }
  .title { text-align: left; }
  .title h1 { margin: 0; font-size: 26px; color: #0e7490; }
  .title div { margin-top: 3px; color: #334155; }
  .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 14px 0; }
  .box { border: 1px solid #cbd5e1; border-radius: 8px; padding: 9px 12px; }
  .box b { display: block; color: #475569; font-size: 11px; margin-bottom: 3px; }
  table { width: 100%; border-collapse: collapse; margin-top: 6px; }
  th { background: #0e7490; color: #fff; padding: 8px 6px; font-size: 12px; }
  td { padding: 7px 6px; border-bottom: 1px solid #e2e8f0; text-align: center; }
  td.name { text-align: right; }
  tr:nth-child(even) td { background: #f8fafc; }
  .totals { width: 46%; margin: 14px 0 0 auto; }
  .totals div { display: flex; justify-content: space-between; padding: 5px 10px; border-bottom: 1px solid #e2e8f0; }
  .totals .grand { background: #e0f2fe; border-top: 2px solid #0e7490; font-weight: 800; font-size: 15px; }
  .notes { margin-top: 16px; font-size: 12px; }
  .notes h4 { margin: 0 0 4px; color: #0e7490; }
  .sign { display: flex; justify-content: space-between; margin-top: 46px; font-size: 12px; color: #475569; }
  .sign div { width: 40%; border-top: 1px solid #94a3b8; padding-top: 5px; text-align: center; }
  .foot { margin-top: 18px; text-align: center; color: #64748b; font-size: 10px; }
</style></head><body>
<div class="top">
  <div class="co">
    ${company.logoUrl ? `<img src="${esc(company.logoUrl)}" alt="">` : ''}
    <div>
      <h2>${esc(company.name || '')}</h2>
      ${company.vat ? `<small>الرقم الضريبي: ${esc(company.vat)}</small>` : ''}
      ${company.address ? `<small>${esc(company.address)}</small>` : ''}
      ${contact ? `<small>${esc(contact)}</small>` : ''}
    </div>
  </div>
  <div class="title">
    <h1>عرض سعر</h1>
    <div>رقم العرض: <b>${esc(q.number)}</b></div>
    <div>تاريخ الإصدار: ${esc((q.date || '').slice(0, 10))}</div>
    <div>صالح حتى: <b>${esc(q.validUntil)}</b></div>
  </div>
</div>
<div class="meta">
  <div class="box"><b>السادة / العميل</b>${esc(q.customerName || '—')}</div>
  <div class="box"><b>الجوال</b>${esc(q.customerPhone || '—')}</div>
</div>
<table>
  <thead><tr><th style="width:36px">#</th><th>البيان</th><th style="width:70px">الكمية</th><th style="width:100px">سعر الوحدة</th><th style="width:110px">الإجمالي</th></tr></thead>
  <tbody>${rows}</tbody>
</table>
<div class="totals">
  <div><span>الإجمالي قبل الخصم</span><span>${money(q.rawSubtotal)}</span></div>
  ${q.discount > 0 ? `<div><span>الخصم${q.discountType === 'percent' ? ` (${esc(q.discountValue)}%)` : ''}</span><span>- ${money(q.discount)}</span></div>` : ''}
  <div><span>الإجمالي بعد الخصم</span><span>${money(q.subtotal)}</span></div>
  <div><span>ضريبة القيمة المضافة (${esc(q.taxRate)}%)</span><span>${money(q.tax)}</span></div>
  <div class="grand"><span>الإجمالي شامل الضريبة</span><span>${money(q.total)}</span></div>
</div>
${q.notes ? `<div class="notes"><h4>ملاحظات</h4>${esc(q.notes).replace(/\n/g, '<br>')}</div>` : ''}
${q.terms ? `<div class="notes"><h4>الشروط والأحكام</h4>${esc(q.terms).replace(/\n/g, '<br>')}</div>` : ''}
<div class="sign"><div>ختم وتوقيع المنشأة</div><div>موافقة العميل</div></div>
<div class="foot">هذا المستند عرض سعر وليس فاتورة ضريبية.</div>
</body></html>`;
}
