import type { Invoice } from '../types';

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export const isReturnDoc = (inv: Invoice) => inv.docType === 'return';

/** المتبقي على العميل (0 للفاتورة المسددة وللمرتجع) */
export function invoiceRemaining(inv: Invoice): number {
  if (isReturnDoc(inv)) return 0;
  return Math.max(0, round2(inv.remainingAmount ?? 0));
}

/**
 * ما حُصِّل فعلاً من الفاتورة (لا يتجاوز إجماليها حتى لو دفع العميل أكثر وأخذ باقياً).
 * المرتجع: قيمة سالبة = ما رُدّ للعميل فعلاً (بعد استبعاد ما خُصم من مديونيته).
 */
export function invoiceCollected(inv: Invoice): number {
  if (isReturnDoc(inv)) return round2(Math.min(0, inv.total + (inv.debtOffset || 0)));
  return round2(Math.max(0, inv.total - invoiceRemaining(inv)));
}

export function isUnsettled(inv: Invoice): boolean {
  return invoiceRemaining(inv) > 0.004;
}

export const GENERAL_CUSTOMER = 'عميل عام';

/** الاسم المعروض للعميل: الفواتير القديمة المسجلة باسم «عميل نقدي» تظهر الآن «عميل عام» */
export function customerLabel(name?: string): string {
  const n = (name || '').trim();
  return !n || n === 'عميل نقدي' || n === 'نقدي' ? GENERAL_CUSTOMER : n;
}
