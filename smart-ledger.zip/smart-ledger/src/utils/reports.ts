import type { Invoice } from '../types';
import { customerLabel, invoiceCollected, invoiceRemaining, isReturnDoc, round2 } from './invoiceMath';
import { toCsv, type Cell } from './csv';

export type ReportKind = 'daily' | 'monthly' | 'users' | 'tax';

export interface ReportTable {
  kind: ReportKind;
  title: string;
  period: string;
  columns: string[];
  rows: Cell[][];
  totals: Cell[];
  summary: { label: string; value: string }[];
}

const fmt = (n: number) => (Number.isFinite(n) ? n.toFixed(2) : '0.00');
const dayOf = (inv: Invoice) => (inv.date || '').slice(0, 10);

export function filterInvoices(invoices: Invoice[], from: string, to: string): Invoice[] {
  return invoices.filter((inv) => {
    const d = dayOf(inv);
    if (from && d < from) return false;
    if (to && d > to) return false;
    return true;
  });
}

function periodLabel(from: string, to: string): string {
  if (!from && !to) return 'كل الفترات';
  if (from && to) return `من ${from} إلى ${to}`;
  return from ? `من ${from}` : `حتى ${to}`;
}

interface Bucket {
  count: number; subtotal: number; discount: number; tax: number; total: number;
  cash: number; card: number; credit: number;
  returnsCount: number; returns: number;
}
const emptyBucket = (): Bucket => ({ count: 0, subtotal: 0, discount: 0, tax: 0, total: 0, cash: 0, card: 0, credit: 0, returnsCount: 0, returns: 0 });

function addToBucket(b: Bucket, inv: Invoice) {
  const collected = invoiceCollected(inv);
  // المرتجع قيمه سالبة: يُطرح من الإجماليات والضريبة والنقدية، ولا يُحسب كفاتورة
  if (isReturnDoc(inv)) { b.returnsCount += 1; b.returns += Math.abs(inv.total ?? 0); }
  else b.count += 1;
  b.subtotal += inv.subtotal ?? 0;
  b.discount += inv.discount ?? 0;
  b.tax += inv.tax ?? 0;
  b.total += inv.total ?? 0;
  if (inv.paymentMethod === 'card') b.card += collected;
  else b.cash += collected;
  b.credit += invoiceRemaining(inv);
}

function group(invoices: Invoice[], keyOf: (i: Invoice) => string): [string, Bucket][] {
  const map = new Map<string, Bucket>();
  for (const inv of invoices) {
    const k = keyOf(inv) || '—';
    if (!map.has(k)) map.set(k, emptyBucket());
    addToBucket(map.get(k)!, inv);
  }
  return Array.from(map.entries());
}

function summaryOf(invoices: Invoice[]) {
  const t = emptyBucket();
  invoices.forEach((i) => addToBucket(t, i));
  return {
    totals: t,
    summary: [
      { label: 'صافي المبيعات (بعد المرتجعات)', value: fmt(t.total) },
      ...(t.returnsCount ? [{ label: `المرتجعات (${t.returnsCount})`, value: fmt(t.returns) }] : []),
      { label: 'إجمالي الضريبة', value: fmt(t.tax) },
      { label: 'عدد الفواتير', value: String(t.count) },
      { label: 'المبالغ الآجلة (غير المسددة)', value: fmt(t.credit) },
    ],
  };
}

export function buildReport(kind: ReportKind, allInvoices: Invoice[], from: string, to: string): ReportTable {
  const invoices = filterInvoices(allInvoices, from, to);
  const { totals: T, summary } = summaryOf(invoices);
  const period = periodLabel(from, to);

  if (kind === 'tax') {
    const sorted = [...invoices].sort((a, b) => (a.date < b.date ? -1 : 1));
    return {
      kind, period, summary,
      title: 'الإقرار الضريبي للمبيعات',
      columns: ['رقم الفاتورة', 'التاريخ', 'العميل', 'المبلغ الخاضع للضريبة', 'ضريبة القيمة المضافة', 'الإجمالي'],
      rows: sorted.map((i) => [
        i.invoiceNumber || i.number, i.date, customerLabel(i.customerName),
        fmt(i.subtotal ?? 0), fmt(i.tax ?? 0), fmt(i.total ?? 0),
      ]),
      totals: ['الإجمالي', '', `${T.count} فاتورة`, fmt(T.subtotal), fmt(T.tax), fmt(T.total)],
    };
  }

  if (kind === 'users') {
    const rows = group(invoices, (i) => i.cashierName || 'غير محدد').sort((a, b) => b[1].total - a[1].total);
    return {
      kind, period, summary,
      title: 'مبيعات الكاشير والمستخدمين',
      columns: ['المستخدم', 'عدد الفواتير', 'الإجمالي', 'متوسط الفاتورة', 'نقداً', 'شبكة', 'آجل'],
      rows: rows.map(([k, b]) => [k, b.count, fmt(b.total), fmt(b.count ? b.total / b.count : 0), fmt(b.cash), fmt(b.card), fmt(b.credit)]),
      totals: ['الإجمالي', T.count, fmt(T.total), fmt(T.count ? T.total / T.count : 0), fmt(T.cash), fmt(T.card), fmt(T.credit)],
    };
  }

  const isMonthly = kind === 'monthly';
  const rows = group(invoices, (i) => (isMonthly ? dayOf(i).slice(0, 7) : dayOf(i))).sort((a, b) => (a[0] < b[0] ? -1 : 1));
  return {
    kind, period, summary,
    title: isMonthly ? 'إجمالي المبيعات الشهرية' : 'ملخص الحركة اليومية',
    columns: [isMonthly ? 'الشهر' : 'التاريخ', 'عدد الفواتير', 'قبل الضريبة', 'الخصومات', 'الضريبة', 'الإجمالي', 'نقداً', 'شبكة', 'آجل'],
    rows: rows.map(([k, b]) => [k, b.count, fmt(b.subtotal), fmt(b.discount), fmt(b.tax), fmt(b.total), fmt(b.cash), fmt(b.card), fmt(b.credit)]),
    totals: ['الإجمالي', T.count, fmt(T.subtotal), fmt(T.discount), fmt(T.tax), fmt(T.total), fmt(T.cash), fmt(T.card), fmt(T.credit)],
  };
}

export function reportToCsv(r: ReportTable, company: string): string {
  return toCsv([
    [company || 'الدفتر الذكي'],
    [r.title],
    [r.period],
    [],
    r.columns,
    ...r.rows,
    r.totals,
  ]);
}

const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

export function reportToHtml(r: ReportTable, company: { name: string; vat: string; address?: string }): string {
  const head = r.columns.map((c) => `<th>${esc(c)}</th>`).join('');
  const body = r.rows.map((row) => `<tr>${row.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('');
  const foot = `<tr class="tot">${r.totals.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`;
  const cards = r.summary
    .map((s) => `<div class="card"><div class="l">${esc(s.label)}</div><div class="v">${esc(s.value)}</div></div>`)
    .join('');
  const empty = r.rows.length === 0 ? '<p class="empty">لا توجد بيانات في هذه الفترة.</p>' : '';
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(r.title)}</title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: Tahoma, Arial, sans-serif; color: #0f172a; margin: 0; font-size: 12px; }
  header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #0e7490; padding-bottom: 8px; margin-bottom: 12px; }
  header h1 { margin: 0; font-size: 20px; }
  header .co { font-size: 15px; font-weight: 700; }
  header small { color: #475569; display: block; margin-top: 2px; }
  .cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 12px; }
  .card { border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 10px; }
  .card .l { color: #475569; font-size: 11px; }
  .card .v { font-size: 17px; font-weight: 800; direction: ltr; text-align: right; }
  table { width: 100%; border-collapse: collapse; }
  th { background: #0e7490; color: #fff; padding: 6px 5px; font-size: 11px; }
  td { padding: 5px; border-bottom: 1px solid #e2e8f0; text-align: center; }
  tr:nth-child(even) td { background: #f8fafc; }
  tr.tot td { font-weight: 800; background: #e0f2fe; border-top: 2px solid #0e7490; }
  .empty { text-align: center; color: #64748b; padding: 30px; }
  footer { margin-top: 14px; color: #64748b; font-size: 10px; display: flex; justify-content: space-between; }
</style></head><body>
<header>
  <div><h1>${esc(r.title)}</h1><small>الفترة: ${esc(r.period)}</small></div>
  <div style="text-align:left"><div class="co">${esc(company.name || '')}</div>
    ${company.vat ? `<small>الرقم الضريبي: ${esc(company.vat)}</small>` : ''}
    ${company.address ? `<small>${esc(company.address)}</small>` : ''}</div>
</header>
<div class="cards">${cards}</div>
<table><thead><tr>${head}</tr></thead><tbody>${body}${r.rows.length ? foot : ''}</tbody></table>
${empty}
<footer><span>طُبع بتاريخ ${esc(new Date().toLocaleString('ar-SA'))}</span><span>الدفتر الذكي</span></footer>
</body></html>`;
}

export { round2 };
