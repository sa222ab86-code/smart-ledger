import React, { useState, useMemo, useDeferredValue } from 'react';
import { useIncrementalList, LoadMoreSentinel } from '../utils/useIncrementalList';
import { 
  Package, Plus, Search, Tag, DollarSign, Barcode, Trash2, Edit, X, 
  AlertTriangle, AlertCircle, Layers, Boxes, Sparkles, FolderTree, ArrowRight
} from 'lucide-react';
import { Product, ProductGroup, AppPrinter, ProductUnit } from '../types';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';
import ProductGroupsManager, { GROUP_COLOR_OPTIONS } from './ProductGroupsManager';
import ProductBundlesManager from './ProductBundlesManager';
import PackagingEditor, { PACKAGING_PRESETS } from './PackagingEditor';
import ProductImagePicker from './ProductImagePicker';
import ProductsImportExport, { type ProductsImportResult } from './ProductsImportExport';
import BarcodeLabelsDialog from './BarcodeLabelsDialog';
import type { PrintSettings } from '../utils/printing';

interface ProductsManagerProps {
  products: Product[];
  groups?: ProductGroup[];
  printers?: AppPrinter[];
  initialTab?: 'products' | 'groups' | 'bundles';
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (id: string, updated: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
  /** سبب منع الحذف (صنف عليه حركة) أو null */
  getDeleteBlockReason?: (id: string) => string | null;
  /** أسعار البيع شاملة الضريبة؟ (لعنوان حقل السعر فقط) */
  pricesIncludeTax?: boolean;
  onAddGroup?: (group: ProductGroup) => void;
  onUpdateGroup?: (id: string, updated: Partial<ProductGroup>) => void;
  onDeleteGroup?: (id: string, reassignGroupId?: string) => void;
  onImportProducts?: (result: ProductsImportResult) => void;
  notify?: (msg: string) => void;
  barcodePrint?: {
    printSettings: PrintSettings;
    onChangePrintSettings: (updater: (prev: PrintSettings) => PrintSettings) => void;
    companyName: string;
    taxRatePercent?: number;
    pricesIncludeTax?: boolean;
  };
}

export default function ProductsManager({ 
  products, 
  groups = [],
  printers = [],
  initialTab = 'products',
  onAddProduct, 
  onUpdateProduct, 
  onDeleteProduct,
  getDeleteBlockReason,
  pricesIncludeTax,
  onAddGroup,
  onUpdateGroup,
  onDeleteGroup,
  onImportProducts,
  notify,
  barcodePrint
}: ProductsManagerProps) {
  const [barcodeIds, setBarcodeIds] = useState<string[] | null>(null);
  const [activeTab, setActiveTab] = useState<'products' | 'groups' | 'bundles'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Quick Add Group Modal within Product Form
  const [showQuickAddGroupModal, setShowQuickAddGroupModal] = useState(false);
  const [quickGroupNameAr, setQuickGroupNameAr] = useState('');
  const [quickGroupColor, setQuickGroupColor] = useState('#06b6d4');
  
  // Product form fields
  const [nameAr, setNameAr] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [cost, setCost] = useState('');
  const [groupId, setGroupId] = useState(groups[0]?.id || '');
  const [categoryAr, setCategoryAr] = useState(groups[0]?.nameAr || 'وجبات');
  const [stock, setStock] = useState('100');
  const [minStock, setMinStock] = useState('10');
  const [barcode, setBarcode] = useState('');
  const [image, setImage] = useState('');

  // Packaging & Size Units state
  const [hasPackaging, setHasPackaging] = useState(false);
  const [packagingList, setPackagingList] = useState<ProductUnit[]>([]);

  const handleAddPackagingRow = (type: 'size' | 'volume' | 'pack' | 'weight' | 'unit' = 'size') => {
    const currentBasePrice = parseFloat(price) || 0;
    const newRow: ProductUnit = {
      id: `pkg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: '',
      factor: 1,
      price: currentBasePrice,
      barcode: barcode ? `${barcode}-${packagingList.length + 1}` : '',
      unitType: type
    };
    setPackagingList(prev => [...prev, newRow]);
    setHasPackaging(true);
  };

  const handleUpdatePackagingRow = (id: string, updates: Partial<ProductUnit>) => {
    setPackagingList(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const handleRemovePackagingRow = (id: string) => {
    setPackagingList(prev => prev.filter(item => item.id !== id));
  };

  const handleApplyPreset = (presetId: string) => {
    const preset = PACKAGING_PRESETS.find(p => p.id === presetId);
    if (!preset) return;
    const currentBasePrice = parseFloat(price) || 0;
    const generated = preset.generate(currentBasePrice, barcode);
    setPackagingList(generated);
    setHasPackaging(true);
  };

  // Fallback categories list if groups are empty or mixed
  const allCategoryNames = useMemo(() => Array.from(new Set([
    ...groups.map(g => g.nameAr),
    ...products.map(p => p.categoryAr).filter(Boolean)
  ])), [groups, products]);

  // عدّ الأصناف لكل تصنيف وعدد الباقات — مرة واحدة بدل المرور على كل الأصناف لكل زر
  const { categoryCounts, bundleCount } = useMemo(() => {
    const m = new Map<string, number>();
    let bundles = 0;
    for (const p of products) {
      if (p.categoryAr) m.set(p.categoryAr, (m.get(p.categoryAr) || 0) + 1);
      if (p.isBundle) bundles++;
    }
    return { categoryCounts: m, bundleCount: bundles };
  }, [products]);

  const filterCategories = ['الكل', ...allCategoryNames];

  const handleOpenAddProduct = () => {
    setNameAr('');
    setNameEn('');
    setDescription('');
    setPrice('');
    setCost('');
    const defaultGroup = groups[0];
    setGroupId(defaultGroup ? defaultGroup.id : '');
    setCategoryAr(defaultGroup ? defaultGroup.nameAr : (allCategoryNames[0] || 'عام'));
    setStock('100');
    setMinStock('10');
    setBarcode('');
    setImage('');
    setHasPackaging(false);
    setPackagingList([]);
    setShowAddModal(true);
  };

  const handleGroupSelectChange = (newGroupId: string) => {
    setGroupId(newGroupId);
    const grp = groups.find(g => g.id === newGroupId);
    if (grp) {
      setCategoryAr(grp.nameAr);
    }
  };

  const handleQuickAddGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickGroupNameAr.trim() || !onAddGroup) return;

    const newGrp: ProductGroup = {
      id: `grp-${Date.now()}`,
      nameAr: quickGroupNameAr.trim(),
      nameEn: quickGroupNameAr.trim(),
      color: quickGroupColor,
      icon: 'Layers',
      displayOrder: (groups.length + 1),
      isActive: true
    };

    onAddGroup(newGrp);
    setGroupId(newGrp.id);
    setCategoryAr(newGrp.nameAr);
    setQuickGroupNameAr('');
    setShowQuickAddGroupModal(false);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameAr.trim() || !price) return;

    const currentGroup = groups.find(g => g.id === groupId);
    const resolvedCatAr = currentGroup ? currentGroup.nameAr : categoryAr;
    const resolvedCatEn = currentGroup?.nameEn || resolvedCatAr;

    const validUnits = hasPackaging 
      ? packagingList.filter(u => u.name && u.name.trim() !== '')
      : undefined;
    const validVariants = validUnits && validUnits.length > 0
      ? validUnits.map(u => ({ id: u.id, name: u.name, price: u.price }))
      : undefined;

    const newProduct: Product = {
      id: `p${Date.now()}`,
      nameAr: nameAr.trim(),
      nameEn: nameEn.trim() || nameAr.trim(),
      description: description.trim() || undefined,
      price: parseFloat(price),
      cost: parseFloat(cost) || 0,
      categoryAr: resolvedCatAr,
      categoryEn: resolvedCatEn,
      groupId: currentGroup?.id,
      stock: parseInt(stock) || 0,
      minStock: parseInt(minStock) || 10,
      barcode: barcode || Math.floor(Math.random() * 900000 + 100000).toString(),
      image: image || undefined,
      units: validUnits && validUnits.length > 0 ? validUnits : undefined,
      variants: validVariants && validVariants.length > 0 ? validVariants : undefined
    };

    onAddProduct(newProduct);

    // reset forms
    setNameAr('');
    setNameEn('');
    setDescription('');
    setPrice('');
    setCost('');
    setStock('100');
    setMinStock('10');
    setBarcode('');
    setImage('');
    setHasPackaging(false);
    setPackagingList([]);
    setShowAddModal(false);
  };

  const handleEditClick = (product: Product) => {
    setEditingProduct(product);
    setNameAr(product.nameAr);
    setNameEn(product.nameEn);
    setDescription(product.description || '');
    setPrice(product.price.toString());
    setCost(product.cost.toString());
    
    const matchedGroup = groups.find(g => g.id === product.groupId || g.nameAr === product.categoryAr);
    setGroupId(matchedGroup ? matchedGroup.id : '');
    setCategoryAr(product.categoryAr);
    setStock(product.stock.toString());
    setMinStock((product.minStock ?? 10).toString());
    setBarcode(product.barcode);
    setImage(product.image || '');

    // Load packaging & units
    if (product.units && product.units.length > 0) {
      setHasPackaging(true);
      setPackagingList([...product.units]);
    } else if (product.variants && product.variants.length > 0) {
      setHasPackaging(true);
      setPackagingList(product.variants.map((v, idx) => ({
        id: v.id,
        name: v.name,
        factor: 1,
        price: v.price,
        barcode: `${product.barcode}-${idx + 1}`,
        unitType: 'size'
      })));
    } else {
      setHasPackaging(false);
      setPackagingList([]);
    }

    setShowEditModal(true);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !nameAr.trim() || !price) return;

    const currentGroup = groups.find(g => g.id === groupId);
    const resolvedCatAr = currentGroup ? currentGroup.nameAr : categoryAr;
    const resolvedCatEn = currentGroup?.nameEn || resolvedCatAr;

    const validUnits = hasPackaging 
      ? packagingList.filter(u => u.name && u.name.trim() !== '')
      : undefined;
    const validVariants = validUnits && validUnits.length > 0
      ? validUnits.map(u => ({ id: u.id, name: u.name, price: u.price }))
      : undefined;

    onUpdateProduct(editingProduct.id, {
      nameAr: nameAr.trim(),
      nameEn: nameEn.trim() || nameAr.trim(),
      description: description.trim() || undefined,
      price: parseFloat(price),
      cost: parseFloat(cost) || 0,
      categoryAr: resolvedCatAr,
      categoryEn: resolvedCatEn,
      groupId: currentGroup?.id,
      stock: parseInt(stock) || 0,
      minStock: parseInt(minStock) || 10,
      barcode: barcode,
      image: image || undefined,
      units: validUnits && validUnits.length > 0 ? validUnits : undefined,
      variants: validVariants && validVariants.length > 0 ? validVariants : undefined
    });

    setEditingProduct(null);
    setShowEditModal(false);
  };

  const handleDeleteClick = (id: string) => {
    const blocked = getDeleteBlockReason?.(id);
    if (blocked) { alert(blocked); return; }
    if (confirm('هل أنت متأكد من رغبتك في حذف هذا الصنف نهائياً؟')) {
      onDeleteProduct(id);
    }
  };

  const deferredSearch = useDeferredValue(searchQuery);
  const filteredProducts = useMemo(() => {
    const q = deferredSearch.toLowerCase().trim();
    return products.filter(p => {
      const matchesCategory = selectedCategory === 'الكل' || p.categoryAr === selectedCategory;
      if (!matchesCategory) return false;
      return !q ||
        (p.nameAr || '').toLowerCase().includes(q) ||
        (p.nameEn && p.nameEn.toLowerCase().includes(q)) ||
        (p.barcode || '').includes(q);
    });
  }, [products, deferredSearch, selectedCategory]);
  // الجدول يرسم ١٠٠ صف فقط ويحمّل المزيد عند التمرير (كانت نافذة التعديل تهنج لأن الجدول كله يُعاد رسمه مع كل حرف)
  const productsTable = useIncrementalList(filteredProducts, 100, `${deferredSearch}|${selectedCategory}`);

  return (
    <div className="bg-slate-50 dark:bg-slate-950 text-right text-slate-800 dark:text-slate-100 min-h-full flex flex-col" dir="rtl">
      
      {/* Top Navigation Tabs Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 pt-5 pb-0 shrink-0">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
          <div>
            <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2.5">
              <Package className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
              <span>إدارة المنتجات وشؤون الأصناف</span>
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mt-0.5">
              إدارة الكتالوج الشامل، نظام مجموعات الأصناف والتصنيفات، وباقات الكومبو التوفيرية.
            </p>
          </div>

          {activeTab === 'products' && (
            <div className="flex flex-wrap items-center gap-2">
              {onImportProducts && (
                <ProductsImportExport products={products} groups={groups} onImport={onImportProducts} notify={notify} />
              )}
              {barcodePrint && (
                <button onClick={() => setBarcodeIds([])} className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition border text-cyan-600 dark:text-cyan-400 border-cyan-500/20 cursor-pointer">
                  <Barcode className="w-4 h-4" /><span>طباعة باركود</span>
                </button>
              )}
              <button 
                onClick={() => setActiveTab('groups')}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-cyan-600 dark:text-cyan-400 font-bold rounded-xl text-xs flex items-center gap-1.5 transition border border-cyan-500/20 cursor-pointer"
              >
                <FolderTree className="w-4 h-4" />
                <span>إدارة المجموعات ({groups.length})</span>
              </button>

              <button 
                onClick={handleOpenAddProduct}
                className="px-5 py-2.5 bg-gradient-to-l from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-black rounded-xl text-xs sm:text-sm flex items-center gap-1.5 transition shadow-lg shadow-cyan-500/20 cursor-pointer active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة صنف جديد</span>
              </button>
            </div>
          )}
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar border-b border-slate-200 dark:border-slate-800">
          <button
            onClick={() => setActiveTab('products')}
            className={`pb-3 px-4 font-black text-xs sm:text-sm flex items-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'products'
                ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>قائمة الأصناف (المنتجات)</span>
            <span className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[11px] px-2 py-0.5 rounded-full">
              {products.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('groups')}
            className={`pb-3 px-4 font-black text-xs sm:text-sm flex items-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'groups'
                ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>نظام مجموعات الأصناف (Item Groups)</span>
            <span className="bg-cyan-500/20 text-cyan-600 dark:text-cyan-400 font-mono text-[11px] px-2 py-0.5 rounded-full border border-cyan-500/30">
              {groups.length} مجموعات
            </span>
          </button>

          <button
            onClick={() => setActiveTab('bundles')}
            className={`pb-3 px-4 font-black text-xs sm:text-sm flex items-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'bundles'
                ? 'border-purple-500 text-purple-600 dark:text-purple-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <Boxes className="w-4 h-4" />
            <span>الباقات والعروض التجميعية (Combos)</span>
            <span className="bg-purple-500/20 text-purple-600 dark:text-purple-400 font-mono text-[11px] px-2 py-0.5 rounded-full border border-purple-500/30">
              {bundleCount} باقة
            </span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === 'groups' && onAddGroup && onUpdateGroup && onDeleteGroup && (
          <ProductGroupsManager 
            groups={groups}
            products={products}
            printers={printers}
            onAddGroup={onAddGroup}
            onUpdateGroup={onUpdateGroup}
            onDeleteGroup={onDeleteGroup}
            onSelectGroupFilter={(groupName) => {
              setSelectedCategory(groupName);
              setActiveTab('products');
            }}
          />
        )}

        {activeTab === 'bundles' && (
          <ProductBundlesManager 
            products={products}
            groups={groups}
            onAddProduct={onAddProduct}
            onUpdateProduct={onUpdateProduct}
            onDeleteProduct={onDeleteProduct}
            getDeleteBlockReason={getDeleteBlockReason}
          />
        )}

        {activeTab === 'products' && (
          <div className="p-6 space-y-6">
            
            {/* Filter and Search Bar */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <input 
                  type="text" 
                  placeholder="البحث عن صنف بالاسم أو الباركود..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pr-12 pl-4 py-3 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:border-cyan-500 font-bold"
                />
                <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3.5" />
              </div>
              
              {/* Category / Group selector Chips */}
              <div className="flex gap-2 overflow-x-auto pb-1 max-w-full no-scrollbar">
                {filterCategories.map((cat, idx) => {
                  const grp = groups.find(g => g.nameAr === cat);
                  const isSelected = selectedCategory === cat;
                  const groupColor = grp?.color || '#06b6d4';

                  return (
                    <button
                      key={idx}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border cursor-pointer flex items-center gap-1.5 ${
                        isSelected 
                          ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-black shadow-md' 
                          : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {cat !== 'الكل' && (
                        <span 
                          className="w-2.5 h-2.5 rounded-full" 
                          style={{ backgroundColor: isSelected ? '#000' : groupColor }}
                        />
                      )}
                      <span>{cat}</span>
                      {cat !== 'الكل' && (
                        <span className={`text-[10px] font-mono px-1 rounded-full ${isSelected ? 'bg-black/20 text-slate-950 font-black' : 'text-slate-500'}`}>
                          {categoryCounts.get(cat) || 0}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Products Table */}
            <div className="bg-white dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-right text-xs md:text-sm font-bold">
                  <thead>
                    <tr className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-[11px] uppercase tracking-wider">
                      <th className="p-4">الصنف</th>
                      <th className="p-4">المجموعة والتصنيف</th>
                      <th className="p-4 text-center">الباركود</th>
                      <th className="p-4 text-center">سعر البيع</th>
                      <th className="p-4 text-center">التكلفة</th>
                      <th className="p-4 text-center">المخزون</th>
                      <th className="p-4 text-center">التحكم</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200/40 dark:divide-slate-800/40 text-slate-600 dark:text-slate-300">
                    {productsTable.visible.map(product => {
                      const matchedGroup = groups.find(g => g.id === product.groupId || g.nameAr === product.categoryAr);
                      const groupColor = matchedGroup?.color || '#06b6d4';

                      return (
                        <tr key={product.id} className="hover:bg-white/30 dark:hover:bg-slate-900/30 transition-colors">
                          <td className="p-4 flex items-center gap-3">
                            <div 
                              className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border overflow-hidden bg-white dark:bg-slate-900 shadow-xs relative"
                              style={{ 
                                backgroundColor: `${groupColor}15`,
                                borderColor: `${groupColor}40`,
                                color: groupColor 
                              }}
                            >
                              {product.image ? (
                                <img 
                                  src={product.image} 
                                  alt={product.nameAr}
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : product.isBundle ? (
                                <Boxes className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                              ) : (
                                <Package className="w-5 h-5" />
                              )}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-bold text-slate-900 dark:text-white text-sm leading-snug">{product.nameAr}</p>
                                {product.isBundle && (
                                  <span className="bg-purple-500/20 text-purple-600 dark:text-purple-400 border border-purple-500/30 px-2 py-0.2 rounded-md text-[10px] font-black flex items-center gap-1">
                                    <Boxes className="w-3 h-3" />
                                    <span>باقة كومبو</span>
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-slate-500 font-medium font-mono">{product.nameEn}</p>
                              {product.isBundle && product.bundleItems && (
                                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 font-normal">
                                  يشمل: {product.bundleItems.map(bi => `${bi.qty}× ${bi.productName}`).join(' + ')}
                                </p>
                              )}
                              {((product.units && product.units.length > 0) || (product.variants && product.variants.length > 0)) && (
                                <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                                  <span className="text-[9.5px] font-black bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border border-cyan-500/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                                    <Layers className="w-2.5 h-2.5" />
                                    <span>{product.units?.length || product.variants?.length} تعبئات / مقاسات</span>
                                  </span>
                                  {(product.units || product.variants?.map(v => ({ id: v.id, name: v.name, price: v.price })) || []).slice(0, 3).map((u: any) => (
                                    <span key={u.id} className="text-[9.5px] bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 px-1.5 py-0.5 rounded font-mono inline-flex items-center gap-0.5">
                                      <span>{u.name}</span>
                                      <span className="text-cyan-600 dark:text-cyan-400 font-bold">({u.price.toFixed(2)} ﷼)</span>
                                    </span>
                                  ))}
                                  {((product.units?.length || product.variants?.length || 0) > 3) && (
                                    <span className="text-[9.5px] text-slate-500 font-mono">
                                      +{(product.units?.length || product.variants?.length || 0) - 3} أخرى
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <span 
                              className="px-2.5 py-1 rounded-full text-[11px] font-black inline-flex items-center gap-1.5 border"
                              style={{ 
                                backgroundColor: `${groupColor}15`,
                                borderColor: `${groupColor}40`,
                                color: groupColor 
                              }}
                            >
                              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: groupColor }} />
                              <span>{product.categoryAr || 'عام'}</span>
                            </span>
                          </td>
                          <td className="p-4 text-center font-mono text-slate-500">
                            <span className="flex items-center justify-center gap-1">
                              <Barcode className="w-4 h-4 text-slate-400 dark:text-slate-600" />
                              <span>{product.barcode}</span>
                            </span>
                          </td>
                          <td className="p-4 text-center font-mono font-black text-slate-900 dark:text-white text-sm">
                            <span className="inline-flex items-center gap-1">{product.price.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" /></span>
                          </td>
                          <td className="p-4 text-center font-mono text-slate-500 dark:text-slate-400">
                            <span className="inline-flex items-center gap-1">{product.cost.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 text-slate-500" /></span>
                          </td>
                          <td className="p-4 text-center font-mono">
                            {(() => {
                              const threshold = product.minStock !== undefined ? product.minStock : 10;
                              const isOut = product.stock <= 0;
                              const isLow = !isOut && product.stock <= threshold;
                              return (
                                <div className="flex flex-col items-center gap-0.5">
                                  <span className={`px-2.5 py-0.5 rounded-lg text-xs font-black inline-flex items-center gap-1.5 ${
                                    isOut 
                                      ? 'text-rose-600 dark:text-rose-400 bg-rose-950/40 border border-rose-500/40 shadow-sm' 
                                      : isLow 
                                      ? 'text-amber-600 dark:text-amber-400 bg-amber-950/40 border border-amber-500/40 ring-1 ring-amber-400/40 shadow-sm' 
                                      : 'text-emerald-600 dark:text-emerald-400 bg-emerald-950/20'
                                  }`}>
                                    {isLow && <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 fill-current animate-pulse" />}
                                    {isOut && <AlertCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />}
                                    <span>{product.stock} قِطعة</span>
                                  </span>
                                  <span className="text-[10px] text-slate-500 font-mono">
                                    الحد الأدنى: {threshold}
                                  </span>
                                </div>
                              );
                            })()}
                          </td>
                          <td className="p-4 text-center">
                            <div className="flex gap-2 justify-center">
                              {barcodePrint && (
                                <button
                                  onClick={() => setBarcodeIds([product.id])}
                                  className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-cyan-500/20 text-slate-600 dark:text-slate-300 rounded transition border border-slate-300 dark:border-slate-700"
                                  title="طباعة ملصق باركود"
                                >
                                  <Barcode className="w-4 h-4" />
                                </button>
                              )}
                              <button 
                                onClick={() => handleEditClick(product)}
                                className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-cyan-500/20 text-cyan-600 dark:text-cyan-400 rounded transition border border-slate-300 dark:border-slate-700 hover:border-cyan-500/30 cursor-pointer"
                                title="تعديل"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => handleDeleteClick(product.id)}
                                className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded transition border border-slate-300 dark:border-slate-700 hover:border-rose-500/30 cursor-pointer"
                                title="حذف"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <LoadMoreSentinel hasMore={productsTable.hasMore} shown={productsTable.shown} total={productsTable.total} onMore={productsTable.showMore} sentinelRef={productsTable.sentinelRef} />

              {filteredProducts.length === 0 && (
                <div className="p-8 text-center text-slate-500">
                  <Package className="w-10 h-10 mx-auto mb-2 opacity-50" />
                  <p>لا توجد منتجات مطابقة لخيارات البحث أو التصفية الحالية</p>
                </div>
              )}
            </div>

          </div>
        )}
      </div>

      {/* Add Product Modal Overlay */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden text-right">
            <div className="bg-slate-50 dark:bg-slate-950 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <span className="font-black text-lg text-cyan-600 dark:text-cyan-400">إضافة صنف جديد</span>
              <button onClick={() => setShowAddModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition cursor-pointer">✕</button>
            </div>
            
            <form onSubmit={handleAddSubmit} className="p-6 grid grid-cols-2 gap-4 max-h-[85vh] overflow-y-auto">
              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">اسم الصنف باللغة العربية *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: شاي عدني كرك"
                  value={nameAr}
                  onChange={(e) => setNameAr(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">الاسم باللغة الإنجليزية</label>
                <input 
                  type="text" 
                  placeholder="Example: Karak Tea"
                  value={nameEn}
                  onChange={(e) => setNameEn(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold text-left"
                  dir="ltr"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">وصف الصنف (اختياري — يظهر في الفاتورة تحت الاسم)</label>
                <textarea
                  rows={2}
                  maxLength={300}
                  placeholder="مثال: بدون سكر — حجم كبير — ضمان سنة"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-800 dark:text-slate-100 resize-none"
                />
              </div>

              {/* Group / Category Selector with Quick Add */}
              <div className="col-span-2 space-y-1">
                <div className="flex justify-between items-center">
                  <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">مجموعة الصنف والتصنيف *</label>
                  {onAddGroup && (
                    <button
                      type="button"
                      onClick={() => setShowQuickAddGroupModal(true)}
                      className="text-xs text-cyan-600 dark:text-cyan-400 hover:text-cyan-700 dark:hover:text-cyan-300 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+ إضافة مجموعة جديدة</span>
                    </button>
                  )}
                </div>

                <select 
                  value={groupId || categoryAr}
                  onChange={(e) => {
                    const val = e.target.value;
                    const matched = groups.find(g => g.id === val || g.nameAr === val);
                    if (matched) {
                      setGroupId(matched.id);
                      setCategoryAr(matched.nameAr);
                    } else {
                      setCategoryAr(val);
                    }
                  }}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold cursor-pointer"
                >
                  {groups.map(g => (
                    <option key={g.id} value={g.id}>
                      {g.nameAr} {g.nameEn ? `(${g.nameEn})` : ''}
                    </option>
                  ))}
                  {groups.length === 0 && (
                    allCategoryNames.map((cat, idx) => (
                      <option key={idx} value={cat}>{cat}</option>
                    ))
                  )}
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">سعر البيع ({pricesIncludeTax ? 'شامل الضريبة' : 'قبل الضريبة'}) *</label>
                <input 
                  type="number" 
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">تكلفة الصنف</label>
                <input 
                  type="number" 
                  step="0.01"
                  placeholder="0.00"
                  value={cost}
                  onChange={(e) => setCost(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">كمية المخزون الافتتاحية</label>
                <input 
                  type="number" 
                  placeholder="100"
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-amber-600 dark:text-amber-400 text-xs font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>الحد الأدنى للتنبيه</span>
                </label>
                <input 
                  type="number" 
                  placeholder="10"
                  value={minStock}
                  onChange={(e) => setMinStock(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-400 text-amber-200 font-bold font-mono"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">رمز الباركود (Barcode)</label>
                <input 
                  type="text" 
                  placeholder="اختياري - سيتم توليده عشوائياً إذا تُرِك فارغاً"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              {/* قسم صورة المنتج والذكاء الاصطناعي */}
              <ProductImagePicker
                currentImageUrl={image}
                productNameAr={nameAr}
                productNameEn={nameEn}
                categoryNameAr={categoryAr}
                onSelectImage={(url) => setImage(url)}
                onRemoveImage={() => setImage('')}
              />

              {/* نظام التعبئة والمقاسات والأحجام */}
              <PackagingEditor 
                hasPackaging={hasPackaging}
                onToggleHasPackaging={setHasPackaging}
                packagingList={packagingList}
                basePrice={parseFloat(price) || 0}
                baseBarcode={barcode}
                onAddRow={handleAddPackagingRow}
                onUpdateRow={handleUpdatePackagingRow}
                onRemoveRow={handleRemovePackagingRow}
                onApplyPreset={handleApplyPreset}
              />

              <div className="col-span-2 pt-4 flex gap-3">
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-gradient-to-l from-cyan-500 to-blue-600 hover:from-cyan-600 text-white rounded-xl font-bold text-sm transition shadow-lg shadow-cyan-500/20 cursor-pointer"
                >
                  حفظ الصنف
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-bold text-sm transition border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Product Modal Overlay */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden text-right">
            <div className="bg-slate-50 dark:bg-slate-950 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <span className="font-black text-lg text-cyan-600 dark:text-cyan-400">تعديل بيانات الصنف</span>
              <button onClick={() => setShowEditModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition cursor-pointer">✕</button>
            </div>
            
            <form onSubmit={handleEditSubmit} className="p-6 grid grid-cols-2 gap-4 max-h-[85vh] overflow-y-auto">
              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">اسم الصنف باللغة العربية *</label>
                <input 
                  type="text" 
                  required
                  value={nameAr}
                  onChange={(e) => setNameAr(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">الاسم باللغة الإنجليزية</label>
                <input 
                  type="text" 
                  value={nameEn}
                  onChange={(e) => setNameEn(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold text-left"
                  dir="ltr"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">وصف الصنف (اختياري — يظهر في الفاتورة تحت الاسم)</label>
                <textarea
                  rows={2}
                  maxLength={300}
                  placeholder="مثال: بدون سكر — حجم كبير — ضمان سنة"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-800 dark:text-slate-100 resize-none"
                />
              </div>

              {/* Group / Category Selector with Quick Add */}
              <div className="col-span-2 space-y-1">
                <div className="flex justify-between items-center">
                  <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">مجموعة الصنف والتصنيف *</label>
                  {onAddGroup && (
                    <button
                      type="button"
                      onClick={() => setShowQuickAddGroupModal(true)}
                      className="text-xs text-cyan-600 dark:text-cyan-400 hover:text-cyan-700 dark:hover:text-cyan-300 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+ إضافة مجموعة جديدة</span>
                    </button>
                  )}
                </div>

                <select 
                  value={groupId || categoryAr}
                  onChange={(e) => {
                    const val = e.target.value;
                    const matched = groups.find(g => g.id === val || g.nameAr === val);
                    if (matched) {
                      setGroupId(matched.id);
                      setCategoryAr(matched.nameAr);
                    } else {
                      setCategoryAr(val);
                    }
                  }}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold cursor-pointer"
                >
                  {groups.map(g => (
                    <option key={g.id} value={g.id}>
                      {g.nameAr} {g.nameEn ? `(${g.nameEn})` : ''}
                    </option>
                  ))}
                  {groups.length === 0 && (
                    allCategoryNames.map((cat, idx) => (
                      <option key={idx} value={cat}>{cat}</option>
                    ))
                  )}
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">سعر البيع ({pricesIncludeTax ? 'شامل الضريبة' : 'قبل الضريبة'}) *</label>
                <input 
                  type="number" 
                  step="0.01"
                  required
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">تكلفة الصنف</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={cost}
                  onChange={(e) => setCost(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">كمية المخزون</label>
                <input 
                  type="number" 
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-amber-600 dark:text-amber-400 text-xs font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>الحد الأدنى للتنبيه</span>
                </label>
                <input 
                  type="number" 
                  value={minStock}
                  onChange={(e) => setMinStock(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-amber-500/40 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-amber-200 font-bold font-mono"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">رمز الباركود (Barcode)</label>
                <input 
                  type="text" 
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              {/* قسم صورة المنتج والذكاء الاصطناعي */}
              <ProductImagePicker
                currentImageUrl={image}
                productNameAr={nameAr}
                productNameEn={nameEn}
                categoryNameAr={categoryAr}
                onSelectImage={(url) => setImage(url)}
                onRemoveImage={() => setImage('')}
              />

              {/* نظام التعبئة والمقاسات والأحجام */}
              <PackagingEditor 
                hasPackaging={hasPackaging}
                onToggleHasPackaging={setHasPackaging}
                packagingList={packagingList}
                basePrice={parseFloat(price) || 0}
                baseBarcode={barcode}
                onAddRow={handleAddPackagingRow}
                onUpdateRow={handleUpdatePackagingRow}
                onRemoveRow={handleRemovePackagingRow}
                onApplyPreset={handleApplyPreset}
              />

              <div className="col-span-2 pt-4 flex gap-3">
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-gradient-to-l from-cyan-500 to-blue-600 hover:from-cyan-600 text-white rounded-xl font-bold text-sm transition shadow-lg shadow-cyan-500/20 cursor-pointer"
                >
                  تطبيق التعديلات
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-bold text-sm transition border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Add Group Modal (Nested inside Product Form) */}
      {showQuickAddGroupModal && (
        <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 w-full max-w-sm rounded-2xl shadow-2xl p-5 text-right space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 pb-3">
              <span className="font-black text-sm text-cyan-600 dark:text-cyan-400 flex items-center gap-1.5">
                <Layers className="w-4 h-4" />
                <span>إضافة مجموعة أصناف سريعة</span>
              </span>
              <button 
                type="button"
                onClick={() => setShowQuickAddGroupModal(false)}
                className="text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleQuickAddGroupSubmit} className="space-y-3">
              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">اسم المجموعة (بالعربية) *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: مخبوزات طازجة"
                  value={quickGroupNameAr}
                  onChange={(e) => setQuickGroupNameAr(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-cyan-400 font-bold"
                  autoFocus
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-600 dark:text-slate-300 text-xs font-bold">لون المجموعة</label>
                <div className="flex flex-wrap gap-1.5 p-2 bg-white dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  {GROUP_COLOR_OPTIONS.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setQuickGroupColor(c.hex)}
                      className={`w-6 h-6 rounded-md cursor-pointer transition ${
                        quickGroupColor === c.hex ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  إضافة واختيار
                </button>
                <button
                  type="button"
                  onClick={() => setShowQuickAddGroupModal(false)}
                  className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {barcodePrint && barcodeIds !== null && (
        <BarcodeLabelsDialog
          products={products}
          initialIds={barcodeIds}
          companyName={barcodePrint.companyName}
          taxRatePercent={barcodePrint.taxRatePercent}
          pricesIncludeTax={barcodePrint.pricesIncludeTax}
          printSettings={barcodePrint.printSettings}
          onChangePrintSettings={barcodePrint.onChangePrintSettings}
          onUpdateProduct={onUpdateProduct}
          notify={notify ?? (() => {})}
          onClose={() => setBarcodeIds(null)}
        />
      )}
    </div>
  );
}
