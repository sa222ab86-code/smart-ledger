import React from 'react';
import {
  ShoppingBag, Receipt, Building2, Package, Users, LogOut, LayoutDashboard,
  BarChart3, History, LockKeyhole, Truck, FileBox, Printer, Palette, UserCog,
  Settings, Globe, Boxes, Layers, FileText
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  onLogout: () => void;
}

export default function Sidebar({ currentView, onViewChange, onLogout }: SidebarProps) {
  // تجميع عناصر القائمة مع تصنيفات (مجموعات) لتسهيل التنقل
  const menuGroups = [
    {
      label: 'المبيعات',
      items: [
        { id: 'pos', label: 'نقطة البيع POS', icon: <ShoppingBag className="w-5 h-5" /> },
        { id: 'dailyReports', label: 'التقارير اليومية', icon: <BarChart3 className="w-5 h-5" /> },
        { id: 'salesLog', label: 'سجل المبيعات', icon: <History className="w-5 h-5" /> },
        { id: 'dailyClosing', label: 'الإقفال اليومي', icon: <LockKeyhole className="w-5 h-5" /> },
      ],
    },
    {
      label: 'الإدارة',
      items: [
        { id: 'invoices', label: 'الفواتير', icon: <Receipt className="w-5 h-5" /> },
        { id: 'quotations', label: 'عروض الأسعار', icon: <FileText className="w-5 h-5" /> },
        { id: 'products', label: 'المنتجات', icon: <Package className="w-5 h-5" /> },
        { id: 'productGroups', label: 'مجموعات الأصناف', icon: <Layers className="w-5 h-5" /> },
        { id: 'inventory', label: 'إدارة المخزون', icon: <Boxes className="w-5 h-5" /> },
        { id: 'customers', label: 'العملاء', icon: <Users className="w-5 h-5" /> },
        { id: 'suppliers', label: 'الموردين', icon: <Truck className="w-5 h-5" /> },
        { id: 'purchases', label: 'المشتريات', icon: <FileBox className="w-5 h-5" /> },
        { id: 'users', label: 'المستخدمين', icon: <UserCog className="w-5 h-5" /> },
      ],
    },
    {
      label: 'الإعدادات',
      items: [
        { id: 'printers', label: 'الطابعات', icon: <Printer className="w-5 h-5" /> },
        { id: 'settings', label: 'إعدادات المنشأة', icon: <Building2 className="w-5 h-5" /> },
        { id: 'appSettings', label: 'إعدادات التطبيق', icon: <Palette className="w-5 h-5" /> },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 flex flex-col justify-between h-full select-none shrink-0" dir="rtl">
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {menuGroups.map((group, idx) => (
          <div key={idx}>
            <div className="text-xs font-bold text-slate-400 dark:text-slate-500 mb-2 pr-2">
              {group.label}
            </div>
            <div className="space-y-1.5">
              {group.items.map((item) => {
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onViewChange(item.id)}
                    className={`relative w-full text-right px-4 py-2.5 rounded-xl font-bold flex items-center gap-3 transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-cyan-50 text-cyan-800 dark:bg-cyan-900/50 dark:text-cyan-200'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    {isActive && <span aria-hidden className="absolute right-0 top-2 bottom-2 w-1 rounded-l bg-brass-500" />}
                    <span>{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
            {idx < menuGroups.length - 1 && <div className="border-b border-slate-200 dark:border-slate-800 my-3" />}
          </div>
        ))}
      </div>
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
        <button
          onClick={onLogout}
          className="w-full py-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 rounded-xl font-bold flex items-center justify-center gap-2 border border-rose-500/20 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>تسجيل خروج</span>
        </button>
      </div>
    </aside>
  );
}