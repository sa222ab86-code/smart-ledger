import React, { useState, useMemo } from 'react';
import { 
  Package, AlertTriangle, AlertCircle, CheckCircle2, Printer, Search, 
  Filter, ArrowUpDown, TrendingDown, DollarSign, Layers, Plus, Minus,
  RefreshCw, FileText, Building2, Eye, X, Check, Boxes
} from 'lucide-react';
import { CompanySettings, Product } from '../types';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';

interface Variant { id: string; name: string; price: number; }
interface ProductUnit { id: string; name: string; factor: number; price: number; barcode: string; }
interface ExtendedProduct extends Product { variants?: Variant[]; units?: ProductUnit[]; }

interface InventoryManagerProps {
  products: ExtendedProduct[];
  onUpdateStock: (productId: string, newStock: number) => void;
  companySettings: CompanySettings;
}

export default function InventoryManager({
  products,
  onUpdateStock,
  companySettings
}: InventoryManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'low' | 'out' | 'in_stock'>('all');
  const [sortBy, setSortBy] = useState<'stock_asc' | 'stock_desc' | 'name' | 'value_desc'>('stock_asc');
  const [defaultThreshold, setDefaultThreshold] = useState<number>(15);
  
  // Quick stock edit state
  const [editingStockProduct, setEditingStockProduct] = useState<ExtendedProduct | null>(null);
  const [stockAdjustmentQty, setStockAdjustmentQty] = useState<number>(0);
  const [adjustmentReason, setAdjustmentReason] = useState<'purchase' | 'audit' | 'damage' | 'return'>('audit');
  
  // Print Inventory Modal State
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach(p => {
      if (p.categoryAr) set.add(p.categoryAr);
    });
    return ['الكل', ...Array.from(set)];
  }, [products]);

  // Inventory Metrics
  const metrics = useMemo(() => {
    let totalItems = products.length;
    let totalUnits = 0;
    let totalCostValue = 0;
    let totalRetailValue = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;

    products.forEach(p => {
      const stock = p.stock || 0;
      const minStock = p.minStock ?? defaultThreshold;
      const cost = p.cost || (p.price * 0.6); // fallback cost if not specified
      const price = p.price || 0;

      totalUnits += stock;
      totalCostValue += (stock * cost);
      totalRetailValue += (stock * price);

      if (stock === 0) {
        outOfStockCount++;
      } else if (stock <= minStock) {
        lowStockCount++;
      }
    });

    return {
      totalItems,
      totalUnits,
      totalCostValue,
      totalRetailValue,
      lowStockCount,
      outOfStockCount,
      potentialProfit: totalRetailValue - totalCostValue
    };
  }, [products, defaultThreshold]);

  // Filtered and Sorted Products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const minStock = p.minStock ?? defaultThreshold;
      const stock = p.stock || 0;

      // Search match
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch = !query || 
        p.nameAr.toLowerCase().includes(query) || 
        p.nameEn?.toLowerCase().includes(query) || 
        p.barcode.toLowerCase().includes(query) ||
        p.categoryAr.toLowerCase().includes(query);

      // Category match
      const matchesCategory = selectedCategory === 'الكل' || p.categoryAr === selectedCategory;

      // Status match
      let matchesStatus = true;
      if (selectedStatus === 'low') {
        matchesStatus = stock > 0 && stock <= minStock;
      } else if (selectedStatus === 'out') {
        matchesStatus = stock === 0;
      } else if (selectedStatus === 'in_stock') {
        matchesStatus = stock > minStock;
      }

      return matchesSearch && matchesCategory && matchesStatus;
    }).sort((a, b) => {
      const stockA = a.stock || 0;
      const stockB = b.stock || 0;
      const valueA = stockA * (a.cost || a.price * 0.6);
      const valueB = stockB * (b.cost || b.price * 0.6);

      if (sortBy === 'stock_asc') return stockA - stockB;
      if (sortBy === 'stock_desc') return stockB - stockA;
      if (sortBy === 'name') return a.nameAr.localeCompare(b.nameAr);
      if (sortBy === 'value_desc') return valueB - valueA;
      return 0;
    });
  }, [products, searchQuery, selectedCategory, selectedStatus, sortBy, defaultThreshold]);

  // Handle Quick Stepper
  const handleStepStock = (productId: string, delta: number) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    const current = prod.stock || 0;
    const updated = Math.max(0, current + delta);
    onUpdateStock(productId, updated);
  };

  // Handle Modal Stock Save
  const handleSaveStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStockProduct) return;
    const newStock = Math.max(0, stockAdjustmentQty);
    onUpdateStock(editingStockProduct.id, newStock);
    setEditingStockProduct(null);
  };

  // Open modal with pre-filled quantity
  const handleOpenStockEdit = (prod: ExtendedProduct) => {
    setEditingStockProduct(prod);
    setStockAdjustmentQty(prod.stock || 0);
    setAdjustmentReason('audit');
  };

  return (
    <div className="p-4 sm:p-6 bg-slate-950 text-slate-100 min-h-full space-y-6 select-none font-sans" dir="rtl">
      
      {/* 1. Header with Title & Print Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 text-cyan-400 rounded-2xl border border-cyan-500/30">
              <Boxes className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <span>إدارة ومراقبة المخزون</span>
                <span className="text-xs bg-slate-800 text-cyan-400 border border-cyan-500/30 px-2.5 py-0.5 rounded-full font-bold">
                  مستودع حي ومباشر
                </span>
              </h1>
              <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
                متابعة أرصدة الأصناف بدقة، تنبيهات النواقص، وتقارير الجرد المعتمدة للطباعة.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setIsPrintModalOpen(true)}
            className="flex-1 sm:flex-initial px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/15 transition cursor-pointer active:scale-95"
            title="طباعة كشف جرد المستودع"
          >
            <Printer className="w-4.5 h-4.5" />
            <span>طباعة كشف جرد المخزون</span>
          </button>
        </div>
      </div>

      {/* 2. Critical Alert Banner if Low Stock or Out of Stock */}
      {(metrics.lowStockCount > 0 || metrics.outOfStockCount > 0) && (
        <div className="bg-gradient-to-l from-amber-500/15 via-rose-500/10 to-transparent border border-amber-500/40 rounded-2xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl shrink-0">
              <AlertTriangle className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <span>تنبيه نواقص المخزون في المستودع!</span>
                {metrics.outOfStockCount > 0 && (
                  <span className="bg-rose-500 text-white font-mono text-[10px] px-2 py-0.5 rounded-full">
                    {metrics.outOfStockCount} أصناف نفدت بالكامل
                  </span>
                )}
                {metrics.lowStockCount > 0 && (
                  <span className="bg-amber-500 text-slate-950 font-mono text-[10px] px-2 py-0.5 rounded-full">
                    {metrics.lowStockCount} أصناف قاربت على النفاد (أقل من {defaultThreshold})
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-300 mt-0.5">
                يُرجى عمل أوامر شراء جديدة لتغذية المخزون وتفادي توقف عمليات البيع في الكاشير.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSelectedStatus('low')}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition cursor-pointer shadow-sm"
            >
              عرض المنخفض فقط
            </button>
            {metrics.outOfStockCount > 0 && (
              <button
                type="button"
                onClick={() => setSelectedStatus('out')}
                className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg transition cursor-pointer shadow-sm"
              >
                عرض النافذ فقط
              </button>
            )}
            {selectedStatus !== 'all' && (
              <button
                type="button"
                onClick={() => setSelectedStatus('all')}
                className="px-2.5 py-1.5 bg-slate-800 text-slate-300 hover:text-white text-xs font-bold rounded-lg transition cursor-pointer"
              >
                عرض الكل
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. KPI Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-400">إجمالي الأصناف (SKU)</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="font-mono font-black text-2xl text-white">{metrics.totalItems}</span>
            <span className="text-[10px] text-slate-500 font-bold">صنف مسجل</span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-400">إجمالي الوحدات بالمستودع</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="font-mono font-black text-2xl text-cyan-400">{metrics.totalUnits}</span>
            <span className="text-[10px] text-cyan-600 font-bold">قطعة</span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-400">قيمة المخزون (بالتكلفة)</span>
          <div className="mt-2">
            <span className="font-mono font-black text-xl text-emerald-400 block">{metrics.totalCostValue.toFixed(2)}</span>
            <span className="text-[10px] text-slate-500 font-bold flex items-center gap-1 mt-0.5">
              <SaudiRiyalSymbol className="w-3 h-3 text-slate-400" />
              <span>(رأس المال المحجوز)</span>
            </span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-400">القيمة البيعية المتوقعة</span>
          <div className="mt-2">
            <span className="font-mono font-black text-xl text-blue-400 block">{metrics.totalRetailValue.toFixed(2)}</span>
            <span className="text-[10px] text-slate-500 font-bold flex items-center gap-1 mt-0.5">
              <SaudiRiyalSymbol className="w-3 h-3 text-slate-400" />
              <span>(شامل هامش الربح)</span>
            </span>
          </div>
        </div>

        <div className={`border rounded-2xl p-4 flex flex-col justify-between transition-all ${
          metrics.lowStockCount > 0 
            ? 'bg-amber-950/20 border-amber-500/40 text-amber-300' 
            : 'bg-[#0D0D0D] border-slate-800/80 text-slate-400'
        }`}>
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-bold">منخفض المخزون</span>
            {metrics.lowStockCount > 0 && <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className={`font-mono font-black text-2xl ${metrics.lowStockCount > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
              {metrics.lowStockCount}
            </span>
            <span className="text-[10px] font-bold opacity-80">&lt; {defaultThreshold} قطع</span>
          </div>
        </div>

        <div className={`border rounded-2xl p-4 flex flex-col justify-between transition-all ${
          metrics.outOfStockCount > 0 
            ? 'bg-rose-950/20 border-rose-500/40 text-rose-300' 
            : 'bg-[#0D0D0D] border-slate-800/80 text-slate-400'
        }`}>
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-bold">نفد من المخزون</span>
            {metrics.outOfStockCount > 0 && <AlertCircle className="w-3.5 h-3.5 text-rose-400" />}
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className={`font-mono font-black text-2xl ${metrics.outOfStockCount > 0 ? 'text-rose-400' : 'text-slate-400'}`}>
              {metrics.outOfStockCount}
            </span>
            <span className="text-[10px] font-bold opacity-80">0 قطع</span>
          </div>
        </div>
      </div>

      {/* 4. Search and Filter Bar */}
      <div className="bg-[#0D0D0D] border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search input */}
          <div className="relative flex-1">
            <input 
              type="text" 
              placeholder="البحث باسم الصنف، الباركود، أو التصنيف..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-11 pl-4 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 font-bold"
            />
            <Search className="w-4.5 h-4.5 text-slate-500 absolute right-4 top-3" />
            {searchQuery && (
              <button 
                type="button" 
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-2.5 p-1 text-slate-500 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category filter */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
            <Filter className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-xs text-slate-400 font-bold">التصنيف:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent text-sm font-bold text-slate-200 outline-none cursor-pointer"
            >
              {categories.map((cat, idx) => (
                <option key={idx} value={cat} className="bg-slate-900 text-white">{cat}</option>
              ))}
            </select>
          </div>

          {/* Status filter tabs */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl shrink-0 overflow-x-auto">
            <button
              type="button"
              onClick={() => setSelectedStatus('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                selectedStatus === 'all'
                  ? 'bg-cyan-500 text-slate-950 font-black shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل ({products.length})
            </button>
            <button
              type="button"
              onClick={() => setSelectedStatus('low')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1 ${
                selectedStatus === 'low'
                  ? 'bg-amber-500 text-slate-950 font-black shadow-sm'
                  : 'text-amber-400/80 hover:text-amber-300'
              }`}
            >
              <AlertTriangle className="w-3 h-3" />
              <span>منخفض ({metrics.lowStockCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedStatus('out')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1 ${
                selectedStatus === 'out'
                  ? 'bg-rose-500 text-white font-black shadow-sm'
                  : 'text-rose-400/80 hover:text-rose-300'
              }`}
            >
              <AlertCircle className="w-3 h-3" />
              <span>نافذ ({metrics.outOfStockCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedStatus('in_stock')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                selectedStatus === 'in_stock'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              متوفر
            </button>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
            <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
            <span className="text-xs text-slate-400 font-bold">الترتيب:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-xs font-bold text-slate-200 outline-none cursor-pointer"
            >
              <option value="stock_asc" className="bg-slate-900 text-white">الأقل كمية أولاً (الأولوية)</option>
              <option value="stock_desc" className="bg-slate-900 text-white">الأكثر كمية أولاً</option>
              <option value="name" className="bg-slate-900 text-white">الاسم أبجدياً</option>
              <option value="value_desc" className="bg-slate-900 text-white">الأعلى قيمة مخزون</option>
            </select>
          </div>
        </div>

        {/* Global Alert Threshold config */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/60 font-bold">
          <div className="flex items-center gap-2">
            <span>حد التنبيه الافتراضي لانخفاض المخزون:</span>
            <input 
              type="number" 
              min="1" 
              max="500"
              value={defaultThreshold}
              onChange={(e) => setDefaultThreshold(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-16 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-center font-mono font-bold text-cyan-400 focus:outline-none focus:border-cyan-500"
            />
            <span>قطعة</span>
          </div>
          <span>المعروض: {filteredProducts.length} من أصل {products.length} صنف</span>
        </div>
      </div>

      {/* 5. Real-Time Stock Table */}
      <div className="bg-[#0D0D0D] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse text-xs">
            <thead>
              <tr className="bg-slate-900/90 text-slate-400 font-black border-b border-slate-800">
                <th className="p-3.5 pr-4">الباركود</th>
                <th className="p-3.5">اسم الصنف</th>
                <th className="p-3.5">التصنيف</th>
                <th className="p-3.5 text-center">سعر التكلفة</th>
                <th className="p-3.5 text-center">سعر البيع</th>
                <th className="p-3.5 text-center">الرصيد الحالي</th>
                <th className="p-3.5 text-center">حالة المخزون</th>
                <th className="p-3.5 text-center">قيمة المخزون</th>
                <th className="p-3.5 text-center pl-4">تعديل سريع</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-bold">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500 font-bold">
                    لا توجد أصناف تطابق معايير البحث والفلترة المحددة
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const stock = p.stock || 0;
                  const minStock = p.minStock ?? defaultThreshold;
                  const cost = p.cost || (p.price * 0.6);
                  const stockValue = stock * cost;
                  const isOutOfStock = stock === 0;
                  const isLowStock = !isOutOfStock && stock <= minStock;

                  return (
                    <tr 
                      key={p.id}
                      className={`hover:bg-slate-900/40 transition-colors ${
                        isOutOfStock 
                          ? 'bg-rose-950/10' 
                          : isLowStock 
                            ? 'bg-amber-950/10' 
                            : ''
                      }`}
                    >
                      {/* Barcode */}
                      <td className="p-3.5 pr-4 font-mono text-slate-400 text-[11px]">
                        {p.barcode || '—'}
                      </td>

                      {/* Name */}
                      <td className="p-3.5 text-white">
                        <div className="font-bold text-sm">{p.nameAr}</div>
                        {p.nameEn && (
                          <div className="text-[11px] text-slate-500 font-normal">{p.nameEn}</div>
                        )}
                      </td>

                      {/* Category */}
                      <td className="p-3.5">
                        <span className="bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-300 text-[11px]">
                          {p.categoryAr}
                        </span>
                      </td>

                      {/* Cost */}
                      <td className="p-3.5 text-center font-mono text-slate-400">
                        <span className="inline-flex items-center gap-1">{cost.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 text-slate-500" /></span>
                      </td>

                      {/* Price */}
                      <td className="p-3.5 text-center font-mono text-slate-200">
                        <span className="inline-flex items-center gap-1">{p.price.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 text-slate-400" /></span>
                      </td>

                      {/* Current Stock */}
                      <td className="p-3.5 text-center">
                        <div className="inline-flex items-center justify-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-xl">
                          <button
                            type="button"
                            onClick={() => handleStepStock(p.id, -1)}
                            disabled={stock <= 0}
                            className="p-1 hover:bg-slate-800 text-rose-400 rounded disabled:opacity-30 cursor-pointer"
                            title="إنقاص وحدة"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          
                          <span className={`font-mono font-black text-sm px-1.5 ${
                            isOutOfStock 
                              ? 'text-rose-500 animate-pulse' 
                              : isLowStock 
                                ? 'text-amber-400' 
                                : 'text-white'
                          }`}>
                            {stock}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleStepStock(p.id, 1)}
                            className="p-1 hover:bg-slate-800 text-emerald-400 rounded cursor-pointer"
                            title="زيادة وحدة"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </td>

                      {/* Stock Status Badge */}
                      <td className="p-3.5 text-center">
                        {isOutOfStock ? (
                          <span className="inline-flex items-center gap-1 bg-rose-500/15 border border-rose-500/30 text-rose-400 px-2.5 py-1 rounded-full text-[10px] font-bold">
                            <AlertCircle className="w-3 h-3 shrink-0" />
                            <span>نفد من المخزون</span>
                          </span>
                        ) : isLowStock ? (
                          <span className="inline-flex items-center gap-1 bg-amber-500/15 border border-amber-500/30 text-amber-400 px-2.5 py-1 rounded-full text-[10px] font-bold">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>منخفض ({stock}/{minStock})</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 px-2.5 py-1 rounded-full text-[10px] font-bold">
                            <CheckCircle2 className="w-3 h-3 shrink-0" />
                            <span>متوفر ({stock})</span>
                          </span>
                        )}
                      </td>

                      {/* Stock Value */}
                      <td className="p-3.5 text-center font-mono text-cyan-400 font-bold">
                        <span className="inline-flex items-center gap-1">{stockValue.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 text-cyan-400" /></span>
                      </td>

                      {/* Quick Action */}
                      <td className="p-3.5 text-center pl-4">
                        <button
                          type="button"
                          onClick={() => handleOpenStockEdit(p)}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition text-xs font-bold border border-slate-700 cursor-pointer"
                          title="تعديل مباشر لرصيد المخزون"
                        >
                          تعديل الرصيد
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 6. Quick Stock Adjustment Modal */}
      {editingStockProduct && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D0D0D] border border-slate-800 rounded-2xl w-full max-w-md p-6 text-slate-100 shadow-2xl relative">
            <div className="flex justify-between items-start border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-black text-base text-white">تعديل رصيد المخزون</h3>
                <p className="text-xs text-slate-400 font-bold mt-0.5">{editingStockProduct.nameAr}</p>
              </div>
              <button 
                type="button"
                onClick={() => setEditingStockProduct(null)}
                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStockAdjustment} className="mt-4 space-y-4">
              <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 text-xs font-bold space-y-1.5">
                <div className="flex justify-between text-slate-400">
                  <span>الرصيد الحالي المسجل:</span>
                  <span className="font-mono text-white text-sm">{editingStockProduct.stock || 0} قطعة</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>الباركود:</span>
                  <span className="font-mono text-cyan-400">{editingStockProduct.barcode}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-300 mb-1">
                  الرصيد الفعلي الجديد *
                </label>
                <input
                  type="number"
                  min="0"
                  value={stockAdjustmentQty}
                  onChange={(e) => setStockAdjustmentQty(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 font-mono font-black text-lg text-white text-center focus:outline-none focus:border-cyan-500"
                  autoFocus
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-black text-slate-300 mb-1">
                  سبب التعديل:
                </label>
                <select
                  value={adjustmentReason}
                  onChange={(e) => setAdjustmentReason(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 outline-none cursor-pointer"
                >
                  <option value="audit">مطابقة جرد مستودع دوري</option>
                  <option value="purchase">استلام شحنة بضاعة جديدة</option>
                  <option value="return">مرتجع مبيعات من عميل</option>
                  <option value="damage">شطب أصناف تالفة أو منتهية</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black rounded-xl text-sm transition cursor-pointer shadow-md shadow-cyan-500/20"
                >
                  حفظ وتحديث الرصيد
                </button>
                <button
                  type="button"
                  onClick={() => setEditingStockProduct(null)}
                  className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-sm transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. Dedicated Printable Inventory List Modal (Warehouse Management Audit) */}
      {isPrintModalOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-black rounded-2xl w-full max-w-4xl p-8 my-auto shadow-2xl relative font-sans text-right" dir="rtl">
            
            {/* Top Toolbar (Hidden during actual print) */}
            <div className="flex justify-between items-center border-b border-gray-200 pb-4 mb-6 print:hidden">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-cyan-600" />
                <h3 className="font-black text-lg text-gray-900">معاينة كشف جرد المستودع والمخزون للطباعة</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-black rounded-xl text-sm flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الآن (Print)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-gray-900 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Document Body */}
            <div className="printable-inventory-sheet space-y-4">
              {/* Header */}
              <div className="flex justify-between items-start border-b-2 border-black pb-4">
                <div className="flex items-center gap-4">
                  {companySettings.logoUrl && (
                    <img 
                      src={companySettings.logoUrl} 
                      alt={companySettings.companyName} 
                      className="h-16 w-auto max-w-[120px] object-contain border border-gray-300 p-0.5 rounded"
                    />
                  )}
                  <div>
                    <h2 className="text-xl font-black text-gray-900">{companySettings.companyName}</h2>
                    <p className="text-xs text-gray-600">{companySettings.address}</p>
                    <p className="text-xs text-gray-600">الرقم الضريبي: {companySettings.vatNumber}</p>
                    <p className="text-xs text-gray-600">الهاتف: {companySettings.phone}</p>
                  </div>
                </div>

                <div className="text-left font-mono text-xs space-y-1" dir="ltr">
                  <span className="inline-block bg-black text-white px-3 py-1 font-bold text-sm uppercase rounded">
                    WAREHOUSE AUDIT REPORT
                  </span>
                  <p>Date: {new Date().toLocaleDateString('ar-SA')}</p>
                  <p>Time: {new Date().toLocaleTimeString('ar-SA')}</p>
                  <p>Total Items: {filteredProducts.length} SKUs</p>
                </div>
              </div>

              {/* Title */}
              <div className="text-center py-2 bg-gray-100 rounded-lg border border-black">
                <h1 className="text-base font-black text-gray-900">
                  كشف جرد ومطابقة أرصدة المستودع (Inventory Stocktake Sheet)
                </h1>
                <p className="text-[11px] text-gray-600 font-bold mt-0.5">
                  قسم إدارة المستودعات وسلاسل الإمداد - مطابقة الرصيد الدفتري مع العد الفعلي
                </p>
              </div>

              {/* Summary KPIs for Warehouse Staff */}
              <div className="grid grid-cols-4 gap-3 border border-black p-3 rounded-lg text-xs font-bold bg-gray-50">
                <div>
                  <span className="text-gray-500 block text-[10px]">إجمالي الأصناف:</span>
                  <span className="font-mono text-sm">{filteredProducts.length} صنف</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px]">إجمالي الرصيد بالنظام:</span>
                  <span className="font-mono text-sm">{filteredProducts.reduce((s, p) => s + (p.stock || 0), 0)} قطعة</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px]">إجمالي القيمة التقديرية (تكلفة):</span>
                  <span className="font-mono text-sm inline-flex items-center gap-1">
                    {filteredProducts.reduce((s, p) => s + ((p.stock || 0) * (p.cost || p.price * 0.6)), 0).toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 text-black" />
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[10px]">أصناف بحاجة لإعادة طلب:</span>
                  <span className="font-mono text-sm text-red-600 font-black">
                    {filteredProducts.filter(p => (p.stock || 0) <= (p.minStock ?? defaultThreshold)).length} صنف
                  </span>
                </div>
              </div>

              {/* Inventory Table */}
              <table className="w-full text-center border-collapse border border-black text-[11px] my-3">
                <thead>
                  <tr className="bg-gray-200 border-b border-black font-black text-black">
                    <th className="border-r border-black p-2 w-8">م</th>
                    <th className="border-r border-black p-2 text-right pr-3">اسم الصنف</th>
                    <th className="border-r border-black p-2">الباركود</th>
                    <th className="border-r border-black p-2">التصنيف</th>
                    <th className="border-r border-black p-2">التكلفة</th>
                    <th className="border-r border-black p-2 bg-yellow-50">رصيد النظام</th>
                    <th className="border-r border-black p-2 bg-white w-20">العد الفعلي</th>
                    <th className="border-r border-black p-2 bg-white w-20">فرق الجرد</th>
                    <th className="border-r border-black p-2">الحالة</th>
                    <th className="p-2">الملاحظات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black font-bold">
                  {filteredProducts.map((p, idx) => {
                    const stock = p.stock || 0;
                    const minStock = p.minStock ?? defaultThreshold;
                    const isOut = stock === 0;
                    const isLow = !isOut && stock <= minStock;

                    return (
                      <tr key={p.id} className="border-b border-gray-400">
                        <td className="border-r border-black p-1.5 font-mono text-[10px]">{idx + 1}</td>
                        <td className="border-r border-black p-1.5 text-right pr-3 font-bold">{p.nameAr}</td>
                        <td className="border-r border-black p-1.5 font-mono text-[10px]">{p.barcode}</td>
                        <td className="border-r border-black p-1.5">{p.categoryAr}</td>
                        <td className="border-r border-black p-1.5 font-mono">{(p.cost || p.price * 0.6).toFixed(2)}</td>
                        <td className="border-r border-black p-1.5 font-mono font-black bg-yellow-50">{stock}</td>
                        
                        {/* Blank Physical Count Box for Manual Warehouse Stocktaking */}
                        <td className="border-r border-black p-1.5 bg-white">
                          <div className="border border-dashed border-gray-400 h-6 rounded flex items-center justify-center"></div>
                        </td>

                        {/* Blank Variance Box */}
                        <td className="border-r border-black p-1.5 bg-white">
                          <div className="border border-dashed border-gray-400 h-6 rounded flex items-center justify-center"></div>
                        </td>

                        {/* Status */}
                        <td className="border-r border-black p-1.5 text-[10px]">
                          {isOut ? (
                            <span className="text-red-700 font-black">نافذ (0)</span>
                          ) : isLow ? (
                            <span className="text-amber-700 font-bold">منخفض ({stock})</span>
                          ) : (
                            <span className="text-green-700">متوفر</span>
                          )}
                        </td>

                        {/* Notes */}
                        <td className="p-1.5">
                          <div className="border-b border-gray-300 h-4"></div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {/* Signatures & Auditor Sign-off */}
              <div className="grid grid-cols-3 gap-6 pt-6 mt-6 border-t-2 border-black text-xs text-center font-bold">
                <div>
                  <p className="text-gray-700">أمين المستودع (القائم بالجرد):</p>
                  <p className="text-gray-400 mt-6 border-b border-dashed border-gray-500 pb-1">الاسم والتوقيع: ............................</p>
                </div>
                <div>
                  <p className="text-gray-700">المحاسب المالي / المدقق:</p>
                  <p className="text-gray-400 mt-6 border-b border-dashed border-gray-500 pb-1">الاسم والتوقيع: ............................</p>
                </div>
                <div>
                  <p className="text-gray-700">اعتماد مدير العمليات / الإدارة:</p>
                  <p className="text-gray-400 mt-6 border-b border-dashed border-gray-500 pb-1">الاسم والختم: ............................</p>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center text-[10px] text-gray-500 pt-4 border-t border-gray-300">
                <p>تم استخراج هذا التقرير آلياً عبر نظام كاشير البدر لإدارة المخزون ونقاط البيع • {new Date().toLocaleString('ar-SA')}</p>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Global Print Styles for Clean Paper Output */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .printable-inventory-sheet, .printable-inventory-sheet * {
            visibility: visible;
          }
          .printable-inventory-sheet {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 10mm;
            background: white !important;
            color: black !important;
          }
          @page {
            size: A4 portrait;
            margin: 10mm;
          }
        }
      `}</style>

    </div>
  );
}
