import { useEffect, useState } from 'react';
import { Printer, PlusCircle, Server, Trash2, RefreshCw, Zap, TestTube2, X } from 'lucide-react';
import type { OsPrinter } from '../storage/persistence';
import {
  isElectron, kitchenTicketHtml, listOsPrinters, printHtmlDocument,
  type PrintSettings,
} from '../utils/printing';

export interface PrinterRow {
  id: string;
  name: string;
  osPrinterName: string;
  type: 'cashier' | 'kitchen' | 'section';
  template: 'thermal80' | 'A4' | 'kitchenTicket';
  status: 'online' | 'offline';
}

interface Props {
  printers: PrinterRow[];
  setPrinters: (updater: (prev: PrinterRow[]) => PrinterRow[]) => void;
  printSettings: PrintSettings;
  setPrintSettings: (updater: (prev: PrintSettings) => PrintSettings) => void;
  notify: (msg: string) => void;
}

const TYPE_LABEL: Record<PrinterRow['type'], string> = { cashier: 'كاشير / إيصال', kitchen: 'مطبخ / تحضير', section: 'قسم / محطة' };

const card = 'bg-white dark:bg-slate-800 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700';
const sel = 'w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm font-bold outline-none';

function OsSelect({ os, electron, value, onChange, emptyLabel }: { os: OsPrinter[]; electron: boolean; value: string; onChange: (v: string) => void; emptyLabel: string }) {
  return os.length > 0 ? (
    <select value={value} onChange={(e) => onChange(e.target.value)} className={sel} dir="ltr">
      <option value="">{emptyLabel}</option>
      {os.map((p) => <option key={p.name} value={p.name}>{p.displayName}{p.isDefault ? '  ★' : ''}</option>)}
      {value && !os.some((p) => p.name === value) && <option value={value}>{value} (غير موجودة حالياً)</option>}
    </select>
  ) : (
    <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={electron ? 'لم يتم العثور على طابعات — اكتب الاسم يدوياً' : 'اسم الطابعة في ويندوز'} className={sel} dir="ltr" />
  );
}

export default function PrintersManager({ printers, setPrinters, printSettings, setPrintSettings, notify }: Props) {
  const [os, setOs] = useState<OsPrinter[]>([]);
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState<{ name: string; osPrinterName: string; type: PrinterRow['type'] }>({ name: '', osPrinterName: '', type: 'cashier' });

  const refresh = async () => {
    setLoading(true);
    setOs(await listOsPrinters());
    setLoading(false);
  };
  useEffect(() => { void refresh(); }, []);

  const electron = isElectron();
  const defaultName = os.find((p) => p.isDefault)?.name;

  const testPrint = async (deviceName: string, title: string) => {
    const html = kitchenTicketHtml({
      title: `اختبار طباعة — ${title}`,
      invoiceNumber: 'TEST-0001',
      date: new Date().toLocaleString('ar-SA'),
      items: [{ name: 'سطر تجريبي للتأكد من الطباعة', qty: 1 }],
    });
    const res = await printHtmlDocument(html, { silent: printSettings.silent, deviceName: deviceName || undefined, pageSize: 'thermal' });
    notify(res.ok ? 'تم إرسال ورقة الاختبار' : `فشل الاختبار${res.reason ? ': ' + res.reason : ''}`);
  };

  const addPrinter = () => {
    const name = form.name.trim() || form.osPrinterName.trim();
    if (!name) { notify('اكتب اسماً للطابعة أو اختر طابعة'); return; }
    setPrinters((prev) => [
      ...prev,
      {
        id: `p-${Date.now()}`,
        name,
        osPrinterName: form.osPrinterName.trim(),
        type: form.type,
        template: form.type === 'cashier' ? 'thermal80' : 'kitchenTicket',
        status: 'online',
      },
    ]);
    setAdding(false);
    setForm({ name: '', osPrinterName: '', type: 'cashier' });
    notify('تم ربط الطابعة');
  };

  const update = (id: string, patch: Partial<PrinterRow>) =>
    setPrinters((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));

  return (
    <div className="p-6 h-full overflow-y-auto flex flex-col gap-5 animate-in fade-in zoom-in-95 max-w-7xl mx-auto dark:text-white text-right">
      <div className="flex items-center justify-between bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-xl"><Printer className="w-8 h-8" /></div>
          <div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white">الطابعات والطباعة الصامتة</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold mt-1">
              {electron ? `طابعات ويندوز المكتشفة: ${os.length}` : 'اكتشاف الطابعات والطباعة الصامتة متاحان في النسخة المكتبية فقط'}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={refresh} disabled={loading} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-700 font-bold text-sm flex items-center gap-2 disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> تحديث القائمة
          </button>
          <button onClick={() => setAdding(true)} className="bg-blue-500 hover:bg-blue-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2"><PlusCircle className="w-5 h-5" /> ربط طابعة</button>
        </div>
      </div>

      {/* إعدادات الطباعة الصامتة */}
      <div className={card}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-black text-lg flex items-center gap-2"><Zap className="w-5 h-5 text-amber-500" /> إعدادات الطباعة الصامتة</h3>
          <label className="flex items-center gap-3 cursor-pointer select-none">
            <span className="text-sm font-bold">{printSettings.silent ? 'مفعّلة' : 'متوقفة'}</span>
            <span
              onClick={() => setPrintSettings((p) => ({ ...p, silent: !p.silent }))}
              className={`w-12 h-6 rounded-full relative transition ${printSettings.silent ? 'bg-emerald-500' : 'bg-slate-400'}`}
            >
              <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-all ${printSettings.silent ? 'right-0.5' : 'right-6'}`} />
            </span>
          </label>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold mb-4">
          عند التفعيل تُطبع الإيصالات مباشرة على الطابعة المحددة دون ظهور نافذة اختيار الطابعة. عند الإيقاف تظهر نافذة الطباعة المعتادة.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">طابعة الإيصالات الافتراضية</label>
            <OsSelect os={os} electron={electron} value={printSettings.receiptPrinter} onChange={(v) => setPrintSettings((p) => ({ ...p, receiptPrinter: v }))} emptyLabel={defaultName ? `طابعة النظام الافتراضية (${defaultName})` : 'طابعة النظام الافتراضية'} />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">طابعة A4 (فواتير كبيرة وتقارير)</label>
            <OsSelect os={os} electron={electron} value={printSettings.a4Printer} onChange={(v) => setPrintSettings((p) => ({ ...p, a4Printer: v }))} emptyLabel="نفس طابعة الإيصالات" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">طابعة ملصقات الباركود</label>
            <OsSelect os={os} electron={electron} value={printSettings.labelPrinter} onChange={(v) => setPrintSettings((p) => ({ ...p, labelPrinter: v }))} emptyLabel="طابعة النظام الافتراضية" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">عدد نسخ الإيصال</label>
            <input
              type="number" min={1} max={10} value={printSettings.copies}
              onChange={(e) => setPrintSettings((p) => ({ ...p, copies: Math.max(1, Math.min(10, Number(e.target.value) || 1)) }))}
              className={sel}
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4">
          <label className="flex items-center gap-2 text-sm font-bold cursor-pointer">
            <input type="checkbox" checked={printSettings.autoKitchenTickets} onChange={(e) => setPrintSettings((p) => ({ ...p, autoKitchenTickets: e.target.checked }))} />
            طباعة تذاكر المطبخ والأقسام تلقائياً عند البيع (وضع المطعم)
          </label>
          <button onClick={() => testPrint(printSettings.receiptPrinter, 'طابعة الإيصالات')} className="px-4 py-2 rounded-xl bg-slate-800 dark:bg-slate-700 text-white text-sm font-bold flex items-center gap-2">
            <TestTube2 className="w-4 h-4" /> ورقة اختبار
          </button>
        </div>
      </div>

      {/* الطابعات المربوطة (مطبخ / أقسام / كاشير) */}
      <div>
        <h3 className="font-black text-lg mb-3">الطابعات المربوطة بالأقسام</h3>
        {printers.length === 0 ? (
          <div className={`${card} text-center text-slate-400 font-bold py-10`}>
            لا توجد طابعات مربوطة. اربط طابعة المطبخ أو الأقسام ثم اختر الطابعة في «مجموعات الأصناف» ليصل كل صنف لطابعته.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {printers.map((p) => (
              <div key={p.id} className={card}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl"><Server className="w-6 h-6 text-blue-500" /></div>
                    <div>
                      <input value={p.name} onChange={(e) => update(p.id, { name: e.target.value })} className="font-black text-base bg-transparent outline-none w-40" />
                      <div className="text-[11px] font-bold text-slate-500">{TYPE_LABEL[p.type]}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => update(p.id, { status: p.status === 'online' ? 'offline' : 'online' })}
                    className={`text-[11px] font-black px-2.5 py-1 rounded-full ${p.status === 'online' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-500'}`}
                  >
                    {p.status === 'online' ? 'تعمل' : 'متوقفة'}
                  </button>
                </div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">طابعة ويندوز</label>
                <OsSelect os={os} electron={electron} value={p.osPrinterName} onChange={(v) => update(p.id, { osPrinterName: v })} emptyLabel="طابعة النظام الافتراضية" />
                <select value={p.type} onChange={(e) => update(p.id, { type: e.target.value as PrinterRow['type'] })} className={`${sel} mt-2`}>
                  {(Object.keys(TYPE_LABEL) as PrinterRow['type'][]).map((t) => <option key={t} value={t}>{TYPE_LABEL[t]}</option>)}
                </select>
                <div className="flex gap-2 mt-3">
                  <button onClick={() => testPrint(p.osPrinterName, p.name)} className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg text-xs font-bold">طباعة اختبار</button>
                  <button
                    onClick={() => { if (window.confirm(`حذف الطابعة "${p.name}"؟`)) setPrinters((prev) => prev.filter((x) => x.id !== p.id)); }}
                    className="px-3 py-2 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-lg"
                  ><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {adding && (
        <div className="fixed inset-0 z-[9998] bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-lg">ربط طابعة جديدة</h3>
              <button onClick={() => setAdding(false)}><X className="w-5 h-5" /></button>
            </div>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="اسم للطابعة (مثال: مطبخ ساخن)" className={sel} />
            <OsSelect os={os} electron={electron} value={form.osPrinterName} onChange={(v) => setForm({ ...form, osPrinterName: v })} emptyLabel="اختر طابعة ويندوز" />
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as PrinterRow['type'] })} className={sel}>
              {(Object.keys(TYPE_LABEL) as PrinterRow['type'][]).map((t) => <option key={t} value={t}>{TYPE_LABEL[t]}</option>)}
            </select>
            <div className="flex gap-2 pt-1">
              <button onClick={() => setAdding(false)} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-sm">إلغاء</button>
              <button onClick={addPrinter} className="flex-1 py-2.5 rounded-xl bg-blue-600 text-white font-black">حفظ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
