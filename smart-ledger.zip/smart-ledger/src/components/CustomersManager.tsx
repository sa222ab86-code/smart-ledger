import React, { useState } from 'react';
import { Users, Plus, Search, Phone, Mail, Award, Trash2, Edit, MapPin } from 'lucide-react';
import { Customer } from '../types';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';
import { CustomerPaymentModal } from './PaymentModals';

interface CustomersManagerProps {
  customers: Customer[];
  onAddCustomer: (customer: Customer) => void;
  onUpdateCustomer: (id: string, updated: Partial<Customer>) => void;
  onDeleteCustomer: (id: string) => void;
  onRecordPayment?: (customerId: string, amount: number, method: 'cash' | 'card') => void;
}

export default function CustomersManager({ 
  customers, 
  onAddCustomer, 
  onUpdateCustomer, 
  onDeleteCustomer,
  onRecordPayment
}: CustomersManagerProps) {
  const [payingCustomer, setPayingCustomer] = useState<Customer | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [vatNumber, setVatNumber] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    const newCustomer: Customer = {
      id: `c${Date.now()}`,
      name,
      phone: phone || '05XXXXXXXX',
      email: email || 'customer@example.com',
      address: address || 'الرياض',
      balance: 0.00,
      vatNumber: vatNumber || undefined
    };

    onAddCustomer(newCustomer);
    
    // reset form
    setName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setVatNumber('');
    setShowAddModal(false);
  };

  const handleEditClick = (customer: Customer) => {
    setEditingCustomer(customer);
    setName(customer.name);
    setPhone(customer.phone);
    setEmail(customer.email);
    setAddress(customer.address || '');
    setVatNumber(customer.vatNumber || '');
    setShowEditModal(true);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer || !name.trim()) return;

    onUpdateCustomer(editingCustomer.id, {
      name,
      phone,
      email,
      address,
      vatNumber: vatNumber || undefined
    });

    setEditingCustomer(null);
    setName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setVatNumber('');
    setShowEditModal(false);
  };

  const handleDeleteClick = (id: string) => {
    if (confirm('هل أنت متأكد من رغبتك في حذف هذا العميل نهائياً؟')) {
      onDeleteCustomer(id);
    }
  };

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery)
  );

  return (
    <div className="p-6 bg-slate-50 dark:bg-slate-950 text-right text-slate-800 dark:text-slate-100 min-h-full space-y-6" dir="rtl">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-amber-600 dark:text-amber-400" />
            <span>إدارة شؤون العملاء</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">عرض جميع عملائك، تتبع الأرصدة وإضافة عملاء جدد لحسابات نقاط البيع.</p>
        </div>
        <button 
          onClick={() => {
            setName('');
            setPhone('');
            setEmail('');
            setAddress('');
            setShowAddModal(true);
          }}
          className="px-5 py-2.5 bg-amber-500 text-slate-950 hover:bg-amber-400 font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-lg shadow-amber-500/10 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>عميل جديد</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <input 
            type="text" 
            placeholder="البحث عن طريق اسم العميل أو رقم الجوال..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pr-12 pl-4 py-3 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:border-amber-400"
          />
          <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3" />
        </div>
      </div>

      {/* Customers List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCustomers.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500 font-bold">
            لا يوجد عملاء مطابقين لعملية البحث
          </div>
        ) : (
          filteredCustomers.map(customer => (
            <div key={customer.id} className="bg-white dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-6 relative overflow-hidden group flex flex-col justify-between">
              {/* Design accents */}
              <div className="absolute top-0 left-0 w-2 h-full bg-amber-500/40"></div>
              
              <div>
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">{customer.name}</h3>
                    <span className="inline-block text-[10px] bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded-md font-bold">
                      مُعرّف: {customer.id}
                    </span>
                  </div>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => handleEditClick(customer)}
                      className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 hover:bg-white dark:hover:bg-slate-900 rounded-lg transition"
                      title="تعديل"
                    >
                      <Edit className="w-4.5 h-4.5" />
                    </button>
                    <button 
                      onClick={() => handleDeleteClick(customer.id)}
                      className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-white dark:hover:bg-slate-900 rounded-lg transition"
                      title="حذف"
                    >
                      <Trash2 className="w-4.5 h-4.5" />
                    </button>
                  </div>
                </div>

                <div className="mt-5 space-y-2.5 text-xs text-slate-500 dark:text-slate-400 font-bold">
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-slate-500" />
                    <span>{customer.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-slate-500" />
                    <span className="font-mono">{customer.email}</span>
                  </div>
                  {customer.address && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-500" />
                      <span>{customer.address}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Balances */}
              <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-sm">
                <span className="font-bold text-slate-500 text-xs">{(customer.balance || 0) < 0 ? 'مديونية على العميل:' : 'الرصيد المالي:'}</span>
                <span className={`font-mono font-black inline-flex items-center gap-1 ${(customer.balance || 0) >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'}`}>
                  {(customer.balance || 0).toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5" />
                </span>
              </div>
              {onRecordPayment && (customer.balance || 0) < -0.004 && (
                <button
                  onClick={() => setPayingCustomer(customer)}
                  className="mt-3 w-full py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 font-black text-xs"
                >
                  تسجيل دفعة سداد
                </button>
              )}
            </div>
          ))
        )}
      </div>

      {/* Add Customer Modal Overlay */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden text-right">
            <div className="bg-slate-50 dark:bg-slate-950 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <span className="font-black text-lg text-amber-600 dark:text-amber-400">إضافة عميل جديد</span>
              <button onClick={() => setShowAddModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition cursor-pointer">✕</button>
            </div>
            
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">اسم العميل بالكامل *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: صالح أحمد المالكي"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">رقم الجوال</label>
                <input 
                  type="text" 
                  placeholder="مثال: 0541234567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">البريد الإلكتروني</label>
                <input 
                  type="email" 
                  placeholder="مثال: customer@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">العنوان الوطني / السكني</label>
                <input 
                  type="text" 
                  placeholder="مثال: الرياض - حي الملقا"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">الرقم الضريبي (VAT)</label>
                <input 
                  type="text" 
                  placeholder="مثال: 310123456780003"
                  value={vatNumber}
                  onChange={(e) => setVatNumber(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-amber-500 text-slate-950 hover:bg-amber-400 rounded-xl font-bold text-sm transition shadow-lg shadow-amber-500/10 cursor-pointer"
                >
                  تأكيد الحفظ
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-bold text-sm transition border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Customer Modal Overlay */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden text-right">
            <div className="bg-slate-50 dark:bg-slate-950 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <span className="font-black text-lg text-cyan-600 dark:text-cyan-400">تعديل بيانات العميل</span>
              <button onClick={() => setShowEditModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition cursor-pointer">✕</button>
            </div>
            
            <form onSubmit={handleEditSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">اسم العميل بالكامل *</label>
                <input 
                  type="text" 
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">رقم الجوال</label>
                <input 
                  type="text" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">البريد الإلكتروني</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">العنوان الوطني / السكني</label>
                <input 
                  type="text" 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 dark:text-slate-400 text-xs font-bold">الرقم الضريبي (VAT)</label>
                <input 
                  type="text" 
                  placeholder="مثال: 310123456780003"
                  value={vatNumber}
                  onChange={(e) => setVatNumber(e.target.value)}
                  className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-400 text-slate-700 dark:text-slate-200 font-bold font-mono"
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-cyan-500 text-slate-950 hover:bg-cyan-400 rounded-xl font-bold text-sm transition shadow-lg shadow-cyan-500/10 cursor-pointer"
                >
                  حفظ التغييرات
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-bold text-sm transition border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {payingCustomer && onRecordPayment && (
        <CustomerPaymentModal
          customer={payingCustomer}
          onClose={() => setPayingCustomer(null)}
          onConfirm={(amount, method) => { onRecordPayment(payingCustomer.id, amount, method); setPayingCustomer(null); }}
        />
      )}
    </div>
  );
}
