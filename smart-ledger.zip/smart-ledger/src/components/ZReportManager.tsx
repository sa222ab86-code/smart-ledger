import React, { useState, useMemo } from 'react';
import { 
  Invoice, CompanySettings, AppUser 
} from '../types';
import { 
  generateZReportTlvBase64, 
  generateZatcaTlvBase64, 
  ZReportData, 
  generateQrDataUrl 
} from '../utils/zatca';
import ZatcaQrCodeViewer from './ZatcaQrCodeViewer';
import { 
  LockKeyhole, Printer, CheckCircle2, ShieldCheck, 
  History, Calendar, Clock, DollarSign, CreditCard, 
  FileText, ArrowRightLeft, Sparkles, RefreshCw, AlertTriangle 
} from 'lucide-react';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';

interface ZReportRecord extends ZReportData {
  id: string;
  closedAt: string;
  closedBy: string;
  base64Payload: string;
}

interface ZReportManagerProps {
  invoices: Invoice[];
  settings: CompanySettings;
  currentUser?: AppUser;
  onPrintZReport?: (record: ZReportRecord) => void;
  onNotify?: (msg: string) => void;
}

export default function ZReportManager({
  invoices,
  settings,
  currentUser,
  onPrintZReport,
  onNotify
}: ZReportManagerProps) {
  // Shift state and history
  const [activeTab, setActiveTab] = useState<'current' | 'history' | 'simulator'>('current');
  const [selectedHistoricalReport, setSelectedHistoricalReport] = useState<ZReportRecord | null>(null);
  
  // Custom simulator form state for testing any ZATCA invoice QR
  const [testSeller, setTestSeller] = useState(settings.companyName || 'مؤسسة كاشير البدر للتجارة');
  const [testVat, setTestVat] = useState(settings.vatNumber || '300000000000003');
  const [testTotal, setTestTotal] = useState('115.00');
  const [testTax, setTestTax] = useState('15.00');
  const [testDate, setTestDate] = useState(new Date().toISOString().slice(0, 19));

  // Past Z-reports archive
  const [pastZReports, setPastZReports] = useState<ZReportRecord[]>([
    {
      id: 'Z-20260701-001',
      reportNumber: 'Z-20260701-001',
      sellerName: settings.companyName,
      vatNumber: settings.vatNumber,
      posTerminalId: 'POS-TERM-01',
      cashierName: 'أحمد علي',
      shiftStart: '2026-07-01T08:00:00',
      shiftEnd: '2026-07-01T16:00:00',
      totalCash: 850.50,
      totalCard: 1420.00,
      subtotal: 1974.35,
      totalVat: 296.15,
      grandTotal: 2270.50,
      invoicesCount: 14,
      closedAt: '2026-07-01 16:05',
      closedBy: 'المدير العام',
      base64Payload: generateZReportTlvBase64({
        reportNumber: 'Z-20260701-001',
        sellerName: settings.companyName,
        vatNumber: settings.vatNumber,
        posTerminalId: 'POS-TERM-01',
        cashierName: 'أحمد علي',
        shiftStart: '2026-07-01T08:00:00',
        shiftEnd: '2026-07-01T16:00:00',
        totalCash: 850.50,
        totalCard: 1420.00,
        subtotal: 1974.35,
        totalVat: 296.15,
        grandTotal: 2270.50,
        invoicesCount: 14
      })
    }
  ]);

  // Current Shift live calculations
  const shiftMetrics = useMemo(() => {
    const totalCash = invoices
      .filter(i => i.paymentMethod === 'cash')
      .reduce((sum, i) => sum + i.total, 0);

    const totalCard = invoices
      .filter(i => i.paymentMethod === 'card')
      .reduce((sum, i) => sum + i.total, 0);

    const grandTotal = invoices.reduce((sum, i) => sum + i.total, 0);
    const subtotal = invoices.reduce((sum, i) => sum + (i.subtotal !== undefined ? i.subtotal : (i.total / 1.15)), 0);
    const totalVat = invoices.reduce((sum, i) => sum + (i.tax !== undefined ? i.tax : (i.total - (i.total / 1.15))), 0);
    
    return {
      totalCash,
      totalCard,
      grandTotal,
      subtotal,
      totalVat,
      invoicesCount: invoices.length,
      shiftStart: invoices.length > 0 ? invoices[0].date : new Date().toLocaleDateString('ar-SA'),
      shiftEnd: new Date().toLocaleTimeString('ar-SA')
    };
  }, [invoices]);

  // Current active Z-Report data model
  const currentZReportData: ZReportData = useMemo(() => ({
    reportNumber: `Z-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${(pastZReports.length + 1).toString().padStart(3, '0')}`,
    sellerName: settings.companyName,
    vatNumber: settings.vatNumber,
    posTerminalId: 'POS-MAIN-01',
    cashierName: currentUser?.fullName || 'المدير العام',
    shiftStart: '2026-07-01T08:00:00',
    shiftEnd: new Date().toISOString(),
    totalCash: shiftMetrics.totalCash,
    totalCard: shiftMetrics.totalCard,
    subtotal: shiftMetrics.subtotal,
    totalVat: shiftMetrics.totalVat,
    grandTotal: shiftMetrics.grandTotal,
    invoicesCount: shiftMetrics.invoicesCount
  }), [settings, currentUser, shiftMetrics, pastZReports.length]);

  const currentZReportBase64 = useMemo(() => {
    return generateZReportTlvBase64(currentZReportData);
  }, [currentZReportData]);

  // Handle shift closure
  const handleCloseShift = () => {
    const newRecord: ZReportRecord = {
      ...currentZReportData,
      id: currentZReportData.reportNumber,
      closedAt: new Date().toLocaleString('ar-SA'),
      closedBy: currentUser?.fullName || 'المدير العام',
      base64Payload: currentZReportBase64
    };

    setPastZReports(prev => [newRecord, ...prev]);
    if (onNotify) {
      onNotify(`تم إقفال الوردية وتوليد تقرير Z بنجاح (#${newRecord.reportNumber})`);
    }
    if (onPrintZReport) {
      onPrintZReport(newRecord);
    }
  };

  // Test custom simulator QR Base64
  const testInvoiceQrBase64 = useMemo(() => {
    return generateZatcaTlvBase64({
      sellerName: testSeller,
      vatNumber: testVat,
      timestamp: testDate,
      totalWithVat: testTotal,
      vatAmount: testTax
    });
  }, [testSeller, testVat, testDate, testTotal, testTax]);

  return (
    <div className="p-6 bg-slate-950 text-right text-slate-100 min-h-full space-y-6" dir="rtl">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
              <LockKeyhole className="w-6 h-6 text-rose-500" />
              <span>إقفال الوردية وتقرير Z-Report (متوافق مع هيئة الزكاة)</span>
            </h1>
            <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
              ZATCA FATOORA Phase 1
            </span>
          </div>
          <p className="text-slate-400 text-sm mt-1">
            إقفال صندوق الكاشير وتوليد رمز الاستجابة السريعة المشفر بنظام TLV والطباعة الحرارية المعتمدة.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('current')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'current'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            الوردية الحالية
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'history'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            سجل الإقفالات السابقة ({pastZReports.length})
          </button>
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'simulator'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            مولد وفاحص أكواد ZATCA
          </button>
        </div>
      </div>

      {/* TAB 1: CURRENT ACTIVE SHIFT & Z-REPORT */}
      {activeTab === 'current' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Shift Financial Summary */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
                <span className="text-sm font-black text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-cyan-400" />
                  بيانات الوردية النشطة
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  معرّف التقرير: {currentZReportData.reportNumber}
                </span>
              </div>

              {/* Metadata Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">الكاشير النشط:</span>
                  <span className="font-bold text-white">{currentZReportData.cashierName}</span>
                </div>
                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">نقطة البيع (POS):</span>
                  <span className="font-bold text-white font-mono">{currentZReportData.posTerminalId}</span>
                </div>
                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">عدد الفواتير الصادرة:</span>
                  <span className="font-bold text-cyan-400 font-mono text-sm">{shiftMetrics.invoicesCount} فاتورة</span>
                </div>
              </div>

              {/* Breakdown Amounts */}
              <div className="space-y-2.5 bg-slate-900/40 p-4 rounded-xl border border-slate-800/60 text-xs font-bold">
                <div className="flex justify-between items-center text-slate-300">
                  <span className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    المبيعات النقدية (كاش):
                  </span>
                  <span className="font-mono text-emerald-400 text-sm inline-flex items-center gap-1">
                    {shiftMetrics.totalCash.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5" />
                  </span>
                </div>

                <div className="flex justify-between items-center text-slate-300">
                  <span className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-blue-400" />
                    مبيعات مدى والشبكة (بطاقة):
                  </span>
                  <span className="font-mono text-blue-400 text-sm inline-flex items-center gap-1">
                    {shiftMetrics.totalCard.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5" />
                  </span>
                </div>

                <div className="flex justify-between items-center text-slate-400 pt-2 border-t border-slate-800/40">
                  <span>المجموع الخاضع للضريبة (غير شامل):</span>
                  <span className="font-mono text-slate-300 inline-flex items-center gap-1">
                    {shiftMetrics.subtotal.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 text-slate-400" />
                  </span>
                </div>

                <div className="flex justify-between items-center text-rose-400">
                  <span>ضريبة القيمة المضافة المحصلة (15%):</span>
                  <span className="font-mono font-bold inline-flex items-center gap-1">
                    {shiftMetrics.totalVat.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 text-rose-400" />
                  </span>
                </div>

                <div className="flex justify-between items-center text-white text-base pt-3 border-t border-slate-800 font-black">
                  <span>إجمالي مبيعات الوردية الشامل:</span>
                  <span className="font-mono text-cyan-400 text-xl font-black inline-flex items-center gap-1.5">
                    {shiftMetrics.grandTotal.toFixed(2)} <SaudiRiyalSymbol className="w-5 h-5 text-cyan-400" />
                  </span>
                </div>
              </div>

              {/* Close Shift Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleCloseShift}
                  className="w-full py-4 bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-black rounded-xl text-base flex items-center justify-center gap-2 transition shadow-lg shadow-rose-500/20 active:scale-95 cursor-pointer"
                >
                  <LockKeyhole className="w-5 h-5" />
                  <span>إقفال الوردية نهائياً وطباعة تقرير Z</span>
                </button>
                <p className="text-[11px] text-slate-500 text-center mt-2">
                  عند الإقفال يتم تشفير بيانات الإقفال في رمز QR معتمد وحفظ سجل الإقفال للتدقيق المحاسبي.
                </p>
              </div>
            </div>
          </div>

          {/* QR Code Audit Preview */}
          <div className="lg:col-span-5 space-y-4">
            <ZatcaQrCodeViewer
              base64Payload={currentZReportBase64}
              title="رمز التحقق المشفر لتقرير Z (ZATCA QR)"
              subtitle="يحتوي على بصمة الإقفال المحاسبي والضريبي"
              size={180}
            />

            <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-4 text-xs space-y-3">
              <span className="font-bold text-slate-300 block">شروط المطابقة لـ ZATCA:</span>
              <ul className="space-y-1.5 text-slate-400 list-disc pr-4 text-[11px]">
                <li>ترميز البيانات بنظام Base64 المشتق من وسوم TLV الثنائية.</li>
                <li>إدراج الختم الزمني بدقة متناهية وفق معيار ISO 8601.</li>
                <li>تطابق مبالغ الضريبة مع النسبة النظامية المعتمدة (15%).</li>
                <li>الرقم الضريبي للمنشأة مسجل ومكون من 15 رقماً ويبدأ وينتهي بالرقم 3.</li>
              </ul>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: HISTORICAL Z-REPORTS ARCHIVE */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-white text-sm">سجلات الإقفالات اليومية السابقة</h3>
              <span className="text-xs text-slate-400">{pastZReports.length} تقرير مؤرشف</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-slate-900/80 text-slate-400 font-bold border-b border-slate-800">
                  <tr>
                    <th className="p-3">رقم التقرير</th>
                    <th className="p-3">تاريخ الإقفال</th>
                    <th className="p-3">الكاشير</th>
                    <th className="p-3">عدد الفواتير</th>
                    <th className="p-3">نقدي</th>
                    <th className="p-3">شبكة</th>
                    <th className="p-3">الضريبة (15%)</th>
                    <th className="p-3">الإجمالي</th>
                    <th className="p-3 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {pastZReports.map((report) => (
                    <tr key={report.id} className="hover:bg-slate-900/40 transition">
                      <td className="p-3 font-mono font-bold text-cyan-400">{report.reportNumber}</td>
                      <td className="p-3 font-mono text-slate-300">{report.closedAt}</td>
                      <td className="p-3 font-bold text-white">{report.cashierName}</td>
                      <td className="p-3 font-mono">{report.invoicesCount}</td>
                      <td className="p-3 font-mono text-emerald-400">
                        <span className="inline-flex items-center gap-1">{report.totalCash.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3" /></span>
                      </td>
                      <td className="p-3 font-mono text-blue-400">
                        <span className="inline-flex items-center gap-1">{report.totalCard.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3" /></span>
                      </td>
                      <td className="p-3 font-mono text-rose-400">
                        <span className="inline-flex items-center gap-1">{report.totalVat.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3" /></span>
                      </td>
                      <td className="p-3 font-mono font-bold text-white">
                        <span className="inline-flex items-center gap-1">{report.grandTotal.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5" /></span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          type="button"
                          onClick={() => setSelectedHistoricalReport(report)}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-lg font-bold transition text-xs cursor-pointer inline-flex items-center gap-1"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>معاينة الرمز</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Historical modal preview */}
          {selectedHistoricalReport && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-[#0D0D0D] border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <h3 className="font-bold text-white text-sm">
                    معاينة تقرير Z: {selectedHistoricalReport.reportNumber}
                  </h3>
                  <button 
                    onClick={() => setSelectedHistoricalReport(null)}
                    className="text-slate-400 hover:text-white font-bold"
                  >
                    ✕
                  </button>
                </div>
                
                <ZatcaQrCodeViewer
                  base64Payload={selectedHistoricalReport.base64Payload}
                  title={`تقرير إقفال #${selectedHistoricalReport.reportNumber}`}
                  subtitle={`أقفل بواسطة: ${selectedHistoricalReport.closedBy}`}
                />

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => {
                      if (onPrintZReport) onPrintZReport(selectedHistoricalReport);
                      setSelectedHistoricalReport(null);
                    }}
                    className="flex-1 py-3 bg-cyan-500 text-slate-950 font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>إعادة طباعة التقرير</span>
                  </button>
                  <button
                    onClick={() => setSelectedHistoricalReport(null)}
                    className="px-5 py-3 bg-slate-800 text-slate-300 font-bold rounded-xl cursor-pointer"
                  >
                    إغلاق
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CUSTOM ZATCA QR SIMULATOR & TESTER */}
      {activeTab === 'simulator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-black text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              أداة اختبار وتوليد باركود الفاتورة الضريبية المبسطة (ZATCA Phase 1 Tester)
            </h3>
            <p className="text-xs text-slate-400">
              يمكنك كتابة بيانات أي فاتورة يدوياً لتوليد رمز QR مشفر بنظام TLV والتحقق من توافقه الفوري مع تطبيق هيئة الزكاة.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-bold mb-1">اسم المورد (Tag 1):</label>
                <input
                  type="text"
                  value={testSeller}
                  onChange={(e) => setTestSeller(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">الرقم الضريبي VAT (Tag 2 - 15 رقماً):</label>
                <input
                  type="text"
                  value={testVat}
                  onChange={(e) => setTestVat(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-cyan-400 font-mono font-bold outline-none focus:border-cyan-500"
                  dir="ltr"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">الإجمالي شامل الضريبة (Tag 4):</label>
                  <input
                    type="number"
                    step="0.01"
                    value={testTotal}
                    onChange={(e) => setTestTotal(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono font-bold outline-none focus:border-cyan-500"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">مبلغ الضريبة 15% (Tag 5):</label>
                  <input
                    type="number"
                    step="0.01"
                    value={testTax}
                    onChange={(e) => setTestTax(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-rose-400 font-mono font-bold outline-none focus:border-cyan-500"
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">التوقيت ISO 8601 (Tag 3):</label>
                <input
                  type="text"
                  value={testDate}
                  onChange={(e) => setTestDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 font-mono text-xs outline-none focus:border-cyan-500"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setTestDate(new Date().toISOString().slice(0, 19))}
                className="text-xs text-cyan-400 font-bold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>تحديث التوقيت إلى اللحظة الحالية</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5">
            <ZatcaQrCodeViewer
              base64Payload={testInvoiceQrBase64}
              title="الرمز المولد للاختبار (Simulated QR)"
              subtitle="امسح الرمز بكاميرا الجوال أو تطبيق الزكاة للتحقق"
              size={180}
            />
          </div>
        </div>
      )}

    </div>
  );
}
