import { useCallback, useEffect, useState } from 'react';
import { DatabaseBackup, Download, Upload, RefreshCw, ShieldCheck } from 'lucide-react';
import type { BackupInfo } from '../storage/persistence';
import { flushNow } from '../storage/persistence';

const fmtSize = (b: number) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

export default function BackupManager({ notify }: { notify: (msg: string) => void }) {
  const api = window.ledger;
  const [list, setList] = useState<BackupInfo[]>([]);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    if (!api) return;
    try { setList(await api.backup.list()); } catch { /* تجاهل */ }
  }, [api]);

  useEffect(() => { void refresh(); }, [refresh]);

  if (!api) {
    return (
      <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700">
        <h3 className="font-black text-lg flex items-center gap-2 mb-2"><DatabaseBackup className="w-5 h-5 text-cyan-500" /> النسخ الاحتياطي والاستعادة</h3>
        <p className="text-sm font-semibold text-slate-500">متاح في النسخة المكتبية (المثبّتة) فقط.</p>
      </div>
    );
  }

  const guard = async (fn: () => Promise<void>) => {
    if (busy) return;
    setBusy(true);
    try { await fn(); } catch (e) { console.error(e); notify('تعذر تنفيذ العملية'); } finally { setBusy(false); }
  };

  const exportBackup = () => guard(async () => {
    await flushNow();
    const r = await api.backup.exportTo();
    if (r.ok) { notify('تم حفظ النسخة الاحتياطية'); void refresh(); }
  });

  const restore = (fn: () => Promise<{ ok: boolean; canceled?: boolean; error?: string }>) => guard(async () => {
    await flushNow();
    const r = await fn();
    if (!r.ok && !r.canceled) notify(r.error || 'فشلت الاستعادة');
    // عند النجاح يُعاد تشغيل البرنامج تلقائياً
  });

  return (
    <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-black text-lg flex items-center gap-2"><DatabaseBackup className="w-5 h-5 text-cyan-500" /> النسخ الاحتياطي والاستعادة</h3>
        <div className="flex gap-2">
          <button disabled={busy} onClick={exportBackup} className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-sm flex items-center gap-2 disabled:opacity-50"><Download className="w-4 h-4" /> تصدير نسخة احتياطية</button>
          <button disabled={busy} onClick={() => restore(api.backup.restoreFromFile)} className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm flex items-center gap-2 disabled:opacity-50"><Upload className="w-4 h-4" /> استعادة من ملف</button>
        </div>
      </div>

      <p className="flex items-start gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
        <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
        يأخذ البرنامج نسخة تلقائية كل يوم وقبل كل تحديث (يُحتفظ بآخر 15). وقبل أي استعادة تُحفظ نسخة أمان من بياناتك الحالية. انسخ ملف النسخة إلى فلاش أو سحابة للحماية من تلف الجهاز.
      </p>

      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-black">النسخ التلقائية على هذا الجهاز ({list.length})</span>
          <button onClick={refresh} className="text-xs font-bold text-slate-500 flex items-center gap-1"><RefreshCw className="w-3.5 h-3.5" /> تحديث</button>
        </div>
        <div className="max-h-56 overflow-y-auto rounded-xl border border-slate-100 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-700">
          {list.length === 0 && <div className="p-4 text-center text-xs font-bold text-slate-400">لا توجد نسخ بعد.</div>}
          {list.map((b) => (
            <div key={b.name} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
              <div className="min-w-0">
                <div className="font-mono text-xs truncate" dir="ltr">{b.name}</div>
                <div className="text-[11px] text-slate-500 font-semibold">{new Date(b.mtime).toLocaleString('ar-SA')} — {fmtSize(b.size)}</div>
              </div>
              <button disabled={busy} onClick={() => restore(() => api.backup.restoreFromAuto(b.name))} className="shrink-0 px-3 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 hover:bg-amber-100 text-xs font-black disabled:opacity-50">استعادة</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
