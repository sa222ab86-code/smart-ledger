import React, { useState } from 'react';
import { FileBox, Plus, Search, Calendar, DollarSign, Trash2, Tag, X } from 'lucide-react';
import { PurchaseInvoice, Supplier, Product } from '../types';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';
import ProductPicker from './ProductPicker';

interface PurchasesManagerProps {
  purchases: PurchaseInvoice[];
  suppliers: Supplier[];
  products: Product[];
  onAddPurchase: (purchase: PurchaseInvoice) => void;
  onDeletePurchase: (id: string) => void;
}

export default function PurchasesManager({
  purchases,
  suppliers,
  products,
  onAddPurchase,
  onDeletePurchase,
}: PurchasesManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [purchaseItems, setPurchaseItems] = useState<{ productId: string; qty: number; price: number }[]>([]);

  // Item input states
  const [currentItemId, setCurrentItemId] = useState('');
  const [currentQty, setCurrentQty] = useState('1');
  const [currentPrice, setCurrentPrice] = useState('');

  const handleAddItem = () => {
    if (!currentItemId || parseFloat(currentQty) <= 0 || parseFloat(currentPrice) < 0) return;
    
    // Check if product is already in the list
    const existingIndex = purchaseItems.findIndex(item => item.productId === currentItemId);
    if (existingIndex > -1) {
      const updated = purchaseItems.map((it, i) => (i === existingIndex ? { ...it, qty: it.qty + parseInt(currentQty) } : it));
      setPurchaseItems(updated);
    } else {
      setPurchaseItems([...purchaseItems, {
        productId: currentItemId,
        qty: parseInt(currentQty),
        price: parseFloat(currentPrice),
      }]);
    }

    // Reset item inputs
    setCurrentQty('1');
    setCurrentPrice('');
  };

  const handleRemoveItem = (index: number) => {
    setPurchaseItems(purchaseItems.filter((_, i) => i !== index));
  };

  const handleProductChange = (productId: string) => {
    setCurrentItemId(productId);
    const prod = products.find(p => p.id === productId);
    if (prod) {
      setCurrentPrice(prod.cost ? prod.cost.toString() : '0');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplierId || purchaseItems.length === 0) return;

    const supplier = suppliers.find(s => s.id === selectedSupplierId);
    if (!supplier) return;

    const calculatedTotal = purchaseItems.reduce((sum, item) => sum + (item.qty * item.price), 0);

    const formattedItems = purchaseItems.map(item => {
      const prod = products.find(p => p.id === item.productId);
      return {
        productId: item.productId,
        productName: prod ? prod.nameAr : 'صنف غير معروف',
        qty: item.qty,
        price: item.price,
        total: item.qty * item.price,
      };
    });

    const newPurchase: PurchaseInvoice = {
      id: `p-${Date.now()}`,
      supplierId: selectedSupplierId,
      supplierName: supplier.name,
      date: purchaseDate,
      items: formattedItems,
      total: calculatedTotal,
    };

    onAddPurchase(newPurchase);

    // Reset form states
    setSelectedSupplierId('');
    setPurchaseDate(new Date().toISOString().split('T')[0]);
    setPurchaseItems([]);
    setShowAddModal(false);
  };

  const filteredPurchases = purchases.filter(
    (p) =>
      p.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const calculatedTotalPurchase = filteredPurchases.reduce((sum, p) => sum + p.total, 0);

  return (
    <div className="p-6 bg-slate-50 dark:bg-slate-950 text-right text-slate-800 dark:text-slate-100 min-h-full space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <FileBox className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
            <span>إدارة المشتريات والتوريد</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
            تسجيل وتتبع فواتير شراء المخزون وتكلفة السلع لضبط هامش الربح والضريبة.
          </p>
        </div>
        <button
          onClick={() => {
            setSelectedSupplierId(suppliers[0]?.id || '');
            setPurchaseItems([]);
            setShowAddModal(true);
          }}
          className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg transition"
        >
          <Plus className="w-5 h-5" />
          <span>تسجيل فاتورة شراء</span>
        </button>
      </div>

      {/* Stats and Search Row */}
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full max-w-md">
          <input
            type="text"
            placeholder="البحث باسم المورد أو رقم الفاتورة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pr-12 pl-4 py-3 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
          />
          <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3" />
        </div>
        
        <div className="bg-white/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 px-6 py-3 rounded-2xl flex items-center gap-3">
          <DollarSign className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <div className="font-bold">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">إجمالي مشتريات التوريد</span>
            <span className="text-xl text-emerald-600 dark:text-emerald-400 font-mono inline-flex items-center gap-1.5">
              {calculatedTotalPurchase.toFixed(2)} <SaudiRiyalSymbol className="w-4 h-4" />
            </span>
          </div>
        </div>
      </div>

      {/* Purchases Table */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-4 font-bold">رقم الفاتورة</th>
                <th className="p-4 font-bold">المورد</th>
                <th className="p-4 font-bold">التاريخ</th>
                <th className="p-4 font-bold">عدد الأصناف</th>
                <th className="p-4 font-bold">إجمالي الفاتورة</th>
                <th className="p-4 font-bold text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/60 dark:divide-slate-800/60">
              {filteredPurchases.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">
                    لا يوجد فواتير شراء مسجلة حالياً.
                  </td>
                </tr>
              ) : (
                filteredPurchases.map((p) => (
                  <tr key={p.id} className="hover:bg-white/50 dark:hover:bg-slate-900/50 transition">
                    <td className="p-4 font-mono font-bold text-slate-600 dark:text-slate-300">{p.id}</td>
                    <td className="p-4 font-bold text-slate-700 dark:text-slate-200">{p.supplierName}</td>
                    <td className="p-4 font-mono text-slate-500 dark:text-slate-400">{p.date}</td>
                    <td className="p-4 text-slate-500 dark:text-slate-400">{p.items.length} أصناف</td>
                    <td className="p-4 font-mono font-black text-emerald-600 dark:text-emerald-400 inline-flex items-center gap-1">
                      {p.total.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5" />
                    </td>
                    <td className="p-4 flex justify-center">
                      <button
                        onClick={() => onDeletePurchase(p.id)}
                        className="p-2 bg-white dark:bg-slate-900 hover:bg-rose-950 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg text-slate-500 dark:text-slate-400 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Register Invoice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col text-slate-800 dark:text-slate-100 max-h-[90vh]">
            <div className="bg-white dark:bg-slate-900 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-lg flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                <FileBox className="w-5 h-5" /> تسجيل فاتورة شراء جديدة
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-500 dark:text-slate-400 hover:text-rose-500 bg-slate-100 dark:bg-slate-800 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto flex-1 font-bold">
              {/* Supplier and Date Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-sm text-slate-500 dark:text-slate-400">اختر المورد</label>
                  <select
                    value={selectedSupplierId}
                    onChange={(e) => setSelectedSupplierId(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-slate-900 dark:text-white focus:border-emerald-500 focus:outline-none"
                    required
                  >
                    <option value="" disabled>-- اختر المورد --</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm text-slate-500 dark:text-slate-400">تاريخ الشراء</label>
                  <input
                    type="date"
                    value={purchaseDate}
                    onChange={(e) => setPurchaseDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-slate-900 dark:text-white focus:border-emerald-500 focus:outline-none font-mono"
                    required
                  />
                </div>
              </div>

              {/* Item Adder Panel */}
              <div className="border border-slate-200 dark:border-slate-800 bg-white/20 dark:bg-slate-900/20 p-4 rounded-xl space-y-4">
                <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>إضافة أصناف مشتراة إلى الفاتورة</span>
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                  <div className="sm:col-span-2 space-y-1">
                    <label className="text-xs text-slate-500 dark:text-slate-400">الصنف</label>
                    <ProductPicker
                      products={products}
                      value={currentItemId}
                      onChange={handleProductChange}
                      placeholder="-- ابحث عن الصنف بالاسم أو الباركود --"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 dark:text-slate-400">الكمية</label>
                    <input
                      type="number"
                      min="1"
                      value={currentQty}
                      onChange={(e) => setCurrentQty(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-sm text-slate-900 dark:text-white focus:outline-none font-mono"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500 dark:text-slate-400">سعر التكلفة (للوحدة)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={currentPrice}
                      onChange={(e) => setCurrentPrice(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-sm text-slate-900 dark:text-white focus:outline-none font-mono"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="w-full py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-emerald-600 dark:text-emerald-400 text-sm font-bold rounded-xl border border-dashed border-slate-300 dark:border-slate-700 transition"
                >
                  إدراج الصنف للفاتورة +
                </button>
              </div>

              {/* Items List in Invoice */}
              <div className="space-y-2">
                <span className="text-xs text-slate-500 dark:text-slate-400 block">الأصناف المدرجة في الفاتورة</span>
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs bg-slate-50 dark:bg-slate-950 max-h-[180px] overflow-y-auto">
                  <table className="w-full text-right">
                    <thead className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                      <tr>
                        <th className="p-3">اسم الصنف</th>
                        <th className="p-3 text-center">الكمية</th>
                        <th className="p-3 text-center">التكلفة</th>
                        <th className="p-3 text-center">المجموع</th>
                        <th className="p-3 text-center w-12"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200/40 dark:divide-slate-800/40 text-slate-600 dark:text-slate-300">
                      {purchaseItems.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-slate-400 dark:text-slate-600">
                            لا توجد أصناف مضافة حالياً.
                          </td>
                        </tr>
                      ) : (
                        purchaseItems.map((item, idx) => {
                          const prod = products.find(p => p.id === item.productId);
                          const total = item.qty * item.price;
                          return (
                            <tr key={idx}>
                              <td className="p-3 font-bold">{prod ? prod.nameAr : 'صنف غير معروف'}</td>
                              <td className="p-3 text-center font-mono">{item.qty}</td>
                              <td className="p-3 text-center font-mono">{item.price.toFixed(2)}</td>
                              <td className="p-3 text-center font-mono text-emerald-600 dark:text-emerald-400 font-bold">{total.toFixed(2)}</td>
                              <td className="p-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleRemoveItem(idx)}
                                  className="text-rose-600 dark:text-rose-400 hover:text-rose-600 font-bold"
                                >
                                  حذف
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Invoice Summary and Submit */}
              <div className="border-t border-slate-200 dark:border-slate-800 pt-4 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="font-bold text-lg">
                  <span className="text-xs text-slate-500 dark:text-slate-400">الإجمالي الشامل للشراء:</span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400 text-xl inline-flex items-center gap-1.5">
                    {purchaseItems.reduce((sum, item) => sum + (item.qty * item.price), 0).toFixed(2)} <SaudiRiyalSymbol className="w-4 h-4" />
                  </span>
                </div>
                
                <button
                  type="submit"
                  disabled={!selectedSupplierId || purchaseItems.length === 0}
                  className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl disabled:bg-slate-100 dark:disabled:bg-slate-800 disabled:text-slate-400 dark:disabled:text-slate-600 transition"
                >
                  تسجيل الفاتورة وحفظ المخزون
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
