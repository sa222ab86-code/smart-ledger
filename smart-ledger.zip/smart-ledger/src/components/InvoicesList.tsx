import React, { useMemo, useState } from 'react';
import { InvoicePaymentModal } from './PaymentModals';
import SalesReturnModal, { type SalesReturnRequest } from './SalesReturnModal';
import { isReturnDoc, isUnsettled } from '../utils/invoiceMath';
import { hasReturnableQty, returnedQtyByLine } from '../utils/returns';
import { useIncrementalList, LoadMoreSentinel } from '../utils/useIncrementalList';
import { Receipt, Search, Eye, Printer, Coins, ArrowRightLeft, Zap, Wallet, RotateCcw } from 'lucide-react';
import { Invoice, MultiCurrencySettings, CurrencyConfig } from '../types';
import { defaultCurrencies } from '../data';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';
import { customerLabel } from '../utils/invoiceMath';

interface InvoicesListProps {
  invoices: Invoice[];
  onViewInvoice: (invoice: Invoice) => void;
  onPrintInvoice?: (invoice: Invoice, currencyCode?: string) => void;
  multiCurrencySettings?: MultiCurrencySettings;
  /** سداد فاتورة آجلة/جزئية */
  onPayInvoice?: (invoiceId: string, amount: number, method: 'cash' | 'card') => void;
  /** إنشاء مرتجع مبيعات من فاتورة */
  onCreateReturn?: (invoiceId: string, req: SalesReturnRequest) => void;
}

export default function InvoicesList({ 
  invoices, 
  onViewInvoice, 
  onPrintInvoice, 
  multiCurrencySettings,
  onPayInvoice,
  onCreateReturn,
}: InvoicesListProps) {
  const [statusFilter, setStatusFilter] = useState<'all' | 'unpaid' | 'returns'>('all');
  const [payingInvoice, setPayingInvoice] = useState<Invoice | null>(null);
  const [returningInvoice, setReturningInvoice] = useState<Invoice | null>(null);
  // الكميات المرتجعة لكل فاتورة (لإخفاء زر المرتجع عند اكتمال الإرجاع)
  const returnedMap = useMemo(() => {
    const m = new Map<string, number[]>();
    for (const r of invoices) if (isReturnDoc(r) && r.originalInvoiceId && !m.has(r.originalInvoiceId)) m.set(r.originalInvoiceId, returnedQtyByLine(invoices, r.originalInvoiceId));
    return m;
  }, [invoices]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('الكل');
  // الافتراضي: مبيعات اليوم فقط
  const [dateMode, setDateMode] = useState<'today' | 'yesterday' | 'week' | 'all' | 'custom'>('today');
  const [customDate, setCustomDate] = useState('');

  const availableCurrencies: CurrencyConfig[] = 
    multiCurrencySettings?.currencies && multiCurrencySettings.currencies.length > 0
      ? multiCurrencySettings.currencies.filter(c => c.isEnabled || c.isBase)
      : defaultCurrencies.filter(c => c.isEnabled || c.isBase);

  const baseCurrencyCode = multiCurrencySettings?.baseCurrency || 'SAR';
  const [displayCurrencyCode, setDisplayCurrencyCode] = useState<string>(baseCurrencyCode);

  const baseCurrObj = availableCurrencies.find(c => c.code === baseCurrencyCode) || availableCurrencies[0];
  const activeCurrObj = availableCurrencies.find(c => c.code === displayCurrencyCode) || baseCurrObj;

  const renderCurr = (code?: string, symbol?: string, className = "w-3 h-3 inline-block mx-0.5 align-middle") => {
    if (code === 'SAR' || symbol === 'ر.س' || symbol === '⃁' || symbol === '﷼') {
      return <SaudiRiyalSymbol className={className} />;
    }
    return <span>{symbol || code}</span>;
  };
  const isNonBase = activeCurrObj.code !== baseCurrObj.code;
  const exchangeRate = activeCurrObj.exchangeRate || 1.0;

  const convertAmount = (amountInBase: number) => {
    if (!isNonBase || exchangeRate <= 0) return amountInBase;
    return amountInBase / exchangeRate;
  };

  const ymd = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const todayStr = ymd(new Date());
  const yesterdayStr = ymd(new Date(Date.now() - 86400000));
  const weekStartStr = ymd(new Date(Date.now() - 6 * 86400000));

  const matchesDate = (inv: Invoice) => {
    const day = (inv.date || '').slice(0, 10);
    switch (dateMode) {
      case 'today': return day === todayStr;
      case 'yesterday': return day === yesterdayStr;
      case 'week': return day >= weekStartStr && day <= todayStr;
      case 'custom': return !customDate || day === customDate;
      default: return true;
    }
  };

  const filteredInvoices = invoices.filter(inv => {
    if (statusFilter === 'unpaid' && !isUnsettled(inv)) return false;
    if (statusFilter === 'returns' && !isReturnDoc(inv)) return false;
    // الآجل غير المسدد يُعرض من كل الفترات (فواتير قديمة لم تُسدَّد بعد)
    if (statusFilter !== 'unpaid' && !matchesDate(inv)) return false;
    const invNum = inv.invoiceNumber || inv.number || '';
    const matchesSearch = invNum.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (inv.customerName && inv.customerName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesMethod = selectedMethod === 'الكل' || inv.paymentMethod === selectedMethod;
    return matchesSearch && matchesMethod;
  });
  // الإجماليات تُحسب على كل الفواتير المطابقة، لكن الجدول يرسم ١٠٠ صف ويحمّل المزيد عند التمرير
  const invoicesTable = useIncrementalList(filteredInvoices, 100, `${searchQuery}|${selectedMethod}|${dateMode}|${customDate}|${statusFilter}`);

  return (
    <div className="p-6 bg-slate-50 dark:bg-slate-950 text-right text-slate-800 dark:text-slate-100 min-h-full space-y-6" dir="rtl">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Receipt className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
            <span>سجل الفواتير والمبيعات</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">مراجعة والبحث في الفواتير الضريبية المبسطة الصادرة من الكاشير.</p>
        </div>

        {/* Currency badge if non-base */}
        {isNonBase && (
          <div className="bg-amber-500/10 border border-amber-500/30 px-3.5 py-1.5 rounded-xl text-amber-700 dark:text-amber-300 text-xs font-bold flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4" />
            <span className="flex items-center gap-1">عرض المبالغ بسعر صرف: 1 {activeCurrObj.code} = {exchangeRate} {renderCurr(baseCurrObj.code, baseCurrObj.symbol)}</span>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <input 
            type="text" 
            placeholder="البحث برقم الفاتورة أو اسم العميل..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pr-12 pl-4 py-3.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:border-cyan-500"
          />
          <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3.5" />
        </div>
        
        {/* Date filter (default: today) */}
        <div className="flex items-center gap-2">
          <select
            value={dateMode}
            onChange={(e) => setDateMode(e.target.value as typeof dateMode)}
            className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-600 dark:text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="today">اليوم</option>
            <option value="yesterday">أمس</option>
            <option value="week">آخر 7 أيام</option>
            <option value="custom">تاريخ محدد</option>
            <option value="all">كل الفترات</option>
          </select>
          {dateMode === 'custom' && (
            <input
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm text-slate-600 dark:text-slate-300 font-mono focus:outline-none focus:border-cyan-500"
            />
          )}
        </div>

        {/* Status filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
          className={`border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-500 cursor-pointer font-bold ${statusFilter === 'unpaid' ? 'bg-rose-500/10 border-rose-500/40 text-rose-700 dark:text-rose-300' : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'}`}
        >
          <option value="all">كل المستندات</option>
          <option value="unpaid">آجل غير مسدد (كل الفترات)</option>
          <option value="returns">المرتجعات فقط</option>
        </select>

        {/* Payment Method select Filter */}
        <select 
          value={selectedMethod}
          onChange={(e) => setSelectedMethod(e.target.value)}
          className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-600 dark:text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
        >
          <option value="الكل">كل طرق الدفع</option>
          <option value="cash">نقدي (Cash)</option>
          <option value="card">شبكة (Card)</option>
        </select>

        {/* Currency Display Selector */}
        <div className="flex items-center gap-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5">
          <Coins className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
          <span className="text-xs text-slate-500 dark:text-slate-400 font-bold whitespace-nowrap">العملة:</span>
          <select
            value={displayCurrencyCode}
            onChange={(e) => setDisplayCurrencyCode(e.target.value)}
            className="bg-transparent text-cyan-700 dark:text-cyan-300 font-black text-sm focus:outline-none cursor-pointer"
          >
            {availableCurrencies.map(c => (
              <option key={c.code} value={c.code} className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                {c.nameAr} ({c.code === 'SAR' ? '⃁' : c.symbol})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Invoices table (rows) */}
      {filteredInvoices.length === 0 ? (
        <div className="py-12 text-center text-slate-500 font-bold">
          {dateMode === 'all' ? 'لا توجد فواتير مطابقة لعملية البحث' : 'لا توجد فواتير في هذه الفترة — اختر «كل الفترات» لعرض الأقدم'}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right whitespace-nowrap">
              <thead className="bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-xs">
                <tr>
                  <th className="px-4 py-3 font-black">رقم الفاتورة</th>
                  <th className="px-4 py-3 font-black">التاريخ</th>
                  <th className="px-4 py-3 font-black">العميل</th>
                  <th className="px-4 py-3 font-black">الكاشير</th>
                  <th className="px-4 py-3 font-black">طريقة الدفع</th>
                  <th className="px-4 py-3 font-black">قبل الضريبة</th>
                  <th className="px-4 py-3 font-black">الخصم</th>
                  <th className="px-4 py-3 font-black">الضريبة</th>
                  <th className="px-4 py-3 font-black">الإجمالي</th>
                  <th className="px-4 py-3 font-black">الحالة</th>
                  <th className="px-4 py-3 font-black text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {invoicesTable.visible.map(invoice => {
                  const invoiceNum = invoice.invoiceNumber || invoice.number || 'INV-0000';
                  const subTotalAmount = invoice.subtotal !== undefined ? invoice.subtotal : (invoice.total / 1.15);
                  const taxAmount = invoice.tax !== undefined ? invoice.tax : (invoice.total - subTotalAmount);
                  const isRet = isReturnDoc(invoice);
                  const remaining = !isRet && invoice.remainingAmount && invoice.remainingAmount > 0 ? invoice.remainingAmount : 0;
                  const returnedLines = returnedMap.get(invoice.id);
                  const canReturn = !!onCreateReturn && !isRet && hasReturnableQty(invoice, returnedLines);
                  const fmt = (n: number) => convertAmount(n).toFixed(2);

                  return (
                    <tr key={invoice.id} className={`border-t border-slate-200/70 dark:border-slate-800/70 hover:bg-white/60 dark:hover:bg-slate-900/60 transition-colors ${isRet ? 'bg-rose-500/5' : ''}`}>
                      <td className={`px-4 py-3 font-mono font-bold ${isRet ? 'text-rose-700 dark:text-rose-300' : 'text-cyan-700 dark:text-cyan-300'}`}>
                        {invoiceNum}
                        {isRet && <span className="block text-[10px] font-sans text-rose-600 dark:text-rose-400">مرتجع عن {invoice.originalInvoiceNumber}</span>}
                        {!isRet && returnedLines && <span className="block text-[10px] font-sans text-amber-600 dark:text-amber-400">{canReturn ? 'عليها مرتجع جزئي' : 'مرتجعة بالكامل'}</span>}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-300 text-xs">{invoice.date}</td>
                      <td className="px-4 py-3 text-slate-700 dark:text-slate-200 font-bold">
                        {customerLabel(invoice.customerName)}
                        {invoice.note && <span title={invoice.note} className="mr-1.5 cursor-help">📝</span>}
                      </td>
                      <td className="px-4 py-3 text-slate-500 dark:text-slate-400 text-xs font-bold">{invoice.cashierName || '—'}</td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded px-2.5 py-0.5 text-xs font-bold text-slate-700 dark:text-slate-200">
                          {invoice.paymentMethod === 'cash' ? 'نقدي' : 'شبكة'}
                          {invoice.paymentMethod === 'cash' && invoice.isQuickPay && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-700 dark:text-amber-300 px-1 rounded flex items-center gap-0.5"><Zap className="w-2.5 h-2.5" />سريع</span>
                          )}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-300">{fmt(subTotalAmount)}</td>
                      <td className="px-4 py-3 font-mono text-amber-600 dark:text-amber-400">
                        {invoice.discount && invoice.discount > 0
                          ? `- ${fmt(invoice.discount)}${invoice.discountType === 'percent' ? ` (${invoice.discountValue}%)` : ''}`
                          : <span className="text-slate-400 dark:text-slate-600">—</span>}
                      </td>
                      <td className="px-4 py-3 font-mono text-rose-600 dark:text-rose-400">{fmt(taxAmount)}</td>
                      <td className="px-4 py-3">
                        <span className="font-mono font-black text-emerald-600 dark:text-emerald-400">{fmt(invoice.total)}</span>
                        {isNonBase && (
                          <span className="block text-[10px] text-slate-500 font-mono">({invoice.total.toFixed(2)} {baseCurrObj.code})</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {isRet ? (
                          <span className="inline-flex flex-col">
                            <span className="text-[11px] font-black text-rose-700 dark:text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded px-2 py-0.5">مرتجع مبيعات</span>
                            {invoice.debtOffset ? <span className="text-[10px] font-mono text-amber-700 dark:text-amber-300 mt-0.5">خُصم من المديونية {fmt(invoice.debtOffset)}</span> : null}
                          </span>
                        ) : remaining > 0 ? (
                          <span className="inline-flex flex-col">
                            <span className="text-[11px] font-black text-rose-700 dark:text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded px-2 py-0.5">
                              {invoice.paymentStatus === 'unpaid' ? 'آجل' : 'دفع جزئي'}
                            </span>
                            <span className="text-[10px] font-mono text-rose-700 dark:text-rose-300 mt-0.5">المتبقي {fmt(remaining)}</span>
                          </span>
                        ) : (
                          <span className="text-[11px] font-black text-emerald-700 dark:text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded px-2 py-0.5">مسددة</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2 justify-center">
                          {remaining > 0 && onPayInvoice && (
                            <button
                              onClick={() => setPayingInvoice(invoice)}
                              className="px-2.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition text-xs font-black flex items-center gap-1 cursor-pointer"
                              title="سداد الفاتورة"
                            >
                              <Wallet className="w-4 h-4" /> سداد
                            </button>
                          )}
                          {canReturn && (
                            <button
                              onClick={() => setReturningInvoice(invoice)}
                              className="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-lg transition border border-rose-500/30 cursor-pointer"
                              title="مرتجع مبيعات"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => onViewInvoice(invoice)}
                            className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition border border-slate-300 dark:border-slate-700 cursor-pointer"
                            title="عرض الفاتورة وتغيير العملة"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onPrintInvoice && onPrintInvoice(invoice, displayCurrencyCode)}
                            className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition border border-slate-300 dark:border-slate-700 cursor-pointer"
                            title="طباعة"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-white dark:bg-slate-900 border-t-2 border-cyan-500/40 font-black text-sm">
                <tr>
                  <td className="px-4 py-3 text-cyan-700 dark:text-cyan-300" colSpan={5}>الإجمالي ({filteredInvoices.length} فاتورة) — العملة: {activeCurrObj.code}</td>
                  <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-200">{convertAmount(filteredInvoices.reduce((t, i) => t + (i.subtotal !== undefined ? i.subtotal : i.total / 1.15), 0)).toFixed(2)}</td>
                  <td className="px-4 py-3 font-mono text-amber-600 dark:text-amber-400">{convertAmount(filteredInvoices.reduce((t, i) => t + (i.discount || 0), 0)).toFixed(2)}</td>
                  <td className="px-4 py-3 font-mono text-rose-600 dark:text-rose-400">{convertAmount(filteredInvoices.reduce((t, i) => t + (i.tax !== undefined ? i.tax : i.total - i.total / 1.15), 0)).toFixed(2)}</td>
                  <td className="px-4 py-3 font-mono text-emerald-600 dark:text-emerald-400">{convertAmount(filteredInvoices.reduce((t, i) => t + i.total, 0)).toFixed(2)}</td>
                  <td className="px-4 py-3 font-mono text-rose-700 dark:text-rose-300 text-xs" colSpan={2}>
                    {(() => { const r = filteredInvoices.reduce((t, i) => t + (i.remainingAmount && i.remainingAmount > 0 ? i.remainingAmount : 0), 0); return r > 0 ? `آجل ${convertAmount(r).toFixed(2)}` : ''; })()}
                  </td>
                </tr>
              </tfoot>
            </table>
            <LoadMoreSentinel hasMore={invoicesTable.hasMore} shown={invoicesTable.shown} total={invoicesTable.total} onMore={invoicesTable.showMore} sentinelRef={invoicesTable.sentinelRef} />
          </div>
        </div>
      )}

      {payingInvoice && onPayInvoice && (
        <InvoicePaymentModal
          invoice={payingInvoice}
          onClose={() => setPayingInvoice(null)}
          onConfirm={(amount, method) => { onPayInvoice(payingInvoice.id, amount, method); setPayingInvoice(null); }}
        />
      )}
      {returningInvoice && onCreateReturn && (
        <SalesReturnModal
          invoice={returningInvoice}
          allInvoices={invoices}
          onClose={() => setReturningInvoice(null)}
          onConfirm={(req) => { onCreateReturn(returningInvoice.id, req); setReturningInvoice(null); }}
        />
      )}
    </div>
  );
}
