import React, { useState } from 'react';
import { Receipt, Search, Eye, Printer, Coins, ArrowRightLeft, Zap } from 'lucide-react';
import { Invoice, MultiCurrencySettings, CurrencyConfig } from '../types';
import { defaultCurrencies } from '../data';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';

interface InvoicesListProps {
  invoices: Invoice[];
  onViewInvoice: (invoice: Invoice) => void;
  onPrintInvoice?: (invoice: Invoice, currencyCode?: string) => void;
  multiCurrencySettings?: MultiCurrencySettings;
}

export default function InvoicesList({ 
  invoices, 
  onViewInvoice, 
  onPrintInvoice, 
  multiCurrencySettings 
}: InvoicesListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('الكل');

  const availableCurrencies: CurrencyConfig[] = 
    multiCurrencySettings?.currencies && multiCurrencySettings.currencies.length > 0
      ? multiCurrencySettings.currencies.filter(c => c.isEnabled || c.isBase)
      : defaultCurrencies.filter(c => c.isEnabled || c.isBase);

  const baseCurrencyCode = multiCurrencySettings?.baseCurrency || 'SAR';
  const [displayCurrencyCode, setDisplayCurrencyCode] = useState<string>(baseCurrencyCode);

  const baseCurrObj = availableCurrencies.find(c => c.code === baseCurrencyCode) || availableCurrencies[0];
  const activeCurrObj = availableCurrencies.find(c => c.code === displayCurrencyCode) || baseCurrObj;

  const renderCurr = (code?: string, symbol?: string, className = "w-3 h-3 inline-block mx-0.5 align-middle") => {
    if (code === 'SAR' || symbol === 'ر.س' || symbol === '⃁' || symbol === '﷼') {
      return <SaudiRiyalSymbol className={className} />;
    }
    return <span>{symbol || code}</span>;
  };
  const isNonBase = activeCurrObj.code !== baseCurrObj.code;
  const exchangeRate = activeCurrObj.exchangeRate || 1.0;

  const convertAmount = (amountInBase: number) => {
    if (!isNonBase || exchangeRate <= 0) return amountInBase;
    return amountInBase / exchangeRate;
  };

  const filteredInvoices = invoices.filter(inv => {
    const invNum = inv.invoiceNumber || inv.number || '';
    const matchesSearch = invNum.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (inv.customerName && inv.customerName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesMethod = selectedMethod === 'الكل' || inv.paymentMethod === selectedMethod;
    return matchesSearch && matchesMethod;
  });

  return (
    <div className="p-6 bg-slate-950 text-right text-slate-100 min-h-full space-y-6" dir="rtl">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
            <Receipt className="w-6 h-6 text-cyan-400" />
            <span>سجل الفواتير والمبيعات</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1">مراجعة والبحث في الفواتير الضريبية المبسطة الصادرة من الكاشير.</p>
        </div>

        {/* Currency badge if non-base */}
        {isNonBase && (
          <div className="bg-amber-500/10 border border-amber-500/30 px-3.5 py-1.5 rounded-xl text-amber-300 text-xs font-bold flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4" />
            <span className="flex items-center gap-1">عرض المبالغ بسعر صرف: 1 {activeCurrObj.code} = {exchangeRate} {renderCurr(baseCurrObj.code, baseCurrObj.symbol)}</span>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <input 
            type="text" 
            placeholder="البحث برقم الفاتورة أو اسم العميل..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0D0D0D] border border-slate-800 rounded-xl pr-12 pl-4 py-3.5 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
          />
          <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3.5" />
        </div>
        
        {/* Payment Method select Filter */}
        <select 
          value={selectedMethod}
          onChange={(e) => setSelectedMethod(e.target.value)}
          className="bg-[#0D0D0D] border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
        >
          <option value="الكل">كل طرق الدفع</option>
          <option value="cash">نقدي (Cash)</option>
          <option value="card">شبكة (Card)</option>
        </select>

        {/* Currency Display Selector */}
        <div className="flex items-center gap-2 bg-[#0D0D0D] border border-slate-800 rounded-xl px-3 py-1.5">
          <Coins className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="text-xs text-slate-400 font-bold whitespace-nowrap">العملة:</span>
          <select
            value={displayCurrencyCode}
            onChange={(e) => setDisplayCurrencyCode(e.target.value)}
            className="bg-transparent text-cyan-300 font-black text-sm focus:outline-none cursor-pointer"
          >
            {availableCurrencies.map(c => (
              <option key={c.code} value={c.code} className="bg-slate-900 text-white">
                {c.nameAr} ({c.code === 'SAR' ? '⃁' : c.symbol})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Invoices List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInvoices.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500 font-bold">
            لا توجد فواتير مطابقة لعملية البحث
          </div>
        ) : (
          filteredInvoices.map(invoice => {
            const invoiceNum = invoice.invoiceNumber || invoice.number || 'INV-0000';
            const subTotalAmount = invoice.subtotal !== undefined ? invoice.subtotal : (invoice.total / 1.15);
            const taxAmount = invoice.tax !== undefined ? invoice.tax : (invoice.total - subTotalAmount);

            const convSubTotal = convertAmount(subTotalAmount);
            const convTax = convertAmount(taxAmount);
            const convTotal = convertAmount(invoice.total);

            return (
              <div key={invoice.id} className="bg-[#0D0D0D] border border-slate-800/80 rounded-2xl p-6 relative overflow-hidden group hover:border-cyan-500/30 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start border-b border-slate-800/60 pb-4">
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase tracking-wider text-cyan-400 font-extrabold block">فاتورة ضريبية مبسطة</span>
                      <h3 className="font-bold text-white text-base font-mono">{invoiceNum}</h3>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                      <Receipt className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="mt-4 space-y-2.5 text-xs text-slate-400 font-bold">
                    <div className="flex justify-between">
                      <span className="text-slate-500">العميل:</span>
                      <span className="text-slate-200">{invoice.customerName || 'نقدي'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">التاريخ:</span>
                      <span className="text-slate-200 font-mono">{invoice.date}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">طريقة الدفع:</span>
                      <span className="text-slate-200 font-bold bg-slate-900 px-2.5 py-0.5 rounded border border-slate-800 uppercase inline-flex items-center gap-1">
                        {invoice.paymentMethod === 'cash' ? (
                          <>
                            <span>نقدي</span>
                            {invoice.isQuickPay && (
                              <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1 rounded font-bold flex items-center gap-0.5">
                                <Zap className="w-2.5 h-2.5" />
                                <span>سريع</span>
                              </span>
                            )}
                          </>
                        ) : 'شبكة'}
                      </span>
                    </div>
                    {invoice.paymentMethod === 'cash' && invoice.paidAmount !== undefined && (
                      <div className="flex justify-between items-center text-[11px] text-slate-400 bg-slate-900/40 px-2 py-1 rounded">
                        <span>المدفوع / الباقي:</span>
                        <span className="font-mono inline-flex items-center gap-0.5">
                          {convertAmount(invoice.paidAmount).toFixed(0)} / <strong className="text-emerald-400">{convertAmount(invoice.changeAmount || 0).toFixed(2)}</strong> {renderCurr(activeCurrObj.code, activeCurrObj.symbol)}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between pt-2 border-t border-slate-800/40">
                      <span className="text-slate-500">المجموع الفرعي:</span>
                      <span className="text-slate-300 font-mono inline-flex items-center gap-0.5">
                        {convSubTotal.toFixed(2)} {renderCurr(activeCurrObj.code, activeCurrObj.symbol)}
                      </span>
                    </div>
                    {invoice.discount && invoice.discount > 0 && (
                      <div className="flex justify-between text-amber-400">
                        <span className="text-amber-500/80">الخصم المطبق:</span>
                        <span className="font-mono font-bold inline-flex items-center gap-0.5">
                          - {convertAmount(invoice.discount).toFixed(2)} {renderCurr(activeCurrObj.code, activeCurrObj.symbol)}
                          {invoice.discountType === 'percent'
                            ? ` (${invoice.discountValue}%)`
                            : (invoice.discountScope === 'total' ? ' (ثابت من الإجمالي)' : ' (مبلغ ثابت)')}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-slate-500">الضريبة (15%):</span>
                      <span className="text-rose-400 font-mono inline-flex items-center gap-0.5">
                        {convTax.toFixed(2)} {renderCurr(activeCurrObj.code, activeCurrObj.symbol)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase tracking-widest font-bold">الإجمالي النهائي</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="font-mono font-black text-lg text-emerald-400 inline-flex items-center gap-1">
                        {convTotal.toFixed(2)} {renderCurr(activeCurrObj.code, activeCurrObj.symbol, "w-4 h-4")}
                      </span>
                      {isNonBase && (
                        <span className="text-[11px] text-slate-500 font-mono inline-flex items-center gap-0.5">
                          ({invoice.total.toFixed(2)} {renderCurr(baseCurrObj.code, baseCurrObj.symbol, "w-2.5 h-2.5")})
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button 
                      onClick={() => onViewInvoice(invoice)}
                      className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition border border-slate-700 cursor-pointer"
                      title="عرض الفاتورة وتغيير العملة"
                    >
                      <Eye className="w-4.5 h-4.5" />
                    </button>
                    <button 
                      onClick={() => onPrintInvoice && onPrintInvoice(invoice, displayCurrencyCode)}
                      className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition border border-slate-700 cursor-pointer"
                      title="طباعة"
                    >
                      <Printer className="w-4.5 h-4.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
