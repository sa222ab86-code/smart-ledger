import React from 'react';
import { 
  Package, Plus, Trash2, Ruler, Maximize2, Boxes, Sliders, CheckCircle2, 
  HelpCircle, Sparkles, Layers, Info
} from 'lucide-react';
import { ProductUnit } from '../types';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';

export interface PackagingPreset {
  id: string;
  title: string;
  badge: string;
  examples: string;
  icon: 'ruler' | 'maximize' | 'boxes' | 'sliders';
  generate: (basePrice: number, baseBarcode: string) => ProductUnit[];
}

export const PACKAGING_PRESETS: PackagingPreset[] = [
  {
    id: 'sizes',
    title: 'مقاسات (ملابس / مطاعم)',
    badge: 'مقاس',
    examples: 'صغير (S) • وسط (M) • كبير (L)',
    icon: 'ruler',
    generate: (basePrice: number, baseBarcode: string) => [
      { 
        id: `pkg-${Date.now()}-1`, 
        name: 'صغير (Small)', 
        factor: 1, 
        price: basePrice > 0 ? basePrice : 15, 
        barcode: baseBarcode ? `${baseBarcode}-S` : `${Math.floor(Math.random() * 900000 + 100000)}-S`, 
        unitType: 'size' 
      },
      { 
        id: `pkg-${Date.now()}-2`, 
        name: 'وسط (Medium)', 
        factor: 1.3, 
        price: Math.round(((basePrice > 0 ? basePrice : 15) * 1.35) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-M` : `${Math.floor(Math.random() * 900000 + 100000)}-M`, 
        unitType: 'size' 
      },
      { 
        id: `pkg-${Date.now()}-3`, 
        name: 'كبير (Large)', 
        factor: 1.7, 
        price: Math.round(((basePrice > 0 ? basePrice : 15) * 1.7) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-L` : `${Math.floor(Math.random() * 900000 + 100000)}-L`, 
        unitType: 'size' 
      },
    ]
  },
  {
    id: 'volumes',
    title: 'أحجام وسعات (مشروبات / سوائل)',
    badge: 'حجم / سعة',
    examples: 'كوب 250 مل • وسط 500 مل • جالون 1 لتر',
    icon: 'maximize',
    generate: (basePrice: number, baseBarcode: string) => [
      { 
        id: `pkg-${Date.now()}-1`, 
        name: 'كوب صغير (250 مل)', 
        factor: 1, 
        price: basePrice > 0 ? basePrice : 10, 
        barcode: baseBarcode ? `${baseBarcode}-250` : `${Math.floor(Math.random() * 900000 + 100000)}-250`, 
        unitType: 'volume' 
      },
      { 
        id: `pkg-${Date.now()}-2`, 
        name: 'كوب وسط (500 مل)', 
        factor: 1.5, 
        price: Math.round(((basePrice > 0 ? basePrice : 10) * 1.4) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-500` : `${Math.floor(Math.random() * 900000 + 100000)}-500`, 
        unitType: 'volume' 
      },
      { 
        id: `pkg-${Date.now()}-3`, 
        name: 'جالون عائلي (1 لتر)', 
        factor: 2.5, 
        price: Math.round(((basePrice > 0 ? basePrice : 10) * 2.2) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-1L` : `${Math.floor(Math.random() * 900000 + 100000)}-1L`, 
        unitType: 'volume' 
      },
    ]
  },
  {
    id: 'packs',
    title: 'عبوات تجزئة وكرتون (بقالة / مستودع)',
    badge: 'تعبئة وتجزئة',
    examples: 'حبة فردي • شدة (6) • كرتون (24)',
    icon: 'boxes',
    generate: (basePrice: number, baseBarcode: string) => [
      { 
        id: `pkg-${Date.now()}-1`, 
        name: 'حبة فردي (قطعة)', 
        factor: 1, 
        price: basePrice > 0 ? basePrice : 3, 
        barcode: baseBarcode || `${Math.floor(Math.random() * 900000 + 100000)}`, 
        unitType: 'pack' 
      },
      { 
        id: `pkg-${Date.now()}-2`, 
        name: 'شدة (6 حبات)', 
        factor: 6, 
        price: Math.round(((basePrice > 0 ? basePrice : 3) * 5.5) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-6` : `${Math.floor(Math.random() * 900000 + 100000)}-6`, 
        unitType: 'pack' 
      },
      { 
        id: `pkg-${Date.now()}-3`, 
        name: 'كرتون (24 حبة)', 
        factor: 24, 
        price: Math.round(((basePrice > 0 ? basePrice : 3) * 20) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-24` : `${Math.floor(Math.random() * 900000 + 100000)}-24`, 
        unitType: 'pack' 
      },
    ]
  },
  {
    id: 'weights',
    title: 'أوزان ومقادير (خضار / مكسرات / لحوم)',
    badge: 'وزن',
    examples: 'ربع كيلو • نصف كيلو • 1 كيلو',
    icon: 'sliders',
    generate: (basePrice: number, baseBarcode: string) => [
      { 
        id: `pkg-${Date.now()}-1`, 
        name: 'ربع كيلو (250 جم)', 
        factor: 0.25, 
        price: Math.round(((basePrice > 0 ? basePrice : 40) * 0.28) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-250g` : `${Math.floor(Math.random() * 900000 + 100000)}-250g`, 
        unitType: 'weight' 
      },
      { 
        id: `pkg-${Date.now()}-2`, 
        name: 'نصف كيلو (500 جم)', 
        factor: 0.5, 
        price: Math.round(((basePrice > 0 ? basePrice : 40) * 0.52) * 100) / 100, 
        barcode: baseBarcode ? `${baseBarcode}-500g` : `${Math.floor(Math.random() * 900000 + 100000)}-500g`, 
        unitType: 'weight' 
      },
      { 
        id: `pkg-${Date.now()}-3`, 
        name: 'واحد كيلو (1 كجم)', 
        factor: 1, 
        price: basePrice > 0 ? basePrice : 40, 
        barcode: baseBarcode ? `${baseBarcode}-1kg` : `${Math.floor(Math.random() * 900000 + 100000)}-1kg`, 
        unitType: 'weight' 
      },
    ]
  }
];

interface PackagingEditorProps {
  hasPackaging: boolean;
  onToggleHasPackaging: (enabled: boolean) => void;
  packagingList: ProductUnit[];
  basePrice: number;
  baseBarcode: string;
  onAddRow: (type?: 'size' | 'volume' | 'pack' | 'weight' | 'unit') => void;
  onUpdateRow: (id: string, updates: Partial<ProductUnit>) => void;
  onRemoveRow: (id: string) => void;
  onApplyPreset: (presetId: string) => void;
}

export default function PackagingEditor({
  hasPackaging,
  onToggleHasPackaging,
  packagingList,
  basePrice,
  baseBarcode,
  onAddRow,
  onUpdateRow,
  onRemoveRow,
  onApplyPreset
}: PackagingEditorProps) {
  return (
    <div className="col-span-2 border border-slate-800 bg-[#0A0A0A] rounded-2xl p-4 sm:p-5 space-y-4">
      
      {/* Header and Toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-black text-sm text-white">نظام التعبئة والمقاسات والأحجام</h4>
              <span className="text-[10px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded-full">
                اختيار سريع عند البيع
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-0.5">
              تحديد مقاسات (صغير/وسط/كبير)، أو أحجام وسعات (250مل/1لتر)، أو تعبئات (حبة/شدة/كرتون) للصنف.
            </p>
          </div>
        </div>

        {/* Toggle Button */}
        <label className="inline-flex items-center gap-2 cursor-pointer shrink-0 self-end sm:self-center">
          <span className="text-xs font-bold text-slate-300">
            {hasPackaging ? 'مفعل' : 'معطل'}
          </span>
          <div className="relative">
            <input 
              type="checkbox" 
              checked={hasPackaging}
              onChange={(e) => onToggleHasPackaging(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
          </div>
        </label>
      </div>

      {hasPackaging && (
        <div className="space-y-4 animate-in fade-in duration-200">
          
          {/* Quick Preset Buttons */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>قوالب تعبئة ومقاسات جاهزة بنقرة واحدة:</span>
              </span>
              <span className="text-[11px] text-slate-500">
                (يتم توليد الأسعار والباركود تلقائياً)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PACKAGING_PRESETS.map(preset => {
                const getIcon = () => {
                  switch (preset.icon) {
                    case 'ruler': return <Ruler className="w-3.5 h-3.5 text-blue-400" />;
                    case 'maximize': return <Maximize2 className="w-3.5 h-3.5 text-emerald-400" />;
                    case 'boxes': return <Boxes className="w-3.5 h-3.5 text-purple-400" />;
                    case 'sliders': return <Sliders className="w-3.5 h-3.5 text-amber-400" />;
                  }
                };

                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => onApplyPreset(preset.id)}
                    className="p-2.5 bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 rounded-xl text-right transition-all flex flex-col justify-between group cursor-pointer"
                  >
                    <div className="flex items-center justify-between gap-1 w-full mb-1">
                      <div className="flex items-center gap-1.5">
                        {getIcon()}
                        <span className="font-bold text-xs text-slate-200 group-hover:text-cyan-300">
                          {preset.title.split(' ')[0]}
                        </span>
                      </div>
                      <span className="text-[9px] font-mono bg-slate-800 text-slate-400 px-1 py-0.5 rounded">
                        +{preset.generate(10, '').length}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 group-hover:text-slate-400 truncate">
                      {preset.examples}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* List of Packaging Options */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>خيارات التعبئة والمقاسات للصنف ({packagingList.length}):</span>
              </span>

              <button
                type="button"
                onClick={() => onAddRow('size')}
                className="text-xs text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 cursor-pointer bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-800/60 px-2.5 py-1 rounded-lg transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة خيار يدوي</span>
              </button>
            </div>

            {packagingList.length === 0 ? (
              <div className="p-6 border border-dashed border-slate-800 rounded-xl text-center text-slate-500 space-y-2">
                <Boxes className="w-8 h-8 mx-auto text-slate-600 opacity-60" />
                <p className="text-xs font-bold">لم تتم إضافة أي خيارات تعبئة أو مقاسات بعد</p>
                <p className="text-[11px] text-slate-600">
                  اختر أحد القوالب الجاهزة بالأعلى أو اضغط &quot;إضافة خيار يدوي&quot; لتعريف المقاسات أو العبوات.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
                {packagingList.map((unit, index) => (
                  <div 
                    key={unit.id}
                    className="p-3 bg-slate-900/90 border border-slate-800 rounded-xl flex flex-col md:flex-row items-stretch md:items-center gap-2.5 text-xs transition hover:border-slate-700"
                  >
                    {/* Index & Type Selector */}
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] font-mono font-bold text-slate-500 w-4 text-center">
                        {index + 1}
                      </span>
                      <select
                        value={unit.unitType || 'size'}
                        onChange={(e) => onUpdateRow(unit.id, { unitType: e.target.value as any })}
                        className="bg-black/60 border border-slate-700/80 rounded-lg px-2 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-400 font-bold cursor-pointer"
                        title="نوع التعبئة أو المقاس"
                      >
                        <option value="size">مقاس (Size)</option>
                        <option value="volume">حجم / سعة (Volume)</option>
                        <option value="pack">عبوة / كرتون (Pack)</option>
                        <option value="weight">وزن (Weight)</option>
                        <option value="unit">وحدة أخرى (Unit)</option>
                      </select>
                    </div>

                    {/* Name Input */}
                    <div className="flex-1 min-w-[120px]">
                      <input 
                        type="text"
                        required
                        placeholder="اسم المقاس/الحجم (مثال: كبير L، كرتون 24...)"
                        value={unit.name}
                        onChange={(e) => onUpdateRow(unit.id, { name: e.target.value })}
                        className="w-full bg-black/60 border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-bold placeholder:text-slate-600"
                      />
                    </div>

                    {/* Factor / Pieces */}
                    <div className="w-20 shrink-0">
                      <div className="relative">
                        <input 
                          type="number"
                          step="0.1"
                          min="0.1"
                          title="معامل التحويل أو عدد القطع في هذه العبوة"
                          placeholder="المعامل"
                          value={unit.factor}
                          onChange={(e) => onUpdateRow(unit.id, { factor: parseFloat(e.target.value) || 1 })}
                          className="w-full bg-black/60 border border-slate-700/80 rounded-lg px-2 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-400 font-mono font-bold text-center"
                        />
                        <span className="absolute -top-3 right-1 text-[9px] text-slate-500 font-medium pointer-events-none">
                          القطع
                        </span>
                      </div>
                    </div>

                    {/* Selling Price Input */}
                    <div className="w-28 shrink-0">
                      <div className="relative">
                        <input 
                          type="number"
                          step="0.01"
                          required
                          title="سعر البيع للتعبئة (شامل الضريبة)"
                          placeholder="السعر"
                          value={unit.price}
                          onChange={(e) => onUpdateRow(unit.id, { price: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-black/60 border border-slate-700/80 rounded-lg pl-6 pr-2 py-1.5 text-xs text-cyan-300 focus:outline-none focus:border-cyan-400 font-mono font-black text-left"
                        />
                        <span className="absolute left-1.5 top-2 pointer-events-none">
                          <SaudiRiyalSymbol className="w-3 h-3 text-cyan-400 opacity-80" />
                        </span>
                        <span className="absolute -top-3 right-1 text-[9px] text-slate-500 font-medium pointer-events-none">
                          السعر
                        </span>
                      </div>
                    </div>

                    {/* Barcode Input */}
                    <div className="w-28 shrink-0">
                      <div className="relative">
                        <input 
                          type="text"
                          title="باركود التعبئة الخاص للبيع الفوري بالماسح"
                          placeholder="باركود التعبئة"
                          value={unit.barcode}
                          onChange={(e) => onUpdateRow(unit.id, { barcode: e.target.value })}
                          className="w-full bg-black/60 border border-slate-700/80 rounded-lg px-2 py-1.5 text-xs text-slate-400 focus:outline-none focus:border-cyan-400 font-mono text-center placeholder:text-slate-600"
                        />
                        <span className="absolute -top-3 right-1 text-[9px] text-slate-500 font-medium pointer-events-none">
                          الباركود
                        </span>
                      </div>
                    </div>

                    {/* Delete Row Button */}
                    <button
                      type="button"
                      onClick={() => onRemoveRow(unit.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition shrink-0 cursor-pointer self-end md:self-center"
                      title="حذف هذا الخيار"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Helpful Information Notice */}
          <div className="bg-cyan-950/20 border border-cyan-900/40 rounded-xl p-3 flex items-start gap-2 text-[11px] text-cyan-300">
            <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p className="font-bold">
                كيف تظهر التعبئة في نقطة البيع (POS)؟
              </p>
              <p className="text-slate-400 leading-relaxed">
                عند النقر على الصنف في شاشة الكاشير، ستظهر نافذة فورية تسأل عن المقاس أو الحجم المطلوب (مثل: سنجل / دبل، أو حبة / شدة / كرتون). كما يمكنك مسح باركود التعبئة بالماسح لإدراجها مباشرة.
              </p>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
