import React from 'react';
import { LogOut, Globe } from 'lucide-react';
import appIcon from '../assets/app-icon.svg';

interface TopBarProps {
  onLogout: () => void;
  /** أيقونة البرنامج المختارة من الإعدادات */
  iconSrc?: string;
  activeLanguage: string;
}

export default function TopBar({ onLogout, activeLanguage, iconSrc }: TopBarProps) {
  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 h-16 px-6 flex items-center justify-between text-slate-900 dark:text-white select-none">
      <div className="flex items-center gap-4">
        <img src={iconSrc || appIcon} alt="" className="w-9 h-9 rounded-lg object-contain" />
        <div className="leading-tight">
          <div className="text-lg font-black text-cyan-800 dark:text-cyan-300">الدفتر الذكي</div>
          <div className="text-[11px] font-bold text-brass-600 dark:text-brass-400">لوحة تحكم البدر</div>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 font-bold">
          <Globe className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
          <span>العربية (AR)</span>
        </div>
        <button onClick={onLogout} className="flex items-center gap-2 px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-lg text-xs font-bold transition border border-rose-500/20 cursor-pointer">
          <LogOut className="w-4 h-4" />
          <span>خروج</span>
        </button>
      </div>
    </header>
  );
}
