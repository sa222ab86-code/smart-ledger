import React from 'react';
import { LogOut, Globe } from 'lucide-react';

interface TopBarProps {
  onLogout: () => void;
  activeLanguage: string;
}

export default function TopBar({ onLogout, activeLanguage }: TopBarProps) {
  return (
    <header className="bg-slate-900 border-b border-slate-800 h-16 px-6 flex items-center justify-between text-white select-none">
      <div className="flex items-center gap-4">
        <span className="text-xl font-bold bg-gradient-to-l from-cyan-400 to-blue-500 bg-clip-text text-transparent">لوحة تحكم البدر</span>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 font-bold">
          <Globe className="w-4 h-4 text-cyan-400" />
          <span>العربية (AR)</span>
        </div>
        <button onClick={onLogout} className="flex items-center gap-2 px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-lg text-xs font-bold transition border border-rose-500/20 cursor-pointer">
          <LogOut className="w-4 h-4" />
          <span>خروج</span>
        </button>
      </div>
    </header>
  );
}
