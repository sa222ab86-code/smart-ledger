import React, { useEffect, useMemo, useState } from 'react';
import { Barcode, Printer, X, Search } from 'lucide-react';
import type { Product } from '../types';
import type { OsPrinter } from '../storage/persistence';
import { usePersistentState } from '../storage/persistence';
import { encodeBarcode, generateInternalEan13, labelsHtml, type LabelItem } from '../utils/barcode';
import { listOsPrinters, printHtmlDocument, type PrintSettings } from '../utils/printing';

interface Props {
  products: Product[];
  initialIds: string[];
  companyName: string;
  taxRatePercent?: number;
  pricesIncludeTax?: boolean;
  printSettings: PrintSettings;
  onChangePrintSettings: (updater: (prev: PrintSettings) => PrintSettings) => void;
  onUpdateProduct?: (id: string, updated: Partial<Product>) => void;
  notify: (msg: string) => void;
  onClose: () => void;
}

interface LabelSettings {
  presetId: string;
  widthMm: number;
  heightMm: number;
  showName: boolean;
  showPrice: boolean;
  showCompany: boolean;
  // ---- تحكم متقدم ----
  barHeightMm?: number;     // 0 = تلقائي
  moduleMm?: number;        // 0 = تلقائي (يملأ العرض)
  nameFontPt?: number;      // 0 = تلقائي
  priceFontPt?: number;
  codeFontPt?: number;
  companyFontPt?: number;
  boldName?: boolean;
  showBarcodeText?: boolean;
  priceBasis?: 'withTax' | 'beforeTax';
  showTaxNote?: boolean;
  taxNoteText?: string;
  currencyMode?: 'riyal' | 'text' | 'none';
  currencyText?: string;
}

const PRESETS: { id: string; label: string; w: number; h: number }[] = [
  { id: '50x30', label: '50 × 30 مم', w: 50, h: 30 },
  { id: '40x30', label: '40 × 30 مم', w: 40, h: 30 },
  { id: '40x25', label: '40 × 25 مم', w: 40, h: 25 },
  { id: '38x25', label: '38 × 25 مم', w: 38, h: 25 },
  { id: '58x40', label: '58 × 40 مم', w: 58, h: 40 },
  { id: '60x40', label: '60 × 40 مم', w: 60, h: 40 },
  { id: 'custom', label: 'مقاس مخصص', w: 50, h: 30 },
];

const defaultLabelSettings: LabelSettings = {
  presetId: '50x30', widthMm: 50, heightMm: 30, showName: true, showPrice: true, showCompany: false,
  barHeightMm: 0, moduleMm: 0, nameFontPt: 0, priceFontPt: 0, codeFontPt: 0, companyFontPt: 0, boldName: true, showBarcodeText: true,
  priceBasis: 'withTax', showTaxNote: true, taxNoteText: 'شامل الضريبة', currencyMode: 'riyal', currencyText: 'ر.س',
};

const inp = 'w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:border-cyan-500';

export default function BarcodeLabelsDialog({
  products, initialIds, companyName, taxRatePercent = 15, pricesIncludeTax = false, printSettings, onChangePrintSettings, onUpdateProduct, notify, onClose,
}: Props) {
  const [savedSettings, setSettings] = usePersistentState<LabelSettings>('labelSettings', defaultLabelSettings);
  // الإعدادات المحفوظة من إصدار سابق لا تحتوي الحقول الجديدة
  const settings: LabelSettings = { ...defaultLabelSettings, ...savedSettings };
  const [showAdvanced, setShowAdvanced] = useState(false);
  const rate = Math.max(0, taxRatePercent) / 100;
  /** السعر المطبوع على الملصق: شامل الضريبة أو قبلها مهما كانت طريقة إدخال أسعار الأصناف */
  const labelPrice = (p: Product) => {
    const withTax = pricesIncludeTax ? p.price : p.price * (1 + rate);
    const v = settings.priceBasis === 'beforeTax' ? withTax / (1 + rate) : withTax;
    return Math.round(v * 100) / 100;
  };
  const [selected, setSelected] = useState<Record<string, number>>(() => Object.fromEntries(initialIds.map((id) => [id, 1])));
  const [generated, setGenerated] = useState<Record<string, string>>({});
  const [search, setSearch] = useState('');
  const [silent, setSilent] = useState(printSettings.silent);
  const [osPrinters, setOsPrinters] = useState<OsPrinter[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => { void listOsPrinters().then(setOsPrinters); }, []);

  const barcodeOf = (p: Product) => (generated[p.id] ?? p.barcode ?? '').trim();

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products
      .filter((p) => !p.isBundle)
      .filter((p) => !q || p.nameAr.toLowerCase().includes(q) || (p.nameEn || '').toLowerCase().includes(q) || (p.barcode || '').includes(q))
      .slice(0, 300);
  }, [products, search]);

  const chosen = products.filter((p) => selected[p.id] !== undefined);
  const printable = chosen.filter((p) => !!encodeBarcode(barcodeOf(p)));
  const unprintable = chosen.filter((p) => !encodeBarcode(barcodeOf(p)));
  const totalLabels = printable.reduce((n, p) => n + (selected[p.id] || 1), 0);

  const items: LabelItem[] = useMemo(
    () => printable.flatMap((p) => Array.from({ length: selected[p.id] || 1 }, () => ({ name: p.nameAr, barcode: barcodeOf(p), price: labelPrice(p) }))),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [printable.map((p) => `${p.id}:${selected[p.id]}:${barcodeOf(p)}:${p.price}`).join('|'), settings.priceBasis, rate, pricesIncludeTax]
  );

  const defaultTaxNote = settings.priceBasis === 'beforeTax' ? 'غير شامل الضريبة' : 'شامل الضريبة';
  const labelOpts = {
    widthMm: settings.widthMm, heightMm: settings.heightMm, showName: settings.showName,
    showPrice: settings.showPrice, showCompany: settings.showCompany, company: companyName,
    currencyMode: settings.currencyMode, currency: settings.currencyText,
    taxNote: settings.showTaxNote ? (settings.taxNoteText?.trim() || defaultTaxNote) : '',
    showBarcodeText: settings.showBarcodeText, barHeightMm: settings.barHeightMm, moduleMm: settings.moduleMm,
    nameFontPt: settings.nameFontPt, priceFontPt: settings.priceFontPt, codeFontPt: settings.codeFontPt,
    companyFontPt: settings.companyFontPt, boldName: settings.boldName,
  };
  const num = (k: keyof LabelSettings, min: number, max: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = Number(e.target.value);
    setSettings((s) => ({ ...defaultLabelSettings, ...s, [k]: Number.isFinite(v) ? Math.max(min, Math.min(max, v)) : 0 }));
  };
  const setOpt = (patch: Partial<LabelSettings>) => setSettings((s) => ({ ...defaultLabelSettings, ...s, ...patch }));
  const previewHtml = items.length ? labelsHtml([items[0]], labelOpts) : '';

  const toggle = (p: Product) =>
    setSelected((s) => {
      const n = { ...s };
      if (n[p.id] !== undefined) delete n[p.id]; else n[p.id] = 1;
      return n;
    });
  const setCopies = (id: string, v: number) => setSelected((s) => ({ ...s, [id]: Math.max(1, Math.min(999, Math.floor(v) || 1)) }));
  const allVisibleSelected = visible.length > 0 && visible.every((p) => selected[p.id] !== undefined);
  const toggleAll = () =>
    setSelected((s) => {
      const n = { ...s };
      if (allVisibleSelected) visible.forEach((p) => delete n[p.id]);
      else visible.forEach((p) => { if (n[p.id] === undefined) n[p.id] = 1; });
      return n;
    });

  const setPreset = (id: string) => {
    const pr = PRESETS.find((x) => x.id === id)!;
    setSettings((s) => (id === 'custom' ? { ...s, presetId: id } : { ...s, presetId: id, widthMm: pr.w, heightMm: pr.h }));
  };

  const generateMissing = () => {
    if (!onUpdateProduct) return;
    const taken = new Set<string>(products.map((p) => (generated[p.id] ?? p.barcode ?? '').trim()).filter(Boolean));
    const next: Record<string, string> = {};
    for (const p of chosen) {
      if (barcodeOf(p)) continue;
      const code = generateInternalEan13(taken);
      taken.add(code);
      next[p.id] = code;
      onUpdateProduct(p.id, { barcode: code });
    }
    if (Object.keys(next).length) {
      setGenerated((g) => ({ ...g, ...next }));
      notify(`تم توليد ${Object.keys(next).length} باركود وحفظه في الأصناف`);
    }
  };

  const doPrint = async () => {
    if (!items.length || busy) return;
    setBusy(true);
    try {
      const html = labelsHtml(items, labelOpts);
      const res = await printHtmlDocument(html, {
        silent,
        deviceName: printSettings.labelPrinter || undefined,
        pageSizeMm: { width: settings.widthMm, height: settings.heightMm },
      });
      notify(res.ok ? `تم إرسال ${items.length} ملصق للطباعة` : `لم تتم الطباعة${res.reason ? ': ' + res.reason : ''}`);
    } catch (e) {
      console.error(e);
      notify('تعذرت الطباعة');
    } finally {
      setBusy(false);
    }
  };

  const noBarcodeSelected = chosen.filter((p) => !barcodeOf(p)).length;

  return (
    <div className="fixed inset-0 z-[9997] bg-black/70 flex items-center justify-center p-3" dir="rtl">
      <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 w-full max-w-5xl max-h-[94vh] rounded-2xl shadow-2xl flex flex-col text-right">
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
          <h3 className="font-black text-lg text-cyan-700 dark:text-cyan-300 flex items-center gap-2"><Barcode className="w-5 h-5" /> طباعة ملصقات الباركود</h3>
          <button onClick={onClose}><X className="w-5 h-5 text-slate-500 dark:text-slate-400" /></button>
        </div>

        <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-5 gap-4 p-4 overflow-y-auto">
          {/* الأصناف */}
          <div className="lg:col-span-3 flex flex-col min-h-0">
            <div className="flex gap-2 mb-2">
              <div className="relative flex-1">
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث بالاسم أو الباركود..." className={`${inp} pr-9`} />
                <Search className="w-4 h-4 text-slate-500 absolute right-3 top-2.5" />
              </div>
              <button onClick={toggleAll} className="px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold whitespace-nowrap">{allVisibleSelected ? 'إلغاء تحديد الكل' : 'تحديد الكل'}</button>
            </div>
            <div className="flex-1 min-h-[240px] max-h-[48vh] overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-200 dark:divide-slate-800">
              {visible.length === 0 && <div className="p-6 text-center text-slate-500 text-sm font-bold">لا توجد أصناف.</div>}
              {visible.map((p) => {
                const code = barcodeOf(p);
                const ok = !!encodeBarcode(code);
                const on = selected[p.id] !== undefined;
                return (
                  <div key={p.id} className={`flex items-center gap-3 px-3 py-2 ${on ? 'bg-cyan-500/5' : ''}`}>
                    <input type="checkbox" checked={on} onChange={() => toggle(p)} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold truncate">{p.nameAr}</div>
                      <div className={`text-[11px] font-mono ${code ? (ok ? 'text-slate-500' : 'text-amber-600 dark:text-amber-400') : 'text-rose-600 dark:text-rose-400'}`} dir="ltr">
                        {code ? (ok ? code : `${code} (غير قابل للترميز)`) : 'بدون باركود'}
                      </div>
                    </div>
                    <span className="text-xs font-mono text-cyan-700 dark:text-cyan-300" title="السعر المطبوع على الملصق">{labelPrice(p).toFixed(2)}</span>
                    {on && (
                      <input type="number" min={1} max={999} value={selected[p.id]} onChange={(e) => setCopies(p.id, Number(e.target.value))} title="عدد النسخ" className="w-16 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1 text-sm text-center font-mono" />
                    )}
                  </div>
                );
              })}
            </div>
            {(unprintable.length > 0) && (
              <div className="mt-2 text-xs font-bold text-amber-600 dark:text-amber-400">
                {noBarcodeSelected > 0 ? `${noBarcodeSelected} صنف محدد بدون باركود. ` : ''}
                {unprintable.length - noBarcodeSelected > 0 ? `${unprintable.length - noBarcodeSelected} باركود غير قابل للترميز (حروف غير لاتينية). ` : ''}
                لن تُطبع هذه الأصناف.
              </div>
            )}
            {noBarcodeSelected > 0 && onUpdateProduct && (
              <button onClick={generateMissing} className="mt-2 self-start px-4 py-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs font-black hover:bg-amber-500/25">
                توليد باركود (EAN-13) للأصناف المحددة التي بلا باركود وحفظه فيها
              </button>
            )}
          </div>

          {/* الإعدادات والمعاينة */}
          <div className="lg:col-span-2 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2">
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400">مقاس الملصق</label>
                <select value={settings.presetId} onChange={(e) => setPreset(e.target.value)} className={inp}>
                  {PRESETS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
                </select>
              </div>
              {settings.presetId === 'custom' && (
                <>
                  <div><label className="text-xs font-bold text-slate-500 dark:text-slate-400">العرض (مم)</label><input type="number" min={20} max={200} value={settings.widthMm} onChange={(e) => setSettings((s) => ({ ...s, widthMm: Math.max(20, Number(e.target.value) || 50) }))} className={`${inp} font-mono`} /></div>
                  <div><label className="text-xs font-bold text-slate-500 dark:text-slate-400">الارتفاع (مم)</label><input type="number" min={15} max={200} value={settings.heightMm} onChange={(e) => setSettings((s) => ({ ...s, heightMm: Math.max(15, Number(e.target.value) || 30) }))} className={`${inp} font-mono`} /></div>
                </>
              )}
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm font-bold">
              <label className="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" checked={settings.showName} onChange={(e) => setSettings((s) => ({ ...s, showName: e.target.checked }))} /> اسم الصنف</label>
              <label className="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" checked={settings.showPrice} onChange={(e) => setSettings((s) => ({ ...s, showPrice: e.target.checked }))} /> السعر</label>
              <label className="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" checked={settings.showCompany} onChange={(e) => setSettings((s) => ({ ...s, showCompany: e.target.checked }))} /> اسم المنشأة</label>
              <label className="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" checked={settings.showBarcodeText !== false} onChange={(e) => setOpt({ showBarcodeText: e.target.checked })} /> رقم الباركود</label>
            </div>

            {/* السعر والضريبة والعملة */}
            {settings.showPrice && (
              <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">السعر المطبوع</label>
                  <select value={settings.priceBasis} onChange={(e) => setOpt({ priceBasis: e.target.value as LabelSettings['priceBasis'] })} className={inp}>
                    <option value="withTax">شامل الضريبة</option>
                    <option value="beforeTax">قبل الضريبة</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">رمز العملة</label>
                  <select value={settings.currencyMode} onChange={(e) => setOpt({ currencyMode: e.target.value as LabelSettings['currencyMode'] })} className={inp}>
                    <option value="riyal">رمز الريال الرسمي ⃁</option>
                    <option value="text">نص (ر.س / SAR)</option>
                    <option value="none">بدون</option>
                  </select>
                </div>
                {settings.currencyMode === 'text' && (
                  <div className="col-span-2"><input value={settings.currencyText} onChange={(e) => setOpt({ currencyText: e.target.value })} placeholder="ر.س" className={inp} /></div>
                )}
                <label className="col-span-2 flex items-center gap-1.5 text-sm font-bold cursor-pointer">
                  <input type="checkbox" checked={!!settings.showTaxNote} onChange={(e) => setOpt({ showTaxNote: e.target.checked })} /> إظهار عبارة الضريبة تحت السعر
                </label>
                {settings.showTaxNote && (
                  <div className="col-span-2"><input value={settings.taxNoteText} onChange={(e) => setOpt({ taxNoteText: e.target.value })} placeholder={defaultTaxNote} className={inp} /></div>
                )}
              </div>
            )}

            {/* تحكم متقدم: الخطوط والكتابة */}
            <button type="button" onClick={() => setShowAdvanced((v) => !v)} className="text-xs font-black text-cyan-700 dark:text-cyan-300 hover:underline">
              {showAdvanced ? '▲ إخفاء' : '▼ إظهار'} التحكم بالخطوط والكتابة
            </button>
            {showAdvanced && (
              <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                <div><label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">ارتفاع خطوط الباركود (مم)</label><input type="number" min={0} max={150} step={1} value={settings.barHeightMm} onChange={num('barHeightMm', 0, 150)} className={`${inp} font-mono`} /></div>
                <div><label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">سماكة الخط (مم)</label><input type="number" min={0} max={1} step={0.05} value={settings.moduleMm} onChange={num('moduleMm', 0, 1)} className={`${inp} font-mono`} /></div>
                <div><label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">حجم اسم الصنف (pt)</label><input type="number" min={0} max={40} step={0.5} value={settings.nameFontPt} onChange={num('nameFontPt', 0, 40)} className={`${inp} font-mono`} /></div>
                <div><label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">حجم السعر (pt)</label><input type="number" min={0} max={40} step={0.5} value={settings.priceFontPt} onChange={num('priceFontPt', 0, 40)} className={`${inp} font-mono`} /></div>
                <div><label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">حجم رقم الباركود (pt)</label><input type="number" min={0} max={30} step={0.5} value={settings.codeFontPt} onChange={num('codeFontPt', 0, 30)} className={`${inp} font-mono`} /></div>
                <div><label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">حجم اسم المنشأة (pt)</label><input type="number" min={0} max={30} step={0.5} value={settings.companyFontPt} onChange={num('companyFontPt', 0, 30)} className={`${inp} font-mono`} /></div>
                <label className="col-span-2 flex items-center gap-1.5 text-sm font-bold cursor-pointer"><input type="checkbox" checked={settings.boldName !== false} onChange={(e) => setOpt({ boldName: e.target.checked })} /> اسم الصنف بخط عريض</label>
                <p className="col-span-2 text-[11px] text-slate-400">القيمة 0 = تلقائي حسب مقاس الملصق. سماكة الخط تحدد عرض الباركود (0.25–0.35 مم مناسبة لمعظم القارئات).</p>
                <button type="button" onClick={() => setOpt({ barHeightMm: 0, moduleMm: 0, nameFontPt: 0, priceFontPt: 0, codeFontPt: 0, companyFontPt: 0, boldName: true })} className="col-span-2 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-bold">إرجاع الكل للتلقائي</button>
              </div>
            )}

            <div>
              <label className="text-xs font-bold text-slate-500 dark:text-slate-400">طابعة الملصقات</label>
              {osPrinters.length > 0 ? (
                <select value={printSettings.labelPrinter} onChange={(e) => onChangePrintSettings((p) => ({ ...p, labelPrinter: e.target.value }))} className={inp} dir="ltr">
                  <option value="">طابعة النظام الافتراضية</option>
                  {osPrinters.map((p) => <option key={p.name} value={p.name}>{p.displayName}</option>)}
                </select>
              ) : (
                <input value={printSettings.labelPrinter} onChange={(e) => onChangePrintSettings((p) => ({ ...p, labelPrinter: e.target.value }))} placeholder={window.ledger ? 'لم تُكتشف طابعات — اكتب الاسم' : 'متاح في النسخة المكتبية'} className={inp} dir="ltr" />
              )}
              <label className="flex items-center gap-2 mt-2 text-sm font-bold cursor-pointer">
                <input type="checkbox" checked={silent} onChange={(e) => setSilent(e.target.checked)} disabled={!window.ledger} />
                طباعة صامتة (مباشرة بدون نافذة الطباعة)
              </label>
            </div>

            <div>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-1">معاينة (أول ملصق)</div>
              <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex items-center justify-center min-h-[150px] overflow-hidden">
                {previewHtml ? (
                  <div style={{ width: `${settings.widthMm * 3.78 * 1.6}px`, height: `${settings.heightMm * 3.78 * 1.6}px` }} className="bg-white shadow">
                    <iframe
                      title="معاينة"
                      srcDoc={previewHtml}
                      sandbox=""
                      style={{ width: `${settings.widthMm * 3.78}px`, height: `${settings.heightMm * 3.78}px`, border: 0, transform: 'scale(1.6)', transformOrigin: 'top left' }}
                    />
                  </div>
                ) : (
                  <span className="text-xs font-bold text-slate-500">حدّد صنفاً له باركود لعرض المعاينة</span>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3 justify-between">
          <span className="text-sm font-bold text-slate-500 dark:text-slate-400">إجمالي الملصقات: <span className="font-mono text-cyan-700 dark:text-cyan-300 text-base">{totalLabels}</span></span>
          <div className="flex gap-2">
            <button onClick={onClose} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-sm">إغلاق</button>
            <button disabled={!items.length || busy} onClick={doPrint} className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-black text-sm flex items-center gap-2 disabled:opacity-40">
              <Printer className="w-4 h-4" /> {silent && window.ledger ? 'طباعة صامتة' : 'طباعة'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
