import { useMemo, useState } from 'react';
import {
  FileText, Plus, Search, Printer, FileDown, Pencil, Trash2, Copy, ArrowLeftRight, X, Eye,
} from 'lucide-react';
import type { Customer, Product, Quotation, QuotationItem, QuotationStatus } from '../types';
import {
  DEFAULT_TERMS, STATUS_LABEL, addDaysYmd, calcQuotation, isExpired, nextQuotationNumber, quotationHtml,
} from '../utils/quotations';
import { localTimestamp } from '../utils/files';
import { exportHtmlAsPdf, printHtmlDocument, type PrintSettings } from '../utils/printing';
import { round2 } from '../utils/invoiceMath';

export interface ConvertOptions { method: 'cash' | 'card'; credit: boolean; paid: number }

interface Props {
  quotations: Quotation[];
  setQuotations: (updater: (prev: Quotation[]) => Quotation[]) => void;
  customers: Customer[];
  products: Product[];
  taxRatePercent: number;
  /** أسعار الأصناف شاملة الضريبة؟ (بنود العرض تُخزَّن قبل الضريبة) */
  pricesIncludeTax?: boolean;
  company: { name: string; vat: string; address?: string; phone?: string; mobile?: string; logoUrl?: string };
  printSettings: PrintSettings;
  notify: (msg: string) => void;
  onConvert: (q: Quotation, opts: ConvertOptions) => void;
}

const STATUS_STYLE: Record<QuotationStatus, string> = {
  draft: 'bg-slate-500/15 text-slate-600 dark:text-slate-300 border-slate-500/30',
  sent: 'bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30',
  accepted: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30',
  rejected: 'bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/30',
  invoiced: 'bg-violet-500/15 text-violet-700 dark:text-violet-300 border-violet-500/30',
};

const inp = 'w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:border-cyan-500';

const blank = (all: Quotation[], taxRate: number): Quotation => ({
  id: `qt-${Date.now()}`,
  number: nextQuotationNumber(all),
  date: localTimestamp(),
  validUntil: addDaysYmd(15),
  customerName: '',
  items: [],
  discountType: 'fixed',
  discountValue: 0,
  taxRate,
  rawSubtotal: 0, discount: 0, subtotal: 0, tax: 0, total: 0,
  notes: '',
  terms: DEFAULT_TERMS,
  status: 'draft',
});

export default function QuotationsManager({
  quotations, setQuotations, customers, products, taxRatePercent, pricesIncludeTax, company, printSettings, notify, onConvert,
}: Props) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | QuotationStatus | 'expired'>('all');
  const [editing, setEditing] = useState<Quotation | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [productQuery, setProductQuery] = useState('');
  const [converting, setConverting] = useState<Quotation | null>(null);
  const [convMethod, setConvMethod] = useState<'cash' | 'card'>('cash');
  const [convCredit, setConvCredit] = useState(false);
  const [convPaid, setConvPaid] = useState('');

  const list = useMemo(() => {
    const q = search.trim().toLowerCase();
    return quotations.filter((x) => {
      if (statusFilter === 'expired' ? !isExpired(x) : statusFilter !== 'all' && x.status !== statusFilter) return false;
      return !q || x.number.toLowerCase().includes(q) || x.customerName.toLowerCase().includes(q);
    });
  }, [quotations, search, statusFilter]);

  const totals = useMemo(
    () => (editing ? calcQuotation(editing.items, editing.discountType, editing.discountValue, editing.taxRate) : null),
    [editing]
  );

  /* ---------------- تحرير ---------------- */
  const openNew = () => { setEditing(blank(quotations, taxRatePercent)); setIsNew(true); setProductQuery(''); };
  const openEdit = (q: Quotation) => { setEditing({ ...q, items: q.items.map((i) => ({ ...i })) }); setIsNew(false); setProductQuery(''); };
  const patch = (p: Partial<Quotation>) => setEditing((e) => (e ? { ...e, ...p } : e));
  const patchItem = (id: string, p: Partial<QuotationItem>) =>
    setEditing((e) => (e ? { ...e, items: e.items.map((i) => (i.id === id ? { ...i, ...p } : i)) } : e));

  const addProduct = (p: Product) => {
    setEditing((e) => {
      if (!e) return e;
      const existing = e.items.find((i) => i.productId === p.id);
      if (existing) return { ...e, items: e.items.map((i) => (i === existing ? { ...i, qty: i.qty + 1 } : i)) };
      return { ...e, items: [...e.items, { id: `ql-${Date.now()}-${e.items.length}`, productId: p.id, name: p.nameAr, qty: 1, price: pricesIncludeTax ? Math.round((p.price / (1 + (e.taxRate || 0) / 100)) * 10000) / 10000 : p.price }] };
    });
    setProductQuery('');
  };
  const addFreeLine = () =>
    setEditing((e) => (e ? { ...e, items: [...e.items, { id: `ql-${Date.now()}-${e.items.length}`, name: '', qty: 1, price: 0 }] } : e));

  const matches = useMemo(() => {
    const q = productQuery.trim().toLowerCase();
    if (!q) return [];
    return products.filter((p) => p.nameAr.toLowerCase().includes(q) || (p.nameEn || '').toLowerCase().includes(q) || (p.barcode || '').includes(q)).slice(0, 8);
  }, [productQuery, products]);

  const save = (status?: QuotationStatus) => {
    if (!editing || !totals) return;
    if (!editing.customerName.trim()) { notify('اكتب اسم العميل'); return; }
    if (editing.items.length === 0) { notify('أضف بنداً واحداً على الأقل'); return; }
    if (editing.items.some((i) => !i.name.trim() || i.qty <= 0 || i.price < 0)) { notify('راجع البنود: الاسم والكمية والسعر'); return; }
    const final: Quotation = { ...editing, ...totals, status: status ?? editing.status };
    setQuotations((prev) => (isNew ? [final, ...prev] : prev.map((x) => (x.id === final.id ? final : x))));
    setEditing(null);
    notify(isNew ? `تم إنشاء ${final.number}` : `تم حفظ ${final.number}`);
  };

  /* ---------------- إجراءات القائمة ---------------- */
  const setStatus = (id: string, status: QuotationStatus) =>
    setQuotations((prev) => prev.map((x) => (x.id === id ? { ...x, status } : x)));

  const duplicate = (q: Quotation) => {
    setQuotations((prev) => [
      { ...q, id: `qt-${Date.now()}`, number: nextQuotationNumber(prev), date: localTimestamp(), validUntil: addDaysYmd(15), status: 'draft', invoiceId: undefined, invoiceNumber: undefined, items: q.items.map((i, n) => ({ ...i, id: `ql-${Date.now()}-${n}` })) },
      ...prev,
    ]);
    notify('تم نسخ العرض كمسودة جديدة');
  };

  const remove = (q: Quotation) => {
    if (window.confirm(`حذف عرض السعر ${q.number}؟`)) setQuotations((prev) => prev.filter((x) => x.id !== q.id));
  };

  const doPrint = async (q: Quotation) => {
    const res = await printHtmlDocument(quotationHtml(q, company), {
      silent: printSettings.silent && !!printSettings.a4Printer,
      deviceName: printSettings.a4Printer || undefined,
      pageSize: 'A4',
    });
    notify(res.ok ? 'تم إرسال العرض للطباعة' : 'لم تتم الطباعة');
  };
  const doPdf = async (q: Quotation) => {
    if (await exportHtmlAsPdf(quotationHtml(q, company), `${q.number}.pdf`)) notify('تم تصدير العرض');
  };

  const startConvert = (q: Quotation) => { setConverting(q); setConvMethod('cash'); setConvCredit(false); setConvPaid(''); };
  const convPaidNum = Number(convPaid) || 0;
  const convError = !converting ? '' :
    convCredit && !converting.customerId ? 'البيع الآجل يتطلب عميلاً مسجلاً — عدّل العرض واختر العميل من القائمة' :
    convCredit && (convPaidNum < 0 || convPaidNum >= converting.total - 0.004) ? 'المبلغ المدفوع يجب أن يكون أقل من الإجمالي' : '';

  const confirmConvert = () => {
    if (!converting || convError) return;
    onConvert(converting, { method: convMethod, credit: convCredit, paid: convCredit ? round2(convPaidNum) : converting.total });
    setConverting(null);
  };

  /* ---------------- الواجهة ---------------- */
  const FILTERS: { id: typeof statusFilter; label: string }[] = [
    { id: 'all', label: 'الكل' }, { id: 'draft', label: 'مسودة' }, { id: 'sent', label: 'مُرسل' },
    { id: 'accepted', label: 'مقبول' }, { id: 'rejected', label: 'مرفوض' }, { id: 'expired', label: 'منتهي' }, { id: 'invoiced', label: 'محوَّل' },
  ];

  return (
    <div className="p-6 bg-slate-50 dark:bg-slate-950 text-right text-slate-800 dark:text-slate-100 min-h-full space-y-5" dir="rtl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2"><FileText className="w-6 h-6 text-cyan-600 dark:text-cyan-400" /><span>عروض الأسعار</span></h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">أنشئ عرض سعر للعميل، اطبعه أو صدّره PDF، وحوّله إلى فاتورة عند الموافقة.</p>
        </div>
        <button onClick={openNew} className="bg-cyan-600 hover:bg-cyan-700 text-white px-5 py-2.5 rounded-xl font-black flex items-center gap-2"><Plus className="w-5 h-5" /> عرض سعر جديد</button>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث برقم العرض أو اسم العميل..." className={`${inp} pr-11 py-3`} />
          <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3" />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button key={f.id} onClick={() => setStatusFilter(f.id)} className={`px-3 py-2 rounded-xl text-xs font-bold border ${statusFilter === f.id ? 'bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border-cyan-500/40' : 'border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}>{f.label}</button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <div className="py-16 text-center text-slate-500 font-bold">{quotations.length === 0 ? 'لا توجد عروض أسعار بعد. اضغط «عرض سعر جديد» للبدء.' : 'لا توجد عروض مطابقة.'}</div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {list.map((q) => {
            const expired = isExpired(q);
            return (
              <div key={q.id} className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-mono font-black text-cyan-700 dark:text-cyan-300">{q.number}</div>
                    <div className="font-black text-slate-900 dark:text-white mt-0.5">{q.customerName}</div>
                    <div className="text-[11px] text-slate-500 font-bold mt-1">{q.date.slice(0, 10)} — صالح حتى <span className={expired ? 'text-rose-600 dark:text-rose-400' : ''}>{q.validUntil}</span>{expired && ' (منتهي)'}</div>
                  </div>
                  <div className="text-left shrink-0">
                    <div className="font-mono font-black text-xl text-slate-900 dark:text-white">{q.total.toFixed(2)}</div>
                    <span className={`inline-block mt-1 text-[11px] font-black px-2.5 py-0.5 rounded-full border ${STATUS_STYLE[q.status]}`}>{STATUS_LABEL[q.status]}{q.invoiceNumber ? ` ${q.invoiceNumber}` : ''}</span>
                  </div>
                </div>
                <div className="text-xs text-slate-500 font-semibold truncate">{q.items.map((i) => `${i.qty}× ${i.name}`).join('، ')}</div>
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-200 dark:border-slate-800">
                  {q.status !== 'invoiced' && (
                    <select value={q.status} onChange={(e) => setStatus(q.id, e.target.value as QuotationStatus)} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-600 dark:text-slate-300">
                      {(['draft', 'sent', 'accepted', 'rejected'] as QuotationStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
                    </select>
                  )}
                  <button onClick={() => doPrint(q)} title="طباعة" className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700"><Printer className="w-4 h-4" /></button>
                  <button onClick={() => doPdf(q)} title="PDF" className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700"><FileDown className="w-4 h-4" /></button>
                  <button onClick={() => (q.status === 'invoiced' ? setEditing({ ...q }) : openEdit(q))} title={q.status === 'invoiced' ? 'عرض' : 'تعديل'} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700">{q.status === 'invoiced' ? <Eye className="w-4 h-4" /> : <Pencil className="w-4 h-4" />}</button>
                  <button onClick={() => duplicate(q)} title="نسخ" className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700"><Copy className="w-4 h-4" /></button>
                  {q.status !== 'invoiced' && (
                    <button onClick={() => startConvert(q)} className="px-3 py-2 rounded-lg bg-violet-600 hover:bg-violet-700 text-white text-xs font-black flex items-center gap-1.5"><ArrowLeftRight className="w-4 h-4" /> تحويل إلى فاتورة</button>
                  )}
                  <button onClick={() => remove(q)} title="حذف" className="p-2 rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20 mr-auto"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ---------- نافذة التحرير ---------- */}
      {editing && totals && (
        <div className="fixed inset-0 z-[9997] bg-black/70 flex items-center justify-center p-3">
          <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-full max-w-4xl max-h-[94vh] rounded-2xl shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-black text-lg text-cyan-700 dark:text-cyan-300">{isNew ? 'عرض سعر جديد' : `${editing.status === 'invoiced' ? 'عرض' : 'تعديل'} ${editing.number}`}</h3>
              <button onClick={() => setEditing(null)}><X className="w-5 h-5 text-slate-500 dark:text-slate-400" /></button>
            </div>
            <fieldset disabled={editing.status === 'invoiced'} className="p-4 overflow-y-auto space-y-4 min-w-0 border-0">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="md:col-span-2">
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">العميل *</label>
                  <select
                    value={editing.customerId || ''}
                    onChange={(e) => {
                      const c = customers.find((x) => x.id === e.target.value);
                      patch(c ? { customerId: c.id, customerName: c.name, customerPhone: c.phone } : { customerId: undefined });
                    }}
                    className={inp}
                  >
                    <option value="">— عميل غير مسجل (اكتب الاسم) —</option>
                    {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  <input value={editing.customerName} onChange={(e) => patch({ customerName: e.target.value, customerId: undefined })} placeholder="اسم العميل" className={`${inp} mt-2`} />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">الجوال</label>
                  <input value={editing.customerPhone || ''} onChange={(e) => patch({ customerPhone: e.target.value })} className={`${inp} font-mono`} dir="ltr" />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">صالح حتى</label>
                  <input type="date" value={editing.validUntil} onChange={(e) => patch({ validUntil: e.target.value })} className={`${inp} font-mono`} />
                </div>
              </div>

              <div className="relative">
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400">إضافة صنف</label>
                <div className="flex gap-2">
                  <input value={productQuery} onChange={(e) => setProductQuery(e.target.value)} placeholder="ابحث بالاسم أو الباركود..." className={inp} />
                  <button onClick={addFreeLine} className="shrink-0 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-sm font-bold">+ بند حر</button>
                </div>
                {matches.length > 0 && (
                  <div className="absolute z-10 mt-1 w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl overflow-hidden shadow-xl">
                    {matches.map((p) => (
                      <button key={p.id} onClick={() => addProduct(p)} className="w-full flex justify-between px-3 py-2 text-sm font-bold hover:bg-slate-100 dark:hover:bg-slate-800 text-right">
                        <span>{p.nameAr}</span><span className="font-mono text-cyan-700 dark:text-cyan-300">{p.price.toFixed(2)}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 text-xs"><tr><th className="p-2 text-right">البيان</th><th className="p-2 w-24">الكمية</th><th className="p-2 w-32">السعر (قبل الضريبة)</th><th className="p-2 w-28">الإجمالي</th><th className="w-10" /></tr></thead>
                  <tbody>
                    {editing.items.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-slate-500 font-bold">لم تُضف أي بنود بعد</td></tr>}
                    {editing.items.map((it) => (
                      <tr key={it.id} className="border-t border-slate-200 dark:border-slate-800">
                        <td className="p-1.5"><input value={it.name} onChange={(e) => patchItem(it.id, { name: e.target.value })} className={inp} /></td>
                        <td className="p-1.5"><input type="number" min="0" step="any" value={it.qty} onChange={(e) => patchItem(it.id, { qty: Number(e.target.value) })} className={`${inp} font-mono text-center`} /></td>
                        <td className="p-1.5"><input type="number" min="0" step="0.01" value={it.price} onChange={(e) => patchItem(it.id, { price: Number(e.target.value) })} className={`${inp} font-mono text-center`} /></td>
                        <td className="p-1.5 text-center font-mono font-bold">{(it.qty * it.price).toFixed(2)}</td>
                        <td className="p-1.5"><button onClick={() => setEditing((e) => (e ? { ...e, items: e.items.filter((x) => x.id !== it.id) } : e))} className="text-rose-600 dark:text-rose-400"><X className="w-4 h-4" /></button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">ملاحظات</label>
                  <textarea value={editing.notes || ''} onChange={(e) => patch({ notes: e.target.value })} rows={2} className={inp} />
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">الشروط والأحكام</label>
                  <textarea value={editing.terms || ''} onChange={(e) => patch({ terms: e.target.value })} rows={3} className={inp} />
                </div>
                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-2 text-sm font-bold">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 dark:text-slate-400 text-xs">الخصم</span>
                    <input type="number" min="0" step="0.01" value={editing.discountValue || ''} onChange={(e) => patch({ discountValue: Number(e.target.value) })} className={`${inp} font-mono w-28`} />
                    <select value={editing.discountType} onChange={(e) => patch({ discountType: e.target.value as 'fixed' | 'percent' })} className={`${inp} w-24`}>
                      <option value="fixed">مبلغ</option><option value="percent">٪</option>
                    </select>
                  </div>
                  <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">قبل الخصم</span><span className="font-mono">{totals.rawSubtotal.toFixed(2)}</span></div>
                  {totals.discount > 0 && <div className="flex justify-between text-amber-600 dark:text-amber-400"><span>الخصم</span><span className="font-mono">- {totals.discount.toFixed(2)}</span></div>}
                  <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">بعد الخصم</span><span className="font-mono">{totals.subtotal.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">الضريبة ({editing.taxRate}%)</span><span className="font-mono">{totals.tax.toFixed(2)}</span></div>
                  <div className="flex justify-between text-lg font-black text-cyan-700 dark:text-cyan-300 border-t border-slate-200 dark:border-slate-800 pt-2"><span>الإجمالي</span><span className="font-mono">{totals.total.toFixed(2)}</span></div>
                </div>
              </div>
            </fieldset>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-2 justify-end">
              <button onClick={() => setEditing(null)} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-sm">{editing.status === 'invoiced' ? 'إغلاق' : 'إلغاء'}</button>
              {editing.status !== 'invoiced' && (
                <>
                  <button onClick={() => save()} className="px-5 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 font-black text-sm">حفظ</button>
                  <button onClick={() => save('sent')} className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-black text-sm">حفظ وتعليمه «مُرسل»</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ---------- نافذة التحويل لفاتورة ---------- */}
      {converting && (
        <div className="fixed inset-0 z-[9998] bg-black/70 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-slate-50 dark:bg-slate-950 p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <span className="font-black text-violet-700 dark:text-violet-300">تحويل {converting.number} إلى فاتورة</span>
              <button onClick={() => setConverting(null)}><X className="w-5 h-5 text-slate-500 dark:text-slate-400" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div className="flex justify-between bg-slate-50 dark:bg-slate-950 rounded-xl p-3 border border-slate-200 dark:border-slate-800"><span className="text-xs font-bold text-slate-500 dark:text-slate-400">{converting.customerName}</span><span className="font-mono font-black text-xl">{converting.total.toFixed(2)}</span></div>
              <div className="flex gap-2">
                <button onClick={() => setConvMethod('cash')} className={`flex-1 py-2 rounded-xl font-bold text-sm border ${convMethod === 'cash' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-700 dark:text-emerald-300' : 'border-slate-300 dark:border-slate-700'}`}>نقدي</button>
                <button onClick={() => setConvMethod('card')} className={`flex-1 py-2 rounded-xl font-bold text-sm border ${convMethod === 'card' ? 'bg-blue-500/20 border-blue-500 text-blue-700 dark:text-blue-300' : 'border-slate-300 dark:border-slate-700'}`}>شبكة</button>
              </div>
              <label className="flex items-center gap-2 text-sm font-bold cursor-pointer"><input type="checkbox" checked={convCredit} onChange={(e) => setConvCredit(e.target.checked)} /> بيع آجل / دفع جزئي (يُسجَّل المتبقي على العميل)</label>
              {convCredit && (
                <input type="number" min="0" step="0.01" value={convPaid} onChange={(e) => setConvPaid(e.target.value)} placeholder="المبلغ المدفوع الآن (0 = آجل بالكامل)" className={`${inp} font-mono`} dir="ltr" />
              )}
              {convError && <p className="text-xs font-bold text-amber-600 dark:text-amber-400">{convError}</p>}
              <p className="text-[11px] text-slate-500 font-bold">تُنشأ الفاتورة بتاريخ اليوم وتظهر في سجل المبيعات، ويُقفل العرض بعد التحويل.</p>
            </div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex gap-2">
              <button onClick={() => setConverting(null)} className="px-4 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-sm">إلغاء</button>
              <button disabled={!!convError} onClick={confirmConvert} className="flex-1 py-3 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-black disabled:opacity-40">إنشاء الفاتورة</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
