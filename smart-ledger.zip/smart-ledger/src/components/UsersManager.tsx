import React, { useState } from 'react';
import { UserCircle, Plus, Search, Shield, Key, Eye, EyeOff, Trash2, ShieldAlert, X } from 'lucide-react';

interface AppUser {
  id: string;
  username: string;
  role: 'admin' | 'cashier';
  status: 'active' | 'suspended';
  fullName: string;
}

interface UsersManagerProps {
  users: AppUser[];
  onAddUser: (user: AppUser) => void;
  onUpdateUser: (id: string, updated: Partial<AppUser>) => void;
  onDeleteUser: (id: string) => void;
}

export default function UsersManager({
  users,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
}: UsersManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Form states
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'admin' | 'cashier'>('cashier');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !fullName.trim()) return;

    const newUser: AppUser = {
      id: `u-${Date.now()}`,
      username: username.toLowerCase().trim(),
      fullName,
      role,
      status: 'active',
    };

    onAddUser(newUser);

    // Reset forms
    setUsername('');
    setFullName('');
    setPassword('');
    setRole('cashier');
    setShowAddModal(false);
  };

  const toggleStatus = (id: string, currentStatus: 'active' | 'suspended') => {
    onUpdateUser(id, { status: currentStatus === 'active' ? 'suspended' : 'active' });
  };

  const filteredUsers = users.filter(
    (u) =>
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 bg-slate-950 text-right text-slate-100 min-h-full space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
            <UserCircle className="w-6 h-6 text-purple-400" />
            <span>إدارة الكاشير والمستخدمين</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            إضافة كاشير جديد، تعديل الصلاحيات (مدير / كاشير تجزئة)، وتنشيط أو إيقاف الحسابات.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg transition"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة كاشير / مستخدم جديد</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <input
          type="text"
          placeholder="البحث باسم الكاشير أو اسم المستخدم..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-[#0D0D0D] border border-slate-800 rounded-xl pr-12 pl-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-purple-500"
        />
        <Search className="w-5 h-5 text-slate-500 absolute right-4 top-3" />
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.length === 0 ? (
          <div className="col-span-full p-8 text-center text-slate-500 bg-[#0D0D0D] border border-slate-800 rounded-2xl">
            لا يوجد مستخدمين مطابقين للبحث.
          </div>
        ) : (
          filteredUsers.map((u) => (
            <div
              key={u.id}
              className={`bg-[#0D0D0D] border ${
                u.status === 'suspended' ? 'border-rose-950/50' : 'border-slate-800/80'
              } p-6 rounded-2xl shadow-xl flex flex-col justify-between transition-all`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                    <UserCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-200 text-base">{u.fullName}</h3>
                    <p className="text-xs text-slate-500 font-mono">@{u.username}</p>
                  </div>
                </div>
                
                <span
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-md ${
                    u.role === 'admin'
                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                  }`}
                >
                  {u.role === 'admin' ? 'مدير النظام' : 'كاشير'}
                </span>
              </div>

              {/* Status & Options row */}
              <div className="mt-6 pt-4 border-t border-slate-900 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      u.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                    }`}
                  />
                  <span className="text-xs font-bold text-slate-400">
                    {u.status === 'active' ? 'نشط الآن' : 'موقوف مؤقتاً'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleStatus(u.id, u.status)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      u.status === 'active'
                        ? 'bg-rose-950/40 text-rose-400 hover:bg-rose-900/60'
                        : 'bg-emerald-950/40 text-emerald-400 hover:bg-emerald-900/60'
                    }`}
                  >
                    {u.status === 'active' ? 'إيقاف' : 'تنشيط'}
                  </button>
                  
                  {u.username !== 'admin' && (
                    <button
                      onClick={() => onDeleteUser(u.id)}
                      className="p-1.5 bg-slate-900 hover:bg-rose-950 hover:text-rose-400 text-slate-500 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D0D0D] border border-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col text-slate-100">
            <div className="bg-slate-900 p-5 border-b border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-lg flex items-center gap-2 text-purple-400">
                <Shield className="w-5 h-5" /> إضافة مستخدم كاشير جديد
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-rose-500 bg-slate-800 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 font-bold">
              <div className="space-y-1">
                <label className="text-sm text-slate-400">الاسم الكامل (الثنائي أو الثلاثي)</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="مثال: صالح عبدالله الدوسري"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm text-slate-400">اسم المستخدم (للدخول به)</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="مثال: saleh55"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:outline-none font-mono"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm text-slate-400">صلاحية النظام</label>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setRole('cashier')}
                    className={`py-2.5 rounded-xl border text-sm font-bold transition ${
                      role === 'cashier'
                        ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400'
                        : 'border-slate-800 text-slate-400'
                    }`}
                  >
                    صلاحية كاشير
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('admin')}
                    className={`py-2.5 rounded-xl border text-sm font-bold transition ${
                      role === 'admin'
                        ? 'border-rose-500 bg-rose-500/10 text-rose-400'
                        : 'border-slate-800 text-slate-400'
                    }`}
                  >
                    صلاحية مدير نظام
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-sm text-slate-400">كلمة المرور المؤقتة</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-4 pl-12 py-3 text-white focus:border-purple-500 focus:outline-none font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-4 top-3 text-slate-500 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-lg transition"
              >
                تسجيل وحفظ الكاشير
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
