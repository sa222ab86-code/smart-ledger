import React from 'react';
import { QrCode, Barcode } from 'lucide-react';
import SaudiRiyalSymbol from './SaudiRiyalSymbol';

// ==========================================
// 1. قالب الفاتورة الضريبية الشاملة (A4)
// ==========================================
export const A4InvoiceTemplate = () => {
  return (
    <div className="bg-white text-black p-8 w-full max-w-[800px] mx-auto border border-gray-300 shadow-lg font-sans text-sm" dir="rtl">
      
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-black pb-4 mb-4">
        {/* Arabic Header */}
        <div className="text-right font-bold space-y-1">
          <h2 className="text-lg">مؤسسة معادن التنمية للتجارة</h2>
          <p>للخردة والسكراب</p>
          <p>جوال : 0559755592</p>
          <p>الرقم الضريبي : 310331593200003</p>
          <p>السجل التجاري : 4030314478</p>
        </div>
        
        {/* English Header */}
        <div className="text-left font-bold space-y-1" dir="ltr">
          <h2 className="text-lg">Development Metals Trading Corporation</h2>
          <p>FOR SCRAP AND SCRAP</p>
          <p>MO : 0559755592</p>
          <p>VAT No : 310331593200003</p>
          <p>C.R : 4030314478</p>
        </div>
      </div>

      {/* Invoice Title */}
      <div className="text-center font-bold text-lg border border-black py-1 mb-4 w-1/3 mx-auto rounded-full bg-gray-50">
        فاتورة ضريبية
      </div>

      {/* Info Boxes */}
      <div className="grid grid-cols-2 gap-4 mb-4 border border-black rounded-lg p-3">
        {/* Customer Info */}
        <div className="space-y-2 border-l border-black pl-4">
          <div className="flex justify-between"><span className="font-bold">اسم العميل :</span> <span>شركة الوفاء</span></div>
          <div className="flex justify-between"><span className="font-bold">جوال العميل :</span> <span>0125215625</span></div>
          <div className="flex justify-between"><span className="font-bold">الرقم الضريبي :</span> <span>334549845644</span></div>
          <div className="flex justify-between"><span className="font-bold">العنوان :</span> <span>شارع الوفاء للعمارة الفني رقم 6</span></div>
        </div>
        
        {/* Invoice Info */}
        <div className="space-y-2 pr-4 flex flex-col justify-between">
          <div className="flex justify-between items-center">
             <span className="font-bold">رقم الفاتورة :</span>
             <div className="flex flex-col items-center">
               <Barcode className="w-24 h-8" />
               <span className="text-xs">2,100,009</span>
             </div>
          </div>
          <div className="flex justify-between"><span className="font-bold">تاريخ الفاتورة :</span> <span>02/04/2023 12:17:20 AM</span></div>
          <div className="flex justify-between"><span className="font-bold">نوع الفاتورة :</span> <span>مبيعات</span></div>
        </div>
      </div>

      {/* Table */}
      <table className="w-full border-collapse border border-black mb-4 text-center">
        <thead className="bg-gray-100">
          <tr>
            <th className="border border-black p-2 w-10">مسلسل</th>
            <th className="border border-black p-2 w-20">كود الصنف</th>
            <th className="border border-black p-2">الصنف</th>
            <th className="border border-black p-2 w-24 inline-flex items-center justify-center gap-1">
              <span>السعر</span>
              <SaudiRiyalSymbol className="w-3 h-3 text-black" />
            </th>
            <th className="border border-black p-2 w-16">الكمية بالطن</th>
            <th className="border border-black p-2 w-24">قيمة الضريبة</th>
            <th className="border border-black p-2 w-28">إجمالي مع الضريبة</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-black p-2">1</td>
            <td className="border border-black p-2">290000002</td>
            <td className="border border-black p-2">صنف تجريبي للخردة</td>
            <td className="border border-black p-2">13,043.48</td>
            <td className="border border-black p-2">2.00</td>
            <td className="border border-black p-2">3,913.04</td>
            <td className="border border-black p-2 font-bold">30,000.00</td>
          </tr>
          <tr>
            <td className="border border-black p-2">2</td>
            <td className="border border-black p-2"></td>
            <td className="border border-black p-2"></td>
            <td className="border border-black p-2"></td>
            <td className="border border-black p-2"></td>
            <td className="border border-black p-2">0.00</td>
            <td className="border border-black p-2"></td>
          </tr>
        </tbody>
      </table>

      {/* Total Amount in Words Header */}
      <div className="border-t-2 border-black flex items-center justify-center font-bold pb-2 pt-1">
        إجمالي الكمية بالطن : <span className="ml-4">2.00</span>
      </div>

      {/* Summary and QR Code */}
      <div className="flex gap-4 border border-black rounded-lg p-4 mb-6">
        {/* Summary Info */}
        <div className="flex-1 space-y-2 border-l border-black pl-4">
          <div className="flex justify-between"><span className="font-bold">الإجمالي قبل الضريبة :</span> <span className="inline-flex items-center gap-1 font-mono">26,086.96 <SaudiRiyalSymbol className="w-3 h-3" /></span></div>
          <div className="flex justify-between"><span className="font-bold">ضريبة القيمة المضافة :</span> <span className="inline-flex items-center gap-1 font-mono">3,913.04 <SaudiRiyalSymbol className="w-3 h-3" /></span></div>
          <div className="flex justify-between"><span className="font-bold">الإجمالي شامل الضريبة :</span> <span className="inline-flex items-center gap-1 font-mono">30,000.00 <SaudiRiyalSymbol className="w-3 h-3" /></span></div>
          <div className="flex justify-between"><span className="font-bold">الخصم :</span> <span className="inline-flex items-center gap-1 font-mono">0.00 <SaudiRiyalSymbol className="w-3 h-3" /></span></div>
          <div className="flex justify-between font-bold text-lg border-t border-dashed border-gray-400 pt-2"><span className="font-bold">الإجمالي بعد الخصم :</span> <span className="inline-flex items-center gap-1 font-mono">30,000.00 <SaudiRiyalSymbol className="w-4 h-4" /></span></div>
          <div className="flex justify-between"><span className="font-bold">المدفوع :</span> <span className="inline-flex items-center gap-1 font-mono">10,000.00 <SaudiRiyalSymbol className="w-3 h-3" /></span></div>
          <div className="flex justify-between"><span className="font-bold">المتبقي :</span> <span className="inline-flex items-center gap-1 font-mono">20,000.00 <SaudiRiyalSymbol className="w-3 h-3" /></span></div>
          <div className="text-center font-bold pt-2 mt-2 border-t border-black flex items-center justify-center gap-1.5">
            <span>فقط ثلاثون ألف</span>
            <SaudiRiyalSymbol className="w-3.5 h-3.5" />
            <span>فقط لا غير</span>
          </div>
        </div>

        {/* QR Code */}
        <div className="w-32 flex items-center justify-center">
          <QrCode className="w-24 h-24 text-black" />
        </div>
      </div>

      {/* Footer Details */}
      <div className="text-center text-xs text-gray-500 space-y-1">
        <p>صف مخصص للدعاية والترحيب بالعملا</p>
        <p>صف مخصص للدعاية والترحيب بالعملا</p>
        <p>صف مخصص للدعاية والترحيب بالعملا</p>
      </div>
    </div>
  );
};

// ==========================================
// 2. قالب الفاتورة الحرارية المبسطة (80mm)
// ==========================================
export const ThermalReceiptTemplate = () => {
  return (
    <div className="bg-white text-black p-4 mx-auto border border-gray-300 shadow-md font-sans text-xs w-[300px]" dir="rtl">
      
      {/* Header */}
      <div className="text-center space-y-1 border-b-2 border-dashed border-gray-400 pb-3 mb-3">
        <h3 className="font-bold text-sm">فاتورة ضريبية مبسطة</h3>
        <h2 className="font-black text-lg">ogy soft</h2>
        <p className="font-bold">العنوان Address</p>
        <p>الرقم الضريبي 52656526562565</p>
      </div>

      {/* Invoice Meta */}
      <div className="space-y-1 mb-3">
        <div className="text-center font-bold font-mono">239,100,001</div>
        <div className="flex justify-between"><span>مستخدم :</span> <span>Owner</span></div>
        <div className="flex justify-between"><span>تاريخ :</span> <span>04/05/2022</span></div>
        <div className="flex justify-between"><span>الوقت :</span> <span>10:15:30 PM</span></div>
        <div className="flex justify-between"><span>العميل :</span> <span>Customer Default</span></div>
        <div className="flex justify-between"><span>بوليصة :</span> <span>77777</span></div>
      </div>

      {/* Barcode Placeholder */}
      <div className="flex justify-center mb-3">
        <Barcode className="w-full h-10 text-gray-800" />
      </div>

      {/* Table */}
      <table className="w-full border-collapse border border-black text-center mb-2">
        <thead className="bg-gray-100 border-b border-black">
          <tr>
            <th className="p-1 border border-black w-2/5">الصنف<br/>Category</th>
            <th className="p-1 border border-black">سعر<br/>price</th>
            <th className="p-1 border border-black">عدد<br/>quantity</th>
            <th className="p-1 border border-black">اجمالي<br/>Total</th>
          </tr>
        </thead>
        <tbody className="font-bold">
          <tr>
            <td className="p-1 border border-black">صنف تجريبي 2</td>
            <td className="p-1 border border-black font-mono">150.00</td>
            <td className="p-1 border border-black font-mono">1.00</td>
            <td className="p-1 border border-black font-mono">150.00</td>
          </tr>
          <tr>
            <td className="p-1 border border-black">صنف تجريبي 1</td>
            <td className="p-1 border border-black font-mono">120.00</td>
            <td className="p-1 border border-black font-mono">1.00</td>
            <td className="p-1 border border-black font-mono">120.00</td>
          </tr>
        </tbody>
      </table>

      {/* Totals */}
      <div className="border border-black p-2 mb-3 space-y-1 font-bold">
        <div className="flex justify-between border-b border-gray-400 pb-1 mb-1">
           <span>عدد الوحدات في الفاتورة</span>
           <span>2.00</span>
        </div>
        <div className="grid grid-cols-3 text-center text-[10px]">
           <div>القيمة<br/>Value</div>
           <div>يشمل ضريبة القيمة المضافة</div>
           <div>الاجمالي<br/>Total</div>
        </div>
        <div className="grid grid-cols-3 text-center font-mono mt-1">
           <div>0.00</div>
           <div>35.22</div>
           <div>270.00</div>
        </div>
        <div className="grid grid-cols-3 text-center font-mono border-t border-black pt-1 mt-1">
           <div>0.00</div>
           <div></div>
           <div className="text-lg flex items-center justify-center gap-1">
             <span>270.00</span>
             <SaudiRiyalSymbol className="w-3.5 h-3.5 text-black" />
           </div>
        </div>
      </div>

      {/* QR Code and Footer */}
      <div className="flex flex-col items-center justify-center space-y-2 pt-2 border-t-2 border-dashed border-gray-400">
        <div className="font-bold text-center space-y-1">
          <p>صف مخصص للدعاية والترحيب بالعملا</p>
          <p>صف مخصص للدعاية والترحيب بالعملا</p>
          <p>صف مخصص للدعاية والترحيب بالعملا</p>
        </div>
        <div className="bg-white p-1 border-2 border-black rounded-lg">
           <QrCode className="w-24 h-24" />
        </div>
        <p className="text-[10px] text-gray-600 mt-2 text-center">
          رقم 8079 حي الشامخية رقم الوحدة 1 جدة 22529 5009
        </p>
      </div>
    </div>
  );
};

// ==========================================
// 3. مكون استعراض القالبين معاً (للاختبار)
// ==========================================
export default function InvoicesDemo() {
  return (
    <div className="min-h-screen bg-gray-200 p-8 flex flex-col md:flex-row gap-8 items-start justify-center">
      {/* عرض فاتورة A4 */}
      <div className="w-full md:w-2/3">
        <h2 className="text-center font-bold mb-4 text-xl text-gray-700">قالب فاتورة A4</h2>
        <A4InvoiceTemplate />
      </div>

      {/* عرض الفاتورة الحرارية */}
      <div className="w-full md:w-1/3 flex flex-col items-center">
        <h2 className="text-center font-bold mb-4 text-xl text-gray-700">قالب الفاتورة الحرارية (80mm)</h2>
        <ThermalReceiptTemplate />
      </div>
    </div>
  );
}