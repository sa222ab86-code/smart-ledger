import { useMemo, useState, type ReactNode } from 'react';
import { BarChart3, Calendar, FileText, UserCircle, Banknote, Printer, FileDown, FileSpreadsheet } from 'lucide-react';
import type { Invoice } from '../types';
import { buildReport, reportToCsv, reportToHtml, type ReportKind } from '../utils/reports';
import { saveTextFile, todayStamp } from '../utils/files';
import { exportHtmlAsPdf, printHtmlDocument, type PrintSettings } from '../utils/printing';

interface Props {
  invoices: Invoice[];
  company: { name: string; vat: string; address?: string };
  printSettings: PrintSettings;
  notify: (msg: string) => void;
}

const TABS: { id: ReportKind; label: string; icon: ReactNode }[] = [
  { id: 'daily', label: 'التقرير اليومي', icon: <Calendar className="w-5 h-5" /> },
  { id: 'monthly', label: 'التقرير الشهري', icon: <FileText className="w-5 h-5" /> },
  { id: 'users', label: 'أداء المستخدمين', icon: <UserCircle className="w-5 h-5" /> },
  { id: 'tax', label: 'الضريبة', icon: <Banknote className="w-5 h-5" /> },
];

const pad = (n: number) => String(n).padStart(2, '0');
const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export default function ReportsView({ invoices, company, printSettings, notify }: Props) {
  const [tab, setTab] = useState<ReportKind>('daily');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [busy, setBusy] = useState(false);

  const report = useMemo(() => buildReport(tab, invoices, from, to), [tab, invoices, from, to]);

  const setToday = () => { const t = ymd(new Date()); setFrom(t); setTo(t); };
  const setThisMonth = () => {
    const n = new Date();
    setFrom(ymd(new Date(n.getFullYear(), n.getMonth(), 1)));
    setTo(ymd(new Date(n.getFullYear(), n.getMonth() + 1, 0)));
  };
  const setAll = () => { setFrom(''); setTo(''); };

  const fileBase = `${report.kind}-report-${todayStamp()}`;
  const landscape = report.columns.length > 7;

  const run = async (fn: () => Promise<void>) => {
    if (busy) return;
    setBusy(true);
    try { await fn(); } catch (e) { console.error(e); notify('تعذر تنفيذ العملية'); } finally { setBusy(false); }
  };

  const onPrint = () => run(async () => {
    const html = reportToHtml(report, company);
    const res = await printHtmlDocument(html, {
      silent: printSettings.silent && !!printSettings.a4Printer,
      deviceName: printSettings.a4Printer || undefined,
      pageSize: 'A4',
      landscape,
    });
    notify(res.ok ? 'تم إرسال التقرير للطباعة' : 'لم تتم الطباعة');
  });

  const onPdf = () => run(async () => {
    const ok = await exportHtmlAsPdf(reportToHtml(report, company), `${fileBase}.pdf`, landscape);
    if (ok) notify('تم تصدير التقرير');
  });

  const onCsv = () => run(async () => {
    const ok = await saveTextFile(`${fileBase}.csv`, reportToCsv(report, company.name), 'csv');
    if (ok) notify('تم تصدير الملف (يفتح في Excel)');
  });

  const input = 'border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 rounded-xl px-3 py-2 font-mono text-sm outline-none';
  const chip = 'px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200';

  return (
    <div className="p-6 h-full flex flex-col animate-in fade-in zoom-in-95 max-w-7xl mx-auto dark:text-white">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-xl"><BarChart3 className="w-8 h-8" /></div>
          <div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white">التقارير والإحصائيات</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold mt-1">{report.period} — {report.rows.length} سطر</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={setToday} className={chip}>اليوم</button>
          <button onClick={setThisMonth} className={chip}>هذا الشهر</button>
          <button onClick={setAll} className={chip}>الكل</button>
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={input} />
          <span className="text-slate-400">-</span>
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className={input} />
        </div>
      </div>

      <div className="flex gap-3 mb-4">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold transition-all border-2 ${
              tab === t.id
                ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400'
                : 'border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      <div className="flex-1 min-h-0 bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 p-5 flex flex-col">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-4 mb-4">
          <h3 className="text-xl font-black text-slate-800 dark:text-white">{report.title}</h3>
          <div className="flex gap-2">
            <button disabled={busy} onClick={onPrint} className="px-4 py-2 rounded-xl bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white text-sm font-bold flex items-center gap-2 disabled:opacity-50"><Printer className="w-4 h-4" /> طباعة</button>
            <button disabled={busy} onClick={onPdf} className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold flex items-center gap-2 disabled:opacity-50"><FileDown className="w-4 h-4" /> PDF</button>
            <button disabled={busy} onClick={onCsv} className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center gap-2 disabled:opacity-50"><FileSpreadsheet className="w-4 h-4" /> Excel / CSV</button>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          {report.summary.map((s) => (
            <div key={s.label} className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-700">
              <p className="text-slate-500 dark:text-slate-400 font-bold text-xs mb-1">{s.label}</p>
              <p className="text-2xl font-black font-mono text-slate-800 dark:text-white" dir="ltr">{s.value}</p>
            </div>
          ))}
        </div>

        <div className="flex-1 min-h-0 overflow-auto rounded-xl border border-slate-100 dark:border-slate-700">
          {report.rows.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-400 font-bold p-10">لا توجد فواتير في هذه الفترة.</div>
          ) : (
            <table className="w-full text-sm text-center">
              <thead className="bg-slate-100 dark:bg-slate-900 sticky top-0">
                <tr>{report.columns.map((c) => <th key={c} className="px-3 py-2.5 font-black text-slate-600 dark:text-slate-300 whitespace-nowrap">{c}</th>)}</tr>
              </thead>
              <tbody>
                {report.rows.map((row, i) => (
                  <tr key={i} className="border-t border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-900/40">
                    {row.map((c, j) => <td key={j} className="px-3 py-2 font-mono">{String(c ?? '')}</td>)}
                  </tr>
                ))}
                <tr className="border-t-2 border-indigo-400 bg-indigo-50 dark:bg-indigo-900/20 font-black">
                  {report.totals.map((c, j) => <td key={j} className="px-3 py-2.5 font-mono">{String(c ?? '')}</td>)}
                </tr>
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
