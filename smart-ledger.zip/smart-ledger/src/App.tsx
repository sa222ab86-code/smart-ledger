import React, { useState, useEffect, useRef } from 'react';
import { 
  ShoppingBag, User, Menu, Trash2, CreditCard, Printer, Banknote, 
  Plus, Minus, X, Building2, Package, Store, Utensils,
  Palette, BarChart3, History, LockKeyhole, MonitorCheck, Sun, Moon, 
  Search, PlusCircle, Edit, Layers, FolderTree, Server, CheckCircle2,
  Calendar, FileText, UserCircle, ChefHat, FileDigit, ArrowRightLeft,
  Truck, FileBox, UserCog, Receipt, Percent, Tag, BadgePercent,
  PauseCircle, Clock, RotateCcw, AlertCircle, AlertTriangle, Eye, Zap, Coins, Sparkles,
  ChevronDown, ChevronUp, Boxes, Ruler, Maximize2, Sliders
} from 'lucide-react';
import { Product, Customer, Invoice, Supplier, PurchaseInvoice, CompanySettings, ParkedOrder, CartItem, ProductGroup, BundleItem, ProductUnit } from './types';
import { initialProducts, initialCustomers, initialInvoices, defaultCompanySettings, initialProductGroups } from './data';
import { usePersistentState } from './storage/persistence';
import TopBar from './components/TopBar';
import Sidebar from './components/Sidebar';

// Import newly activated manager components
import InvoicesList from './components/InvoicesList';
import ProductsManager from './components/ProductsManager';
import InventoryManager from './components/InventoryManager';
import SettingsView from './components/SettingsView';
import CustomersManager from './components/CustomersManager';
import SuppliersManager from './components/SuppliersManager';
import PurchasesManager from './components/PurchasesManager';
import UsersManager from './components/UsersManager';
import InvoiceView from './components/InvoiceView';
import ZReportManager from './components/ZReportManager';
import SaudiRiyalSymbol from './components/SaudiRiyalSymbol';
import DiscountModal from './components/DiscountModal';
import { generateZatcaTlvBase64, generateQrDataUrl } from './utils/zatca';

type ExtendedViewType = 
  | 'pos' 
  | 'dailyReports' 
  | 'salesLog' 
  | 'dailyClosing' 
  | 'invoices' 
  | 'products' 
  | 'productGroups'
  | 'inventory'
  | 'customers' 
  | 'suppliers' 
  | 'purchases' 
  | 'users' 
  | 'printers' 
  | 'settings' 
  | 'appSettings';

type BusinessType = 'restaurant' | 'retail';

interface Variant { id: string; name: string; price: number; }
interface ExtendedProduct extends Product { variants?: Variant[]; units?: ProductUnit[]; }
interface AppPrinter { id: string; name: string; osPrinterName: string; type: 'cashier' | 'kitchen' | 'section'; template: 'thermal80' | 'A4' | 'kitchenTicket'; status: 'online' | 'offline'; }
interface AppCategory { id: string; name: string; printerId: string; }
interface AppUser { id: string; username: string; role: 'admin' | 'cashier'; status: 'active' | 'suspended'; fullName: string; }

export default function App() {
  const [productGroups, setProductGroups] = usePersistentState<ProductGroup[]>('productGroups', initialProductGroups);

  const [products, setProducts] = usePersistentState<ExtendedProduct[]>('products', [
    ...initialProducts,
    { id: 'v1', nameAr: 'وجبة برجر', nameEn: 'Burger', price: 25, cost: 15, categoryAr: 'وجبات سريعة', categoryEn: 'Fast Food', groupId: 'grp-meals', stock: 100, minStock: 20, barcode: '123456', variants: [ { id: 'v1-1', name: 'سنجل', price: 25 }, { id: 'v1-2', name: 'دبل', price: 35 } ] },
    { id: 'u1', nameAr: 'بيبسي دايت', nameEn: 'Diet Pepsi', price: 2.5, cost: 1.5, categoryAr: 'مشروبات', categoryEn: 'Drinks', groupId: 'grp-drinks', stock: 240, minStock: 30, barcode: '62810001', units: [ { id: 'u1-box', name: 'كرتون 24', factor: 24, price: 50, barcode: '62810001-box' }, { id: 'u1-pack', name: 'شدة 6', factor: 6, price: 14, barcode: '62810001-pack' } ] },
    { id: 'p-low-1', nameAr: 'شاي كرك بالزعفران', nameEn: 'Saffron Karak Tea', price: 8.0, cost: 3.0, categoryAr: 'مشروبات', categoryEn: 'Drinks', groupId: 'grp-drinks', stock: 4, minStock: 15, barcode: '62820010' },
    { id: 'p-low-2', nameAr: 'برجر دجاج كرسبي سبايسي', nameEn: 'Spicy Crispy Chicken Burger', price: 21.0, cost: 10.0, categoryAr: 'برجر', categoryEn: 'Burger', groupId: 'grp-burgers', stock: 3, minStock: 10, barcode: '62840030' },
    { id: 'p-out-1', nameAr: 'كوكيز شوكولاتة بلجيكية', nameEn: 'Chocolate Cookies', price: 12.0, cost: 5.5, categoryAr: 'حلويات', categoryEn: 'Desserts', groupId: 'grp-desserts', stock: 0, minStock: 12, barcode: '62830020' }
  ]);
  
  const [printersList, setPrintersList] = usePersistentState<AppPrinter[]>('printersList', [
    { id: 'p1', name: 'طابعة الكاشير (حراري)', osPrinterName: 'XP-80C', type: 'cashier', template: 'thermal80', status: 'online' },
    { id: 'p2', name: 'طابعة إدارة (A4)', osPrinterName: 'HP LaserJet Pro', type: 'cashier', template: 'A4', status: 'online' },
    { id: 'p3', name: 'طابعة المطبخ', osPrinterName: 'Kitchen-Printer-Net', type: 'kitchen', template: 'kitchenTicket', status: 'online' },
  ]);

  const [categoriesList, setCategoriesList] = usePersistentState<AppCategory[]>('categoriesList', [
    { id: 'cat1', name: 'وجبات سريعة', printerId: 'p3' },
    { id: 'cat2', name: 'مشروبات', printerId: '' },
  ]);

  const [invoices, setInvoices] = usePersistentState<Invoice[]>('invoices', initialInvoices);

  // Durable store collections
  const [customers, setCustomers] = usePersistentState<Customer[]>('customers', initialCustomers);
  const [suppliers, setSuppliers] = usePersistentState<Supplier[]>('suppliers', [
    { id: 's1', name: 'شركة المراعي للمواد الغذائية', phone: '0512345678', email: 'sales@almarai.com', address: 'الرياض - المنطقة الصناعية' },
    { id: 's2', name: 'الشركة الوطنية للدواجن', phone: '0567890123', email: 'info@watania.sa', address: 'القصيم - بريدة' }
  ]);
  const [purchases, setPurchases] = usePersistentState<PurchaseInvoice[]>('purchases', [
    {
      id: 'PUR-1001',
      supplierId: 's1',
      supplierName: 'شركة المراعي للمواد الغذائية',
      date: '2026-07-01',
      items: [
        { productId: 'u1', productName: 'بيبسي دايت', qty: 10, price: 1.5, total: 15.00 }
      ],
      total: 15.00
    }
  ]);
  const [users, setUsers] = usePersistentState<AppUser[]>('users', [
    { id: 'u1', username: 'admin', fullName: 'المدير العام', role: 'admin', status: 'active' },
    { id: 'u2', username: 'cashier1', fullName: 'أحمد علي (كاشير التجزئة)', role: 'cashier', status: 'active' },
    { id: 'u3', username: 'cashier2', fullName: 'صالح محمد (كاشير المطعم)', role: 'cashier', status: 'active' }
  ]);
  const [companySettings, setCompanySettings] = usePersistentState<CompanySettings>('companySettings', defaultCompanySettings);

  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [currentView, setCurrentView] = useState<ExtendedViewType>('pos'); 
  const [isDarkMode, setIsDarkMode] = usePersistentState<boolean>('isDarkMode', false);
  const [isLayoutReversed, setIsLayoutReversed] = usePersistentState<boolean>('isLayoutReversed', false); 
  const [businessType, setBusinessType] = usePersistentState<BusinessType>('businessType', 'retail');
  const [selectedRetailPrinterId, setSelectedRetailPrinterId] = usePersistentState<string>('selectedRetailPrinterId', 'p1'); // Default printer routing for retail
  const [retailPrintTemplate, setRetailPrintTemplate] = usePersistentState<'thermal80' | 'A4' | 'pdf'>('retailPrintTemplate', 'thermal80');

  const [reportDateRange, setReportDateRange] = useState({ from: '', to: '' });
  const [activeReportTab, setActiveReportTab] = useState<'daily' | 'monthly' | 'users' | 'tax'>('daily');

  const [productTab, setProductTab] = useState<'items' | 'categories'>('items');
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<AppCategory | null>(null);
  
  const [isPrinterModalOpen, setIsPrinterModalOpen] = useState(false);
  const [editingPrinter, setEditingPrinter] = useState<AppPrinter | null>(null);

  const [isPosMenuOpen, setIsPosMenuOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [discountType, setDiscountType] = useState<'fixed' | 'percent'>('fixed');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [discountScope, setDiscountScope] = useState<'total' | 'subtotal'>('total');
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState<boolean>(false);
  
  // Parked Orders (الطلبات المعلقة) State
  const [parkedOrders, setParkedOrders] = usePersistentState<ParkedOrder[]>('parkedOrders', [
    {
      id: 'parked-demo-1',
      orderNumber: 1,
      label: 'طلب معلق #1 (طاولة 4)',
      customerName: 'طاولة 4 - خالد',
      items: [
        { id: 'v1', cartItemId: 'v1-1', name: 'وجبة برجر - سنجل', price: 25, qty: 2, tax: 7.5, total: 57.5 },
        { id: 'u1', cartItemId: 'u1-pack', name: 'بيبسي دايت - شدة 6', price: 14, qty: 1, tax: 2.1, total: 16.1 }
      ],
      discountType: 'percent',
      discountValue: 10,
      rawSubtotal: 64,
      discountAmount: 6.4,
      discountedSubtotal: 57.6,
      tax: 8.64,
      total: 66.24,
      createdAt: '11:45 ص',
      dueTime: '12:30 م',
      dueDate: new Date().toISOString().split('T')[0],
      note: 'طلب محلي - العميل ينتظر صديقه'
    }
  ]);
  const [isParkModalOpen, setIsParkModalOpen] = useState(false);
  const [isParkedOrdersModalOpen, setIsParkedOrdersModalOpen] = useState(false);
  const [parkOrderLabel, setParkOrderLabel] = useState('');
  const [parkOrderCustomer, setParkOrderCustomer] = useState('');
  const [parkOrderNote, setParkOrderNote] = useState('');
  const [parkOrderDueTime, setParkOrderDueTime] = useState('');
  const [parkOrderDueDate, setParkOrderDueDate] = useState('');
  const [orderToRestore, setOrderToRestore] = useState<ParkedOrder | null>(null);
  const [previewParkedOrder, setPreviewParkedOrder] = useState<ParkedOrder | null>(null);

  const [activeCategory, setActiveCategory] = useState<string>('الكل');
  const [posStockFilter, setPosStockFilter] = useState<'all' | 'low' | 'out'>('all');
  const [posProductSearch, setPosProductSearch] = useState<string>('');
  const [selectedProductForOptions, setSelectedProductForOptions] = useState<ExtendedProduct | null>(null);
  const [printNotification, setPrintNotification] = useState<string | null>(null);
  const [printInvoiceData, setPrintInvoiceData] = useState<Invoice | null>(null); // For real Windows print job
  const [printZReportData, setPrintZReportData] = useState<any | null>(null); // For Z-Report print job
  const [selectedInvoiceForModal, setSelectedInvoiceForModal] = useState<Invoice | null>(null); // For invoice viewing modal
  const [printInvoiceCurrency, setPrintInvoiceCurrency] = useState<string>('SAR');
  const [activePrintTemplate, setActivePrintTemplate] = useState<'thermal80' | 'A4'>('thermal80');
  
  // Quick Pay (الدفع السريع بنقرة واحدة وحساب الباقي)
  const [lastCashChange, setLastCashChange] = useState<{
    invoiceNumber: string;
    total: number;
    paidAmount: number;
    changeAmount: number;
    customerName: string;
    isQuickPay: boolean;
    timestamp: string;
  } | null>(null);
  const [isCustomQuickPayOpen, setIsCustomQuickPayOpen] = useState<boolean>(false);
  const [customQuickPayInput, setCustomQuickPayInput] = useState<string>('');
  
  // Cart UX & organization state
  const [lastAddedItemId, setLastAddedItemId] = useState<string | null>(null);
  const [isDiscountDrawerOpen, setIsDiscountDrawerOpen] = useState<boolean>(false);
  const [isSummaryDetailsOpen, setIsSummaryDetailsOpen] = useState<boolean>(false);
  const cartListRef = useRef<HTMLDivElement>(null);
  
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (businessType === 'retail' && currentView === 'pos' && barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  }, [businessType, currentView, cart]);

  const handleLogin = (e: React.FormEvent) => { e.preventDefault(); setIsLoggedIn(true); };
  const handleLogout = () => setIsLoggedIn(false);
  const handleFocusSelect = (e: React.FocusEvent<HTMLInputElement>) => { e.target.select(); };
  const triggerPrintNotification = (msg: string) => { setPrintNotification(msg); setTimeout(() => setPrintNotification(null), 3000); };

  const handleBarcodeScan = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const code = e.currentTarget.value.trim();
      if (!code) return;
      let foundProduct, foundOption;
      for (const p of products) {
        if (p.barcode === code) { foundProduct = p; break; }
        if (p.units) {
          const u = p.units.find(unit => unit.barcode === code);
          if (u) { foundProduct = p; foundOption = { id: u.id, name: u.name, price: u.price }; break; }
        }
      }
      if (foundProduct) addToCart(foundProduct, foundOption);
      else triggerPrintNotification('الصنف غير موجود!');
      e.currentTarget.value = '';
    }
  };

  const addToCart = (product: ExtendedProduct, option?: { id: string; name: string; price: number; unitType?: string; factor?: number }) => {
    if (lastCashChange) setLastCashChange(null);
    if (((product.variants && product.variants.length > 0) || (product.units && product.units.length > 0)) && !option) {
      setSelectedProductForOptions(product); return;
    }
    
    // تنبيه الكاشير في حال كان المخزون منخفضاً أو نافداً
    const minStock = product.minStock !== undefined ? product.minStock : 10;
    if ((product.stock ?? 0) <= 0) {
      triggerPrintNotification(`⚠️ تنبيه: الصنف (${product.nameAr}) نفذ من المخزون! تم إضافته للفاتورة`);
    } else if ((product.stock ?? 0) <= minStock) {
      triggerPrintNotification(`⚠️ تنبيه: مخزون (${product.nameAr}) منخفض (متبقي ${product.stock} فقط)`);
    }

    let finalPrice = option ? option.price : product.price;
    let finalName = option ? `${product.nameAr} - ${option.name}` : product.nameAr;
    let cartItemId = option ? `${product.id}-${option.id}` : product.id;
    const bundleDesc = product.isBundle && product.bundleItems 
      ? product.bundleItems.map(bi => `${bi.qty}× ${bi.productName}`).join(' + ')
      : undefined;

    setCart(prev => {
      const existing = prev.find(item => item.cartItemId === cartItemId);
      if (existing) return prev.map(item => item.cartItemId === cartItemId ? { ...item, qty: item.qty + 1, tax: (finalPrice * (item.qty + 1)) * 0.15, total: (finalPrice * (item.qty + 1)) * 1.15 } : item);
      return [...prev, { 
        id: product.id, 
        cartItemId, 
        name: finalName, 
        image: product.image,
        unitName: option?.name,
        unitType: option?.unitType,
        factor: option?.factor,
        price: finalPrice, 
        qty: 1, 
        tax: finalPrice * 0.15, 
        total: finalPrice * 1.15,
        isBundle: product.isBundle,
        bundleDescription: bundleDesc,
        bundleItems: product.bundleItems
      }];
    });
    setSelectedProductForOptions(null);

    // تمييز فوري للصنف المضاف والتمرير إليه ليتأكد الكاشير من إدراجه
    setLastAddedItemId(cartItemId);
    setTimeout(() => {
      setLastAddedItemId(prev => prev === cartItemId ? null : prev);
    }, 1800);
    setTimeout(() => {
      if (cartListRef.current) {
        const itemEl = document.getElementById(`cart-item-${cartItemId}`);
        if (itemEl) {
          itemEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    }, 60);
  };

  const handleAddGroup = (newGroup: ProductGroup) => {
    setProductGroups(prev => [...prev, newGroup]);
    triggerPrintNotification(`تمت إضافة مجموعة "${newGroup.nameAr}" بنجاح`);
  };

  const handleUpdateGroup = (id: string, updated: Partial<ProductGroup>) => {
    const oldGroup = productGroups.find(g => g.id === id);
    setProductGroups(prev => prev.map(g => g.id === id ? { ...g, ...updated } : g));
    
    // في حال تم تعديل اسم المجموعة ينعكس تلقائياً على كافة الأصناف المرتبطة
    if (updated.nameAr && oldGroup && updated.nameAr !== oldGroup.nameAr) {
      setProducts(prev => prev.map(p => {
        if (p.groupId === id || p.categoryAr === oldGroup.nameAr) {
          return { ...p, categoryAr: updated.nameAr!, categoryEn: updated.nameEn || p.categoryEn };
        }
        return p;
      }));
    }
    triggerPrintNotification('تم تحديث بيانات المجموعة بنجاح');
  };

  const handleDeleteGroup = (id: string, reassignGroupId?: string) => {
    const deleting = productGroups.find(g => g.id === id);
    if (!deleting) return;

    const targetGroup = reassignGroupId ? productGroups.find(g => g.id === reassignGroupId) : undefined;
    
    setProducts(prev => prev.map(p => {
      if (p.groupId === id || p.categoryAr === deleting.nameAr) {
        if (targetGroup) {
          return { ...p, groupId: targetGroup.id, categoryAr: targetGroup.nameAr, categoryEn: targetGroup.nameEn || p.categoryEn };
        } else {
          return { ...p, groupId: undefined, categoryAr: 'عام' };
        }
      }
      return p;
    }));

    setProductGroups(prev => prev.filter(g => g.id !== id));
    triggerPrintNotification(`تم حذف مجموعة "${deleting.nameAr}" بنجاح`);
  };

  const removeFromCart = (cartItemId: string) => setCart(prev => prev.filter(item => item.cartItemId !== cartItemId));
  const updateCartItemQtyDirect = (cartItemId: string, newQty: number) => setCart(prev => prev.map(item => item.cartItemId === cartItemId ? { ...item, qty: Math.max(1, newQty), tax: (item.price * Math.max(1, newQty)) * 0.15, total: (item.price * Math.max(1, newQty)) * 1.15 } : item));
  const updateCartItemPrice = (cartItemId: string, newPrice: number) => setCart(prev => prev.map(item => item.cartItemId === cartItemId ? { ...item, price: newPrice, tax: (newPrice * item.qty) * 0.15, total: (newPrice * item.qty) * 1.15 } : item));
  
  const incrementQty = (cartItemId: string) => {
    setCart(prev => prev.map(item => item.cartItemId === cartItemId ? {
      ...item,
      qty: item.qty + 1,
      tax: (item.price * (item.qty + 1)) * 0.15,
      total: (item.price * (item.qty + 1)) * 1.15
    } : item));
  };

  const decrementQty = (cartItemId: string) => {
    setCart(prev => {
      const target = prev.find(item => item.cartItemId === cartItemId);
      if (!target) return prev;
      if (target.qty <= 1) {
        return prev.filter(item => item.cartItemId !== cartItemId);
      }
      return prev.map(item => item.cartItemId === cartItemId ? {
        ...item,
        qty: item.qty - 1,
        tax: (item.price * (item.qty - 1)) * 0.15,
        total: (item.price * (item.qty - 1)) * 1.15
      } : item);
    });
  };
  
  // Real-time Cart and Discount Calculations
  const rawSubtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const cleanDiscountVal = Math.max(0, discountValue || 0);
  const taxRate = (companySettings.taxRate ?? 15) / 100;
  const rawTotalWithTax = rawSubtotal * (1 + taxRate);

  let discountAmount = 0;       // Taxable subtotal deduction
  let discountedSubtotal = rawSubtotal;
  let calculatedTax = rawSubtotal * taxRate;
  let calculatedTotal = rawTotalWithTax;
  let totalSavings = 0;         // Customer savings in base currency (SAR)

  if (rawSubtotal > 0 && cleanDiscountVal > 0) {
    if (discountType === 'percent') {
      const pct = Math.min(100, cleanDiscountVal);
      discountAmount = (rawSubtotal * pct) / 100;
      discountedSubtotal = Math.max(0, rawSubtotal - discountAmount);
      calculatedTax = discountedSubtotal * taxRate;
      calculatedTotal = discountedSubtotal + calculatedTax;
      totalSavings = rawTotalWithTax - calculatedTotal;
    } else {
      // Fixed financial amount discount (خصم بقيمة مالية ثابتة)
      if (discountScope === 'total') {
        // Fixed discount directly on invoice grand total (inclusive of VAT)
        totalSavings = Math.min(rawTotalWithTax, cleanDiscountVal);
        calculatedTotal = Math.max(0, rawTotalWithTax - totalSavings);
        discountedSubtotal = calculatedTotal / (1 + taxRate);
        calculatedTax = calculatedTotal - discountedSubtotal;
        discountAmount = rawSubtotal - discountedSubtotal;
      } else {
        // Fixed discount on pre-tax subtotal
        discountAmount = Math.min(rawSubtotal, cleanDiscountVal);
        discountedSubtotal = Math.max(0, rawSubtotal - discountAmount);
        calculatedTax = discountedSubtotal * taxRate;
        calculatedTotal = discountedSubtotal + calculatedTax;
        totalSavings = rawTotalWithTax - calculatedTotal;
      }
    }
  }

  const handleCheckout = (paymentMethod: 'cash' | 'card', tenderedAmount?: number, isQuick?: boolean) => {
    if (cart.length === 0) {
      triggerPrintNotification('السلة فارغة! برجاء إضافة منتجات أولاً.');
      return;
    }

    const paidAmount = paymentMethod === 'cash' 
      ? (tenderedAmount !== undefined ? tenderedAmount : calculatedTotal) 
      : calculatedTotal;

    if (paymentMethod === 'cash' && paidAmount < calculatedTotal - 0.001) {
      triggerPrintNotification(`المبلغ المدفوع (${paidAmount.toFixed(2)} ﷼) أقل من الإجمالي المطلوب (${calculatedTotal.toFixed(2)} ﷼)!`);
      return;
    }

    const changeAmount = paymentMethod === 'cash' ? Math.max(0, Number((paidAmount - calculatedTotal).toFixed(2))) : 0;

    const newInvoiceNum = `INV-${Math.floor(100000 + Math.random() * 900000)}`;
    
    const newInvoice: Invoice = {
      id: `inv-${Date.now()}`,
      number: newInvoiceNum,
      invoiceNumber: newInvoiceNum,
      date: new Date().toISOString().replace('T', ' ').substring(0, 19),
      customerName: 'عميل نقدي',
      items: cart.map(item => ({ 
        name: item.name, 
        qty: item.qty, 
        price: item.price, 
        tax: item.price * item.qty * taxRate, 
        total: item.total 
      })),
      rawSubtotal: rawSubtotal,
      subtotal: discountedSubtotal, 
      tax: calculatedTax, 
      total: calculatedTotal,
      discount: totalSavings > 0 ? Number(totalSavings.toFixed(2)) : undefined,
      discountType: totalSavings > 0 ? discountType : undefined,
      discountValue: totalSavings > 0 ? cleanDiscountVal : undefined,
      discountScope: totalSavings > 0 ? discountScope : undefined,
      paymentMethod,
      paidAmount,
      changeAmount,
      isQuickPay: isQuick || (tenderedAmount !== undefined)
    };

    setInvoices(prev => [newInvoice, ...prev]);
    setCart([]); // تفريغ السلة
    setDiscountValue(0); // إعادة تعيين الخصم للعملية القادمة
    setDiscountScope('total');
    setIsCustomQuickPayOpen(false);
    setCustomQuickPayInput('');

    if (paymentMethod === 'cash') {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastCashChange({
        invoiceNumber: newInvoiceNum,
        total: calculatedTotal,
        paidAmount,
        changeAmount,
        customerName: 'عميل نقدي',
        isQuickPay: Boolean(isQuick || (tenderedAmount !== undefined && tenderedAmount !== calculatedTotal)),
        timestamp: timeStr
      });
    } else {
      setLastCashChange(null);
    }

    // ==========================================
    // 🚀 منطق الطباعة الذكي (Electron / Windows)
    // ==========================================
    if (businessType === 'retail') {
      // 🛒 وضع التجزئة: توجيه مخصص حسب اختيار المستخدم من الهيدر
      if (retailPrintTemplate === 'pdf') {
        triggerPrintNotification('جاري حفظ الفاتورة كملف PDF...');
        // عند استخدام Electron:
        // window.electronAPI.saveAsPDF(newInvoice);
      } else {
        const activePr = printersList.find(p => p.id === selectedRetailPrinterId);
        triggerPrintNotification(`طباعة (${retailPrintTemplate === 'A4' ? 'A4' : 'حراري'}) موجهة لطابعة: ${activePr?.osPrinterName}`);
        
        // إعداد بيانات الطباعة والقالب المختار ليتم عرضها في المعاينة والطباعة
        setActivePrintTemplate(retailPrintTemplate === 'A4' ? 'A4' : 'thermal80');
        setPrintInvoiceData(newInvoice); 
        
        // عند استخدام Electron للطباعة الصامتة الموجهة:
        // window.electronAPI.printSilent({ printerName: activePr?.osPrinterName, template: retailPrintTemplate, data: newInvoice });
      }

    } else {
      // 🍔 وضع المطعم: طباعة صامتة (Silent Print) تلقائية وسريعة
      const cashierPr = printersList.find(p => p.type === 'cashier' && p.status === 'online');
      const kitchenPr = printersList.find(p => p.type === 'kitchen' && p.status === 'online');
      
      triggerPrintNotification(`طباعة صامتة: كاشير (${cashierPr?.osPrinterName || 'الافتراضية'}) - مطبخ (${kitchenPr?.osPrinterName || 'لايوجد'})`);
      
      setActivePrintTemplate('thermal80');
      setPrintInvoiceData(newInvoice); // إظهارها في المتصفح ومعاينة الإيصال
      
      // عند استخدام Electron للطباعة السريعة بدون أي تدخل من الكاشير:
      // window.electronAPI.printRestaurantSilent({
      //   cashierPrinter: cashierPr?.osPrinterName,
      //   kitchenPrinter: kitchenPr?.osPrinterName,
      //   data: newInvoice
      // });
    }
  };

  // ==========================================
  // ⏸️ منطق الطلبات المعلقة (Parked Orders)
  // ==========================================
  const applyQuickDueMinutes = (minutes: number) => {
    const d = new Date(Date.now() + minutes * 60 * 1000);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const min = String(d.getMinutes()).padStart(2, '0');
    setParkOrderDueDate(`${yyyy}-${mm}-${dd}`);
    setParkOrderDueTime(`${hh}:${min}`);
  };

  const clearParkDue = () => {
    setParkOrderDueDate('');
    setParkOrderDueTime('');
  };

  const formatDueDateTime = (dueDate?: string, dueTime?: string) => {
    if (!dueDate && !dueTime) return null;
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    let dateLabel = '';
    if (dueDate) {
      if (dueDate === todayStr) {
        dateLabel = 'اليوم';
      } else if (dueDate === tomorrowStr) {
        dateLabel = 'غداً';
      } else {
        dateLabel = dueDate;
      }
    }

    let timeLabel = dueTime || '';
    if (dueTime && dueTime.includes(':') && !dueTime.includes('م') && !dueTime.includes('ص')) {
      const [hStr, mStr] = dueTime.split(':');
      const h = parseInt(hStr, 10);
      if (!isNaN(h)) {
        const ampm = h >= 12 ? 'م' : 'ص';
        const formattedH = h % 12 === 0 ? 12 : h % 12;
        timeLabel = `${formattedH}:${mStr} ${ampm}`;
      }
    }

    return [dateLabel, timeLabel].filter(Boolean).join(' - ');
  };

  const getDueStatus = (dueDate?: string, dueTime?: string): { status: 'overdue' | 'soon' | 'future' | 'none'; diffMinutes: number; text: string } => {
    if (!dueTime && !dueDate) return { status: 'none', diffMinutes: 0, text: '' };
    
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const targetDateStr = dueDate || todayStr;
    
    let targetHours = 0;
    let targetMins = 0;
    if (dueTime) {
      if (dueTime.includes(':')) {
        const parts = dueTime.split(':');
        targetHours = parseInt(parts[0], 10);
        targetMins = parseInt(parts[1], 10) || 0;
      }
    }

    const targetDate = new Date(`${targetDateStr}T${String(targetHours).padStart(2, '0')}:${String(targetMins).padStart(2, '0')}:00`);
    if (isNaN(targetDate.getTime())) {
      return { status: 'future', diffMinutes: 0, text: formatDueDateTime(dueDate, dueTime) || '' };
    }

    const diffMs = targetDate.getTime() - now.getTime();
    const diffMinutes = Math.round(diffMs / 60000);

    if (diffMinutes < 0) {
      const overdueMins = Math.abs(diffMinutes);
      const text = overdueMins > 60 
        ? `متأخر أكثر من ساعة (${Math.floor(overdueMins / 60)}س)`
        : `متأخر بـ ${overdueMins} دقيقة`;
      return { status: 'overdue', diffMinutes, text };
    } else if (diffMinutes <= 15) {
      return { status: 'soon', diffMinutes, text: diffMinutes === 0 ? 'مستحق الآن!' : `متبقي ${diffMinutes} دقيقة` };
    } else if (diffMinutes <= 60) {
      return { status: 'soon', diffMinutes, text: `متبقي ${diffMinutes} دقيقة` };
    } else {
      return { status: 'future', diffMinutes, text: formatDueDateTime(dueDate, dueTime) || '' };
    }
  };

  const overdueParkedOrdersCount = parkedOrders.filter(o => {
    const st = getDueStatus(o.dueDate, o.dueTime);
    return st.status === 'overdue';
  }).length;

  const handleOpenParkModal = () => {
    if (cart.length === 0) {
      triggerPrintNotification('السلة فارغة! برجاء إضافة أصناف قبل تعليق الطلب.');
      return;
    }
    const nextNum = parkedOrders.length + 1;
    setParkOrderLabel(`طلب معلق #${nextNum}`);
    setParkOrderCustomer('');
    setParkOrderNote('');
    setParkOrderDueDate(new Date().toISOString().split('T')[0]);
    setParkOrderDueTime('');
    setIsParkModalOpen(true);
  };

  const handleQuickParkOrder = (customLabel?: string) => {
    if (cart.length === 0) {
      triggerPrintNotification('السلة فارغة! برجاء إضافة أصناف قبل تعليق الطلب.');
      return;
    }
    const nextNum = parkedOrders.length + 1;
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
    const finalLabel = customLabel || `طلب معلق #${nextNum}`;
    const newParked: ParkedOrder = {
      id: `parked-${Date.now()}`,
      orderNumber: nextNum,
      label: finalLabel,
      customerName: 'عميل نقدي',
      items: [...cart],
      discountType,
      discountValue: cleanDiscountVal,
      discountScope,
      rawSubtotal,
      discountAmount,
      discountedSubtotal,
      tax: calculatedTax,
      total: calculatedTotal,
      createdAt: timeStr
    };

    setParkedOrders(prev => [newParked, ...prev]);
    setCart([]);
    setDiscountValue(0);
    setDiscountScope('total');
    setIsParkModalOpen(false);
    triggerPrintNotification(`تم تعليق (${finalLabel}) بنجاح.`);
  };

  const handleConfirmParkOrder = (e?: React.FormEvent | React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (cart.length === 0) {
      setIsParkModalOpen(false);
      triggerPrintNotification('السلة فارغة! تم إغلاق النافذة.');
      return;
    }

    const nextNum = parkedOrders.length + 1;
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
    const finalLabel = (parkOrderLabel && parkOrderLabel.trim()) ? parkOrderLabel.trim() : `طلب معلق #${nextNum}`;
    const newParked: ParkedOrder = {
      id: `parked-${Date.now()}`,
      orderNumber: nextNum,
      label: finalLabel,
      customerName: (parkOrderCustomer && parkOrderCustomer.trim()) ? parkOrderCustomer.trim() : 'عميل نقدي',
      items: [...cart],
      discountType,
      discountValue: cleanDiscountVal,
      discountScope,
      rawSubtotal,
      discountAmount,
      discountedSubtotal,
      tax: calculatedTax,
      total: calculatedTotal,
      createdAt: timeStr,
      dueTime: (parkOrderDueTime && parkOrderDueTime.trim()) ? parkOrderDueTime.trim() : undefined,
      dueDate: (parkOrderDueDate && parkOrderDueDate.trim()) ? parkOrderDueDate.trim() : undefined,
      note: (parkOrderNote && parkOrderNote.trim()) ? parkOrderNote.trim() : undefined
    };

    setParkedOrders(prev => [newParked, ...prev]);
    setCart([]);
    setDiscountValue(0);
    setDiscountScope('total');
    setIsParkModalOpen(false);
    triggerPrintNotification(`تم حفظ وتعليق (${finalLabel}) بنجاح.`);
  };

  const handleRequestRestore = (order: ParkedOrder) => {
    if (cart.length > 0) {
      setOrderToRestore(order);
    } else {
      executeRestore(order, 'replace');
    }
  };

  const executeRestore = (order: ParkedOrder, mode: 'replace' | 'merge') => {
    if (mode === 'replace') {
      setCart([...order.items]);
      setDiscountType(order.discountType);
      setDiscountValue(order.discountValue);
      setDiscountScope(order.discountScope || 'total');
    } else {
      setCart(prev => {
        let merged = [...prev];
        order.items.forEach(newItem => {
          const idx = merged.findIndex(i => i.cartItemId === newItem.cartItemId);
          if (idx >= 0) {
            const existing = merged[idx];
            const updatedQty = existing.qty + newItem.qty;
            const updatedTax = (existing.price * updatedQty) * 0.15;
            const updatedTotal = (existing.price * updatedQty) * 1.15;
            merged[idx] = { ...existing, qty: updatedQty, tax: updatedTax, total: updatedTotal };
          } else {
            merged.push({ ...newItem });
          }
        });
        return merged;
      });
      if (order.discountValue > 0) {
        setDiscountType(order.discountType);
        setDiscountValue(order.discountValue);
        setDiscountScope(order.discountScope || 'total');
      }
    }

    setParkedOrders(prev => prev.filter(p => p.id !== order.id));
    setOrderToRestore(null);
    setPreviewParkedOrder(null);
    setIsParkedOrdersModalOpen(false);
    triggerPrintNotification(`تم استرجاع (${order.label}) إلى سلة المبيعات بنجاح.`);
  };

  const handleDeleteParkedOrder = (id: string) => {
    setParkedOrders(prev => prev.filter(p => p.id !== id));
    if (previewParkedOrder?.id === id) setPreviewParkedOrder(null);
    triggerPrintNotification('تم حذف الطلب المعلق بنجاح');
  };

  const cartTotal = calculatedTotal;
  const posCategories = Array.from(new Set(['الكل', ...productGroups.map(c => c.nameAr), ...products.map(p => p.categoryAr).filter(Boolean)]));

  const lowStockProductsCount = products.filter(p => {
    const min = p.minStock !== undefined ? p.minStock : 10;
    return (p.stock ?? 0) > 0 && (p.stock ?? 0) <= min;
  }).length;

  const outOfStockProductsCount = products.filter(p => (p.stock ?? 0) <= 0).length;

  const filteredProducts = products.filter(p => {
    const minStock = p.minStock !== undefined ? p.minStock : 10;
    const matchesCategory = activeCategory === 'الكل' || 
                            p.categoryAr === activeCategory || 
                            (p.groupId && productGroups.find(g => g.id === p.groupId)?.nameAr === activeCategory);
    const q = posProductSearch.trim().toLowerCase();
    const matchesSearch = !q || 
      p.nameAr.toLowerCase().includes(q) || 
      (p.nameEn && p.nameEn.toLowerCase().includes(q)) || 
      p.barcode.includes(q);

    if (!matchesCategory || !matchesSearch) return false;

    if (posStockFilter === 'low') {
      return (p.stock ?? 0) > 0 && (p.stock ?? 0) <= minStock;
    }
    if (posStockFilter === 'out') {
      return (p.stock ?? 0) <= 0;
    }
    return true;
  });

  const renderPOS = () => (
    <div className="flex flex-col h-screen w-full bg-[#f8fafc] dark:bg-slate-900 select-none font-sans overflow-hidden transition-colors" dir="rtl">
      {printNotification && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-800 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <Printer className="w-5 h-5 text-cyan-400" /> <span className="font-bold">{printNotification}</span>
        </div>
      )}
      <div className="bg-slate-900 dark:bg-black text-white h-16 flex items-center justify-between px-4 shadow-lg z-10 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <button onClick={() => setIsPosMenuOpen(true)} className="p-2 hover:bg-slate-700 rounded-lg transition"><Menu className="w-7 h-7" /></button>
          <div className="flex items-center gap-2 bg-gradient-to-l from-cyan-500 to-blue-600 px-4 py-2 rounded-lg shadow-inner">
            {businessType === 'restaurant' ? <Utensils className="w-5 h-5 text-white" /> : <Store className="w-5 h-5 text-white" />}
            <span className="font-bold text-sm tracking-wide">{businessType === 'restaurant' ? 'كاشير المطعم' : 'كاشير التجزئة'}</span>
          </div>

          {/* زر الطلبات المعلقة في الهيدر */}
          <button
            type="button"
            onClick={() => setIsParkedOrdersModalOpen(true)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition border cursor-pointer ${
              parkedOrders.length > 0 
                ? 'bg-amber-500/15 hover:bg-amber-500/25 border-amber-500/40 text-amber-300 shadow-sm' 
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
            title="عرض واسترجاع الطلبات المعلقة"
          >
            <Clock className={`w-4 h-4 ${overdueParkedOrdersCount > 0 ? 'text-rose-400 animate-pulse' : parkedOrders.length > 0 ? 'text-amber-400' : 'text-slate-400'}`} />
            <span className="hidden md:inline">الطلبات المعلقة</span>
            {parkedOrders.length > 0 ? (
              <div className="flex items-center gap-1">
                <span className="bg-amber-500 text-slate-950 font-black font-mono text-[10px] px-1.5 py-0.2 rounded-full shadow-sm">
                  {parkedOrders.length}
                </span>
                {overdueParkedOrdersCount > 0 && (
                  <span className="bg-rose-500 text-white font-black font-mono text-[9px] px-1.5 py-0.2 rounded-full animate-bounce shadow-sm flex items-center gap-0.5" title={`${overdueParkedOrdersCount} طلب متأخر عن موعد العودة المتوقع`}>
                    <AlertCircle className="w-2.5 h-2.5" />
                    <span>{overdueParkedOrdersCount} متأخر</span>
                  </span>
                )}
              </div>
            ) : (
              <span className="text-[10px] text-slate-500 font-mono">0</span>
            )}
          </button>

          {businessType === 'retail' && (
            <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-xl text-xs text-slate-300">
              
              {/* 1. اختيار قالب الطباعة */}
              <div className="flex items-center gap-1 border-l border-slate-700 pl-2 ml-1">
                <span className="font-bold">القالب:</span>
                <select
                  value={retailPrintTemplate}
                  onChange={(e) => setRetailPrintTemplate(e.target.value as 'thermal80' | 'A4' | 'pdf')}
                  className="bg-transparent font-black text-amber-400 outline-none cursor-pointer"
                >
                  <option value="thermal80" className="bg-slate-800 text-white">إيصال حراري</option>
                  <option value="A4" className="bg-slate-800 text-white">فاتورة A4</option>
                  <option value="pdf" className="bg-slate-800 text-white">حفظ كـ PDF</option>
                </select>
              </div>

              {/* 2. اختيار طابعة الويندوز (يختفي إذا اختار حفظ PDF) */}
              {retailPrintTemplate !== 'pdf' && (
                <>
                  <Printer className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold">توجيه:</span>
                  <select
                    value={selectedRetailPrinterId}
                    onChange={(e) => setSelectedRetailPrinterId(e.target.value)}
                    className="bg-transparent font-black text-cyan-400 outline-none cursor-pointer max-w-[120px]"
                  >
                    {printersList.map(pr => (
                      <option key={pr.id} value={pr.id} className="bg-slate-800 text-white">
                        {pr.name} ({pr.osPrinterName})
                      </option>
                    ))}
                  </select>
                </>
              )}
            </div>
          )}
        </div>
        {businessType === 'retail' && (
          <div className="flex-1 max-w-lg mx-8 relative">
            <input ref={barcodeInputRef} type="text" placeholder="مرر الباركود هنا للإضافة المباشرة..." onKeyDown={handleBarcodeScan} className="w-full bg-slate-800 border-2 border-cyan-500 rounded-xl px-4 py-2 text-white font-mono focus:outline-none focus:ring-2 focus:ring-cyan-400 placeholder:text-slate-400" autoFocus />
            <div className="absolute left-3 top-2.5 text-cyan-400 animate-pulse"><FileDigit className="w-5 h-5"/></div>
          </div>
        )}
        <div className="flex-1 flex justify-end gap-2 overflow-x-auto no-scrollbar px-4">
          {businessType === 'restaurant' && posCategories.map((cat, idx) => (
            <button key={idx} onClick={() => setActiveCategory(cat)} className={`px-6 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-all transform ${activeCategory === cat ? 'bg-cyan-500 text-slate-900 shadow-md' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'}`}>{cat}</button>
          ))}
        </div>
      </div>
      <div className={`flex flex-1 overflow-hidden relative ${isLayoutReversed ? 'flex-row-reverse' : 'flex-row'}`}>
        {isPosMenuOpen && (
          <>
            <div className="absolute inset-0 bg-black/60 z-40 backdrop-blur-sm" onClick={() => setIsPosMenuOpen(false)} />
            <div className="absolute top-0 right-0 h-full w-64 bg-slate-900 z-50 animate-in slide-in-from-right"><Sidebar currentView={currentView} onViewChange={(v) => { setCurrentView(v as ExtendedViewType); setIsPosMenuOpen(false); }} onLogout={handleLogout} /></div>
          </>
        )}
        <div className={`w-[42%] min-w-[440px] max-w-[540px] h-full bg-slate-50/70 dark:bg-slate-900/90 flex flex-col shadow-2xl z-0 ${isLayoutReversed ? 'border-r dark:border-slate-800' : 'border-l dark:border-slate-800'} border-slate-200 relative transition-colors overflow-hidden`}>
          
          {/* 1. Header: Sleek, compact cart status bar */}
          <div className="shrink-0 px-4 py-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-sm shadow-cyan-500/20">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-sm font-black text-slate-900 dark:text-white">سلة المشتريات</h2>
                  <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                    {cart.length} أصناف · {cart.reduce((s, i) => s + i.qty, 0)} قطع
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm ? true : true) {
                      setCart([]);
                      setDiscountValue(0);
                    }
                  }}
                  className="px-2.5 py-1 text-xs font-bold text-rose-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition flex items-center gap-1 cursor-pointer"
                  title="تفريغ السلة بالكامل"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>تفريغ</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsParkedOrdersModalOpen(true)}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg border transition flex items-center gap-1 cursor-pointer ${
                  parkedOrders.length > 0
                    ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/40 hover:bg-amber-500/20'
                    : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 border-transparent'
                }`}
                title="عرض الطلبات المعلقة"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>المعلقة</span>
                {parkedOrders.length > 0 && (
                  <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-mono font-black flex items-center justify-center">
                    {parkedOrders.length}
                  </span>
                )}
              </button>

              {businessType === 'restaurant' && (
                <button
                  type="button"
                  onClick={() => triggerPrintNotification('تم إرسال الطلبات للمطبخ (طابعة المطبخ)')}
                  className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 font-bold rounded-lg text-xs flex items-center gap-1 cursor-pointer transition"
                  title="إرسال الفاتورة لطابعة المطبخ"
                >
                  <ChefHat className="w-3.5 h-3.5" />
                  <span>المطبخ</span>
                </button>
              )}
            </div>
          </div>

          {/* 2. Items List: Dedicated high-visibility vertical scroll area */}
          <div ref={cartListRef} className="flex-1 min-h-0 overflow-y-auto p-3 space-y-2.5 custom-scrollbar">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 select-none animate-in fade-in duration-300">
                <div className="w-20 h-20 rounded-3xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3 shadow-inner">
                  <ShoppingBag className="w-9 h-9 stroke-[1.5]" />
                </div>
                <h3 className="text-base font-black text-slate-800 dark:text-slate-200 mb-1">السلة فارغة حالياً</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-[260px] leading-relaxed">
                  انقر على أي صنف من قائمة المنتجات لإضافته، أو مرر الباركود للمسح المباشر.
                </p>
                {businessType === 'retail' && (
                  <div className="mt-4 px-3 py-1.5 rounded-full bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-300/60 dark:border-cyan-800/60 text-cyan-700 dark:text-cyan-300 text-[11px] font-bold flex items-center gap-1.5">
                    <FileDigit className="w-3.5 h-3.5 text-cyan-500" />
                    <span>جاهز لاستقبال مسح الباركود</span>
                  </div>
                )}
              </div>
            ) : (
              cart.map((item, idx) => {
                const isRecentlyAdded = item.cartItemId === lastAddedItemId;
                return (
                  <div
                    key={item.cartItemId}
                    id={`cart-item-${item.cartItemId}`}
                    className={`rounded-2xl border transition-all duration-300 p-3 shadow-xs ${
                      isRecentlyAdded
                        ? 'bg-cyan-50/90 dark:bg-cyan-950/40 border-cyan-400 dark:border-cyan-500 shadow-md ring-2 ring-cyan-400/30'
                        : 'bg-white dark:bg-slate-800/95 border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
                    }`}
                  >
                    {/* Top Row: Index, Name, Line Total, Trash */}
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-start gap-2 flex-1 min-w-0">
                        <span className="text-[11px] font-mono font-bold text-slate-400 dark:text-slate-500 mt-0.5 shrink-0">
                          #{idx + 1}
                        </span>
                        {item.image && (
                          <div className="w-8 h-8 rounded-lg overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-900 mt-0.5 shadow-xs">
                            <img 
                              src={item.image} 
                              alt={item.name} 
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white truncate">
                            {item.name}
                          </h4>
                          {item.unitName && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <span className="text-[10px] font-bold bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border border-cyan-500/20 px-1.5 py-0.2 rounded-md flex items-center gap-1">
                                <Package className="w-2.5 h-2.5" />
                                <span>تعبئة: {item.unitName}</span>
                              </span>
                              {item.factor && item.factor > 1 && (
                                <span className="text-[9.5px] text-slate-400 font-mono">
                                  ({item.factor} قطع)
                                </span>
                              )}
                            </div>
                          )}
                          {item.isBundle && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <span className="text-[9.5px] font-black bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30 px-1.5 py-0.2 rounded flex items-center gap-1">
                                <Boxes className="w-2.5 h-2.5" />
                                <span>باقة كومبو</span>
                              </span>
                              {item.bundleDescription && (
                                <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[200px]" title={item.bundleDescription}>
                                  ({item.bundleDescription})
                                </span>
                              )}
                            </div>
                          )}
                          <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500 dark:text-slate-400 font-mono">
                            <span className="inline-flex items-center gap-0.5 font-bold">
                              <span>{item.price.toFixed(2)}</span>
                              <SaudiRiyalSymbol className="w-2.5 h-2.5 inline-block opacity-80" />
                            </span>
                            <span>×</span>
                            <span className="font-bold text-slate-800 dark:text-slate-200">{item.qty}</span>
                            {companySettings.taxRate > 0 && (
                              <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-700/60 px-1.5 py-0.2 rounded font-sans">
                                ضريبة {companySettings.taxRate}%
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right/End: Line Total & Delete */}
                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-left font-mono font-black text-sm sm:text-base text-cyan-600 dark:text-cyan-400 inline-flex items-center gap-1">
                          <span>{item.total.toFixed(2)}</span>
                          <SaudiRiyalSymbol className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 inline-block align-middle" />
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.cartItemId)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                          title="حذف الصنف من السلة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Bottom Row: Stepper Controls & Editable Unit Price */}
                    <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-slate-100 dark:border-slate-700/60">
                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-0.5 bg-slate-100 dark:bg-slate-700/80 p-0.5 rounded-xl border border-slate-200 dark:border-slate-600/60">
                        <button
                          type="button"
                          onClick={() => decrementQty(item.cartItemId)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition active:scale-95 shadow-xs cursor-pointer"
                          title="إنقاص الكمية"
                        >
                          <Minus className="w-3 h-3" />
                        </button>

                        <input
                          type="number"
                          min="1"
                          value={item.qty}
                          onChange={(e) => updateCartItemQtyDirect(item.cartItemId, parseInt(e.target.value) || 1)}
                          onFocus={handleFocusSelect}
                          className="w-10 text-center font-mono font-black text-xs bg-transparent text-slate-900 dark:text-white focus:outline-none"
                          dir="ltr"
                        />

                        <button
                          type="button"
                          onClick={() => incrementQty(item.cartItemId)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition active:scale-95 shadow-xs cursor-pointer"
                          title="زيادة الكمية"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Editable Unit Price */}
                      <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-900/60 px-2 py-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
                        <span className="text-[10px] text-slate-400 font-bold">سعر الحبة:</span>
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          value={item.price}
                          onChange={(e) => updateCartItemPrice(item.cartItemId, parseFloat(e.target.value) || 0)}
                          onFocus={handleFocusSelect}
                          className="w-14 text-center font-mono font-bold bg-transparent text-slate-800 dark:text-slate-200 focus:outline-none"
                          dir="ltr"
                        />
                        <SaudiRiyalSymbol className="w-2.5 h-2.5 text-slate-400" />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* 3. Streamlined Bottom Checkout Dock (Organized, High-Clarity Totals & Actions) */}
          <div className="shrink-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 p-3 flex flex-col gap-2.5 shadow-[0_-8px_25px_rgba(0,0,0,0.06)]">
            
            {/* Dock Row A: Quick Action Toolbar & Discount Button */}
            <div className="flex items-center justify-between gap-2">
              {/* Discount Trigger / Pill */}
              <div className="flex items-center gap-1.5 flex-1 min-w-0">
                <button
                  type="button"
                  onClick={() => setIsDiscountDrawerOpen(!isDiscountDrawerOpen)}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border cursor-pointer min-w-0 flex-1 justify-between ${
                    cleanDiscountVal > 0
                      ? 'bg-amber-500/15 border-amber-500/40 text-amber-700 dark:text-amber-300 font-black'
                      : isDiscountDrawerOpen
                      ? 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white'
                      : 'bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                  }`}
                  title="تطبيق أو تعديل خصم على الفاتورة (مبلغ مالي ثابت أو نسبة مئوية)"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <BadgePercent className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span className="truncate">
                      {cleanDiscountVal > 0
                        ? (discountType === 'fixed'
                            ? `خصم ثابت ${cleanDiscountVal} ﷼ ${discountScope === 'total' ? 'من الإجمالي' : 'قبل الضريبة'} (-${totalSavings.toFixed(2)})`
                            : `خصم ${cleanDiscountVal}% (-${totalSavings.toFixed(2)} ﷼)`)
                        : '+ خصم الفاتورة (مبلغ ثابت / نسبة %)'}
                    </span>
                  </div>
                  {cleanDiscountVal > 0 && (
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        setDiscountValue(0);
                      }}
                      className="p-0.5 hover:bg-rose-500 hover:text-white rounded-full transition shrink-0 ml-1"
                      title="إلغاء الخصم"
                    >
                      <X className="w-3 h-3" />
                    </span>
                  )}
                </button>

                {/* Open Full Discount Modal Button */}
                <button
                  type="button"
                  onClick={() => setIsDiscountModalOpen(true)}
                  className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-600 dark:text-slate-300 rounded-xl border border-slate-200 dark:border-slate-700 transition cursor-pointer shrink-0"
                  title="فتح واجهة تطبيق الخصم الكاملة"
                >
                  <Sliders className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Park Order Action Buttons */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  disabled={cart.length === 0}
                  onClick={handleOpenParkModal}
                  className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs flex items-center gap-1 cursor-pointer transition border border-slate-200 dark:border-slate-700"
                  title="تعليق الطلب الحالي مع إمكانية إضافة ملاحظة"
                >
                  <PauseCircle className="w-3.5 h-3.5 text-amber-500" />
                  <span>تعليق</span>
                </button>

                <button
                  type="button"
                  disabled={cart.length === 0}
                  onClick={() => handleQuickParkOrder()}
                  className="p-1.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black rounded-xl text-xs flex items-center justify-center cursor-pointer transition shadow-xs"
                  title="تعليق فوري بنقرة واحدة"
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                </button>
              </div>
            </div>

            {/* Collapsible Discount Drawer */}
            {isDiscountDrawerOpen && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/90 rounded-2xl border border-amber-500/40 shadow-sm space-y-2.5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between text-xs font-black text-slate-800 dark:text-slate-200">
                  <div className="flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-amber-500" />
                    <span>تحديد خصم الفاتورة</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setIsDiscountModalOpen(true)}
                      className="text-[10px] text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-1 font-bold ml-2 cursor-pointer"
                      title="فتح شاشة الخصم الموسعة"
                    >
                      <Maximize2 className="w-3 h-3" />
                      <span>نافذة الخصم الكاملة</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsDiscountDrawerOpen(false)}
                      className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Main Discount Type: Fixed Amount vs Percentage */}
                <div className="grid grid-cols-2 gap-1.5 bg-slate-200 dark:bg-slate-900 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setDiscountType('fixed')}
                    className={`py-1.5 px-2 text-xs font-black rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      discountType === 'fixed'
                        ? 'bg-amber-500 text-slate-950 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    <Banknote className="w-3.5 h-3.5" />
                    <span>مبلغ مالي ثابت (﷼)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setDiscountType('percent');
                      if (discountValue > 100) setDiscountValue(10);
                    }}
                    className={`py-1.5 px-2 text-xs font-black rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      discountType === 'percent'
                        ? 'bg-amber-500 text-slate-950 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    <Percent className="w-3.5 h-3.5" />
                    <span>نسبة مئوية (%)</span>
                  </button>
                </div>

                {/* Scope selector for Fixed Amount */}
                {discountType === 'fixed' && (
                  <div className="flex items-center justify-between text-[11px] bg-amber-500/10 border border-amber-500/25 px-2 py-1 rounded-lg">
                    <span className="font-bold text-amber-900 dark:text-amber-300">طريقة التطبيق:</span>
                    <div className="flex items-center gap-2">
                      <label className="flex items-center gap-1 cursor-pointer font-bold text-slate-800 dark:text-slate-200">
                        <input
                          type="radio"
                          name="quickDiscountScope"
                          checked={discountScope === 'total'}
                          onChange={() => setDiscountScope('total')}
                          className="accent-amber-500 text-xs"
                        />
                        <span>من الإجمالي النهائي شامل الضريبة</span>
                      </label>
                      <label className="flex items-center gap-1 cursor-pointer font-bold text-slate-600 dark:text-slate-400">
                        <input
                          type="radio"
                          name="quickDiscountScope"
                          checked={discountScope === 'subtotal'}
                          onChange={() => setDiscountScope('subtotal')}
                          className="accent-amber-500 text-xs"
                        />
                        <span>قبل الضريبة</span>
                      </label>
                    </div>
                  </div>
                )}

                {/* Input and currency symbol */}
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="number"
                      min="0"
                      max={discountType === 'percent' ? 100 : (discountScope === 'total' ? rawTotalWithTax : rawSubtotal)}
                      step={discountType === 'percent' ? '1' : '0.5'}
                      value={discountValue === 0 ? '' : discountValue}
                      placeholder={discountType === 'fixed' ? 'أدخل المبلغ بالريال...' : 'أدخل النسبة المئوية...'}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        if (isNaN(val) || val <= 0) {
                          setDiscountValue(0);
                        } else if (discountType === 'percent') {
                          setDiscountValue(Math.min(100, Math.max(0, val)));
                        } else {
                          setDiscountValue(Math.max(0, val));
                        }
                      }}
                      onFocus={handleFocusSelect}
                      className="w-full text-center font-mono font-black text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl py-1.5 px-8 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                      dir="ltr"
                    />
                    <div className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                      {discountType === 'fixed' ? (
                        <SaudiRiyalSymbol className="w-3.5 h-3.5 text-amber-500" />
                      ) : (
                        <span className="font-bold text-amber-500">%</span>
                      )}
                    </div>
                  </div>

                  {cleanDiscountVal > 0 && (
                    <button
                      type="button"
                      onClick={() => setDiscountValue(0)}
                      className="px-2.5 py-1.5 text-xs rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-500 hover:text-white transition cursor-pointer font-bold shrink-0"
                    >
                      تصفير
                    </button>
                  )}
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pt-0.5">
                  <span className="text-[10px] text-slate-400 font-bold shrink-0">سريع:</span>
                  {(discountType === 'percent' ? [5, 10, 15, 20, 25, 50] : [5, 10, 15, 20, 50, 100]).map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setDiscountValue(preset)}
                      className={`px-2 py-0.5 text-[11px] font-mono rounded-lg font-bold transition cursor-pointer border flex items-center gap-0.5 shrink-0 ${
                        cleanDiscountVal === preset
                          ? 'bg-amber-500 border-amber-600 text-slate-950 font-black'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span>{preset}</span>
                      {discountType === 'percent' ? '%' : <SaudiRiyalSymbol className="w-2 h-2" />}
                    </button>
                  ))}
                  {discountType === 'fixed' && rawTotalWithTax > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setDiscountScope('total');
                        setDiscountValue(Number((rawSubtotal * taxRate).toFixed(2)));
                      }}
                      className="px-2 py-0.5 text-[10px] font-black rounded-lg bg-purple-500/15 text-purple-700 dark:text-purple-300 border border-purple-500/30 shrink-0 cursor-pointer"
                      title="خصم يعادل قيمة الضريبة بالكامل"
                    >
                      خصم الضريبة
                    </button>
                  )}
                </div>

                {/* Live Real-time summary strip */}
                {cleanDiscountVal > 0 && (
                  <div className="text-[11px] font-bold bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200 dark:border-slate-700 flex justify-between items-center text-slate-600 dark:text-slate-300">
                    <span>
                      وفر العميل: <strong className="text-amber-500 font-mono font-black">{totalSavings.toFixed(2)} ﷼</strong>
                    </span>
                    <span>
                      النهائي المستحق: <strong className="text-cyan-600 dark:text-cyan-400 font-mono font-black">{calculatedTotal.toFixed(2)} ﷼</strong>
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Dock Row B: Modern Totals Card */}
            <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-2.5 sm:p-3 border border-slate-200 dark:border-slate-700/80 space-y-2">
              {/* Compact Breakdown Line */}
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium">
                <div className="flex items-center gap-3">
                  <span className="inline-flex items-center gap-1">
                    <span>المجموع:</span>
                    <strong className="font-mono text-slate-800 dark:text-slate-200">{rawSubtotal.toFixed(2)}</strong>
                    <SaudiRiyalSymbol className="w-2.5 h-2.5 opacity-70" />
                  </span>

                  <span className="inline-flex items-center gap-1">
                    <span>الضريبة ({companySettings.taxRate}%):</span>
                    <strong className="font-mono text-slate-800 dark:text-slate-200">{calculatedTax.toFixed(2)}</strong>
                    <SaudiRiyalSymbol className="w-2.5 h-2.5 opacity-70" />
                  </span>

                  {totalSavings > 0 && (
                    <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-bold">
                      <span>الخصم:</span>
                      <strong className="font-mono">-{totalSavings.toFixed(2)}</strong>
                      <SaudiRiyalSymbol className="w-2.5 h-2.5" />
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setIsSummaryDetailsOpen(!isSummaryDetailsOpen)}
                  className="text-[11px] text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <span>{isSummaryDetailsOpen ? 'إخفاء' : 'تفاصيل'}</span>
                  {isSummaryDetailsOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>
              </div>

              {/* Extended Details (if opened) */}
              {isSummaryDetailsOpen && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 space-y-1 text-xs text-slate-600 dark:text-slate-400">
                  <div className="flex justify-between">
                    <span>المبلغ قبل الخصم:</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{rawSubtotal.toFixed(2)} <SaudiRiyalSymbol className="w-2.5 h-2.5 inline" /></span>
                  </div>
                  {totalSavings > 0 && (
                    <div className="flex justify-between text-amber-600 dark:text-amber-400">
                      <span>الخصم المطبق ({discountType === 'fixed' ? (discountScope === 'total' ? 'مبلغ ثابت من الإجمالي' : 'مبلغ ثابت قبل الضريبة') : `${cleanDiscountVal}%`}):</span>
                      <span className="font-mono font-bold">-{totalSavings.toFixed(2)} <SaudiRiyalSymbol className="w-2.5 h-2.5 inline" /></span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>المبلغ الخاضع للضريبة:</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{discountedSubtotal.toFixed(2)} <SaudiRiyalSymbol className="w-2.5 h-2.5 inline" /></span>
                  </div>
                  <div className="flex justify-between">
                    <span>ضريبة القيمة المضافة:</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{calculatedTax.toFixed(2)} <SaudiRiyalSymbol className="w-2.5 h-2.5 inline" /></span>
                  </div>
                </div>
              )}

              {/* High-Impact Final Total Row */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-700/80">
                <div>
                  <span className="text-xs font-black text-slate-700 dark:text-slate-300">
                    الإجمالي النهائي المستحق
                  </span>
                  {companySettings.multiCurrency?.enabled && (
                    <div className="flex items-center gap-1.5 mt-0.5">
                      {companySettings.multiCurrency.currencies
                        .filter(c => c.isEnabled && !c.isBase)
                        .slice(0, 2)
                        .map(c => (
                          <span key={c.code} className="text-[10px] font-mono font-bold text-slate-500 dark:text-slate-400">
                            {(calculatedTotal / (c.exchangeRate || 1)).toFixed(2)} {c.symbol}
                          </span>
                        ))}
                    </div>
                  )}
                </div>

                <div className="font-mono font-black text-2xl sm:text-3xl text-cyan-600 dark:text-cyan-400 inline-flex items-center gap-1.5 drop-shadow-xs">
                  <span>{calculatedTotal.toFixed(2)}</span>
                  <SaudiRiyalSymbol className="w-6 h-6 text-cyan-600 dark:text-cyan-400 inline-block align-middle" />
                </div>
              </div>
            </div>

            {/* Dock Row C: Quick Pay Cash Bar (1-Click Instant Cash & Banknotes) */}
            <div className="p-2 bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-transparent dark:from-amber-500/15 dark:via-emerald-500/15 rounded-xl border border-amber-500/30 dark:border-amber-500/40 space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-[11px] font-black text-slate-800 dark:text-slate-200">
                  <Zap className="w-3 h-3 text-amber-500 fill-current" />
                  <span>دفع سريع (كاش فوري):</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCustomQuickPayOpen(!isCustomQuickPayOpen)}
                  className="text-[10px] font-bold text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <Coins className="w-3 h-3" />
                  <span>{isCustomQuickPayOpen ? 'إغلاق المخصص' : '+ مبلغ آخر'}</span>
                </button>
              </div>

              {/* Custom Cash Tender Drawer */}
              {isCustomQuickPayOpen && (
                <div className="p-2 bg-white dark:bg-slate-800 rounded-xl border border-cyan-500/40 shadow-sm space-y-2 animate-in fade-in">
                  <div className="flex items-center gap-1.5">
                    <div className="relative flex-1">
                      <input
                        type="number"
                        min="0"
                        step="1"
                        placeholder="المبلغ المستلم..."
                        value={customQuickPayInput}
                        onChange={(e) => setCustomQuickPayInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            const val = parseFloat(customQuickPayInput);
                            if (!isNaN(val) && val >= calculatedTotal && calculatedTotal > 0) {
                              handleCheckout('cash', val, true);
                            }
                          }
                        }}
                        className="w-full text-center font-mono font-bold text-xs bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg py-1 px-2 text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                        dir="ltr"
                        autoFocus
                      />
                    </div>
                    <button
                      type="button"
                      disabled={cart.length === 0 || !customQuickPayInput || parseFloat(customQuickPayInput) < calculatedTotal}
                      onClick={() => {
                        const val = parseFloat(customQuickPayInput);
                        if (!isNaN(val)) {
                          handleCheckout('cash', val, true);
                        }
                      }}
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black text-xs rounded-lg transition cursor-pointer shrink-0"
                    >
                      دفع وحساب الباقي
                    </button>
                  </div>
                  {customQuickPayInput && !isNaN(parseFloat(customQuickPayInput)) && (
                    <div className="flex justify-between text-[11px] font-bold pt-1 border-t border-slate-100 dark:border-slate-700 px-1">
                      <span className="text-slate-500">المستلم: {parseFloat(customQuickPayInput).toFixed(2)} ﷼</span>
                      {parseFloat(customQuickPayInput) >= calculatedTotal ? (
                        <span className="text-emerald-600 dark:text-emerald-400">
                          الباقي: {(parseFloat(customQuickPayInput) - calculatedTotal).toFixed(2)} ﷼
                        </span>
                      ) : (
                        <span className="text-rose-500">
                          ناقص: {(calculatedTotal - parseFloat(customQuickPayInput)).toFixed(2)} ﷼
                        </span>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Single Horizontal Strip for Fast Banknotes */}
              <div className="grid grid-cols-5 gap-1">
                {/* 1. Exact Cash */}
                <button
                  type="button"
                  disabled={cart.length === 0 || calculatedTotal <= 0}
                  onClick={() => handleCheckout('cash', calculatedTotal, true)}
                  className="py-1 px-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed text-emerald-800 dark:text-emerald-300 transition flex flex-col items-center justify-center cursor-pointer shadow-xs"
                  title={`إتمام فوري بالمبلغ بالضبط: ${calculatedTotal.toFixed(2)} ﷼`}
                >
                  <span className="text-[8px] font-black uppercase text-emerald-600 dark:text-emerald-400">بالضبط</span>
                  <span className="font-mono font-black text-[11px] leading-tight">{calculatedTotal > 0 ? calculatedTotal.toFixed(0) : '0'} ﷼</span>
                </button>

                {/* 2. Common Banknotes */}
                {[50, 100, 200, 500].map((amt) => {
                  const isEligible = calculatedTotal > 0 && amt >= calculatedTotal;
                  const change = isEligible ? amt - calculatedTotal : 0;
                  return (
                    <button
                      key={amt}
                      type="button"
                      disabled={cart.length === 0 || !isEligible}
                      onClick={() => handleCheckout('cash', amt, true)}
                      className={`py-1 px-1 rounded-lg border transition flex flex-col items-center justify-center cursor-pointer shadow-xs ${
                        isEligible
                          ? 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 hover:border-amber-400 active:scale-95'
                          : 'border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-800/30 text-slate-400 dark:text-slate-600 opacity-40 cursor-not-allowed'
                      }`}
                      title={
                        isEligible
                          ? `كاش ${amt} ﷼ - الباقي: ${change.toFixed(2)} ﷼`
                          : `فئة ${amt} ﷼ أقل من الإجمالي`
                      }
                    >
                      <div className="flex items-center gap-0.5">
                        <span className="font-mono font-black text-[11px] text-slate-800 dark:text-slate-200">{amt}</span>
                        <SaudiRiyalSymbol className="w-2 h-2 opacity-70" />
                      </div>
                      <span className="text-[7.5px] font-mono leading-none text-slate-400 dark:text-slate-500">
                        {isEligible ? `باقي ${change.toFixed(0)}` : 'أقل'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dock Row D: Primary Checkout Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <button
                type="button"
                disabled={cart.length === 0}
                onClick={() => handleCheckout('cash')}
                className="py-3 bg-gradient-to-l from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-500/20 active:scale-98 transition"
              >
                <Banknote className="w-4 h-4 sm:w-5 sm:h-5" />
                <span>دفع كاش</span>
                <span className="font-mono text-xs opacity-90">({calculatedTotal.toFixed(2)})</span>
              </button>

              <button
                type="button"
                disabled={cart.length === 0}
                onClick={() => handleCheckout('card')}
                className="py-3 bg-gradient-to-l from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-500/20 active:scale-98 transition"
              >
                <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
                <span>دفع شبكة</span>
                <span className="font-mono text-xs opacity-90">({calculatedTotal.toFixed(2)})</span>
              </button>
            </div>
          </div>
        </div>
        <div className="flex-1 bg-slate-200/50 dark:bg-slate-900 p-3 overflow-hidden flex flex-col gap-3 transition-colors">
          
          {/* شريط أدوات وتصفية المخزون لشبكة المنتجات (POS Products & Stock Toolbar) */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 bg-white dark:bg-slate-800/90 p-2.5 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
            {/* 1. حقل البحث السريع في المنتجات */}
            <div className="relative flex-1 min-w-[170px] max-w-xs">
              <input
                type="text"
                placeholder="بحث في الأصناف أو الباركود..."
                value={posProductSearch}
                onChange={(e) => setPosProductSearch(e.target.value)}
                className="w-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl pr-8 pl-7 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-bold"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
              {posProductSearch && (
                <button
                  type="button"
                  onClick={() => setPosProductSearch('')}
                  className="absolute left-2.5 top-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  title="مسح البحث"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* 2. أزرار تصفية حالة المخزون (Stock Status Filter) */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setPosStockFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  posStockFilter === 'all'
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>الكل</span>
                <span className="font-mono text-[10px] opacity-75 font-black">({products.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setPosStockFilter('low')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                  posStockFilter === 'low'
                    ? 'bg-amber-500 text-slate-950 shadow-md ring-2 ring-amber-400/50'
                    : 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/30 hover:bg-amber-500/20'
                }`}
                title="عرض الأصناف التي قارب مخزونها على الانتهاء (المخزون <= الحد الأدنى)"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 fill-current" />
                <span>مخزون منخفض</span>
                <span className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] font-black ${
                  posStockFilter === 'low' ? 'bg-black/20 text-slate-950' : 'bg-amber-500/25 text-amber-800 dark:text-amber-200'
                }`}>
                  {lowStockProductsCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setPosStockFilter('out')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                  posStockFilter === 'out'
                    ? 'bg-rose-600 text-white shadow-md ring-2 ring-rose-500/50'
                    : 'bg-rose-500/10 text-rose-700 dark:text-rose-400 border border-rose-500/30 hover:bg-rose-500/20'
                }`}
                title="عرض الأصناف النافدة من المخزون (0 متبقي)"
              >
                <AlertCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>نفذ المخزون</span>
                <span className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] font-black ${
                  posStockFilter === 'out' ? 'bg-white/20 text-white' : 'bg-rose-500/25 text-rose-800 dark:text-rose-200'
                }`}>
                  {outOfStockProductsCount}
                </span>
              </button>
            </div>

            {/* 3. دليل الألوان وتنبيه المخزون (Legend) */}
            <div className="hidden xl:flex items-center gap-2.5 text-[11px] text-slate-500 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700 pr-2.5">
              <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-bold" title="إطار ذهبي وأيقونة تحذير تعني المخزون وصل للحد الأدنى أو أقل">
                <span className="w-2 h-2 rounded-full bg-amber-400 ring-2 ring-amber-400/50 animate-pulse"></span>
                إطار أصفر: منخفض
              </span>
              <span className="flex items-center gap-1 text-rose-600 dark:text-rose-400 font-bold" title="إطار أحمر وأيقونة تنبيه تعني نفاد المخزون بالكامل (0 متبقي)">
                <span className="w-2 h-2 rounded-full bg-rose-500 ring-2 ring-rose-500/50"></span>
                إطار أحمر: نافد
              </span>
            </div>
          </div>

          {/* شريط مجموعات الأصناف والتصنيفات (POS Item Groups Navigation Bar) */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 shrink-0">
            <button
              type="button"
              onClick={() => setActiveCategory('الكل')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs ${
                activeCategory === 'الكل'
                  ? 'bg-gradient-to-l from-cyan-500 to-blue-600 text-white shadow-cyan-500/25 ring-2 ring-cyan-400'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>جميع الأصناف</span>
              <span className={`font-mono text-[10px] px-1.5 py-0.2 rounded-full ${
                activeCategory === 'الكل' ? 'bg-white/20 text-white font-black' : 'bg-slate-100 dark:bg-slate-700 text-slate-500'
              }`}>
                {products.length}
              </span>
            </button>

            {productGroups.map((grp) => {
              const isSelected = activeCategory === grp.nameAr;
              const count = products.filter(p => p.groupId === grp.id || p.categoryAr === grp.nameAr).length;
              const grpColor = grp.color || '#06b6d4';

              return (
                <button
                  key={grp.id}
                  type="button"
                  onClick={() => setActiveCategory(grp.nameAr)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer border shadow-xs ${
                    isSelected
                      ? 'text-white shadow-md ring-2 ring-white/60'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/80 border-slate-200 dark:border-slate-700'
                  }`}
                  style={isSelected ? {
                    backgroundColor: grpColor,
                    borderColor: grpColor,
                  } : undefined}
                >
                  <span 
                    className="w-2 h-2 rounded-full shrink-0" 
                    style={{ backgroundColor: isSelected ? '#ffffff' : grpColor }} 
                  />
                  <span>{grp.nameAr}</span>
                  <span className={`font-mono text-[10px] font-black px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-black/25 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-500'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* شبكة المنتجات (POS Products Grid) */}
          <div className="flex-1 overflow-y-auto bg-transparent pr-1">
            {filteredProducts.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-center p-6 bg-white/40 dark:bg-slate-800/40 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700">
                <Package className="w-12 h-12 text-slate-400 mb-2" />
                <p className="font-bold text-slate-700 dark:text-slate-300">لا توجد منتجات مطابقة لخيارات البحث أو التصفية الحالية</p>
                {(posStockFilter !== 'all' || posProductSearch || activeCategory !== 'الكل') && (
                  <button
                    onClick={() => { setPosStockFilter('all'); setPosProductSearch(''); setActiveCategory('الكل'); }}
                    className="mt-3 text-xs text-cyan-600 dark:text-cyan-400 font-bold hover:underline cursor-pointer"
                  >
                    إلغاء التصفية وعرض جميع الأصناف
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 auto-rows-[115px]">
                {filteredProducts.map((product, idx) => {
                  const colors = ['bg-rose-600', 'bg-blue-600', 'bg-emerald-600', 'bg-amber-600', 'bg-purple-600', 'bg-cyan-600'];
                  const hasOptions = (product.variants && product.variants.length > 0) || (product.units && product.units.length > 0);
                  const minStock = product.minStock !== undefined ? product.minStock : 10;
                  const isOutOfStock = (product.stock ?? 0) <= 0;
                  const isLowStock = !isOutOfStock && (product.stock ?? 0) <= minStock;

                  return (
                    <button 
                      key={product.id} 
                      onClick={() => addToCart(product)} 
                      className={`${product.image ? 'bg-slate-900' : colors[idx % colors.length]} rounded-2xl shadow-sm hover:shadow-xl hover:-translate-y-1 active:scale-95 transition-all p-2.5 flex flex-col items-center justify-between text-center text-white relative group cursor-pointer overflow-hidden ${
                        isOutOfStock 
                          ? 'border-2 border-rose-400 ring-2 ring-rose-500 shadow-lg shadow-rose-500/25 saturate-75' 
                          : isLowStock 
                          ? 'border-2 border-amber-300 ring-2 ring-amber-400 shadow-lg shadow-amber-500/30' 
                          : 'border border-white/20 hover:border-white/50'
                      }`}
                      title={
                        isOutOfStock
                          ? `نفذ المخزون! (المخزون الحالي: 0 - الحد الأدنى للتنبيه: ${minStock})`
                          : isLowStock
                          ? `⚠️ تنبيه: مخزون منخفض! (متبقي: ${product.stock} - الحد الأدنى: ${minStock})`
                          : `${product.nameAr} - المخزون: ${product.stock}`
                      }
                    >
                      {/* خلفية صورة الصنف الاحترافية إن وجدت */}
                      {product.image && (
                        <>
                          <img 
                            src={product.image} 
                            alt={product.nameAr}
                            className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 opacity-90"
                            referrerPolicy="no-referrer"
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/55 to-black/40 group-hover:from-black/90 transition-colors"></div>
                        </>
                      )}

                      {/* حاوية الشارات العلوية (الأصناف المتعددة + تنبيه المخزون المنخفض) */}
                      <div className="w-full flex items-center justify-between pointer-events-none z-20">
                        {/* اليمين: شارة خيارات وتعبئات الصنف أو باقة كومبو */}
                        <div>
                          {product.isBundle ? (
                            <div className="bg-purple-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-sm flex items-center gap-0.5">
                              <Boxes className="w-2.5 h-2.5" />
                              <span>كومبو</span>
                            </div>
                          ) : hasOptions ? (
                            <div className="bg-white text-slate-900 text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-sm flex items-center gap-0.5">
                              <Layers className="w-2.5 h-2.5 text-cyan-600"/>
                              <span>{product.units?.length || product.variants?.length} تعبئات</span>
                            </div>
                          ) : null}
                        </div>

                        {/* اليسار: أيقونة التحذير وشارة المخزون المنخفض أو النافد */}
                        <div>
                          {isOutOfStock ? (
                            <div className="bg-rose-600 text-white text-[9.5px] font-black px-1.5 py-0.5 rounded-md shadow-md flex items-center gap-1 border border-white/30 animate-pulse">
                              <AlertCircle className="w-3 h-3 text-white shrink-0" />
                              <span>نافد</span>
                            </div>
                          ) : isLowStock ? (
                            <div className="bg-amber-400 text-slate-950 text-[9.5px] font-black px-1.5 py-0.5 rounded-md shadow-md flex items-center gap-1 border border-amber-200">
                              <AlertTriangle className="w-3 h-3 text-slate-950 fill-current shrink-0 animate-bounce" />
                              <span className="font-mono">{product.stock} فقط</span>
                            </div>
                          ) : null}
                        </div>
                      </div>

                      {/* اسم الصنف */}
                      <span className="font-bold text-xs sm:text-sm leading-tight drop-shadow-md z-10 line-clamp-2 px-0.5">
                        {product.nameAr}
                      </span>

                      {/* شريط السعر والكمية المتبقية */}
                      <div className="flex items-center justify-center gap-1.5 z-10 w-full mt-1">
                        <span className="font-mono font-black text-xs bg-black/40 px-2 py-0.5 rounded-lg border border-white/20 backdrop-blur-xs shadow-xs inline-flex items-center gap-1">
                          <span>{product.price.toFixed(2)}</span>
                          <SaudiRiyalSymbol className="w-2.5 h-2.5 text-slate-200" />
                        </span>
                        <span className={`text-[8.5px] font-mono font-bold px-1.5 py-0.5 rounded-md ${
                          isOutOfStock 
                            ? 'bg-rose-950/90 text-rose-200 border border-rose-400/40' 
                            : isLowStock 
                            ? 'bg-amber-500 text-slate-950 font-black border border-amber-300' 
                            : 'bg-black/25 text-white/90 border border-white/10'
                        }`}>
                          {product.stock} ق
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
        {selectedProductForOptions && (
          <div className="absolute inset-0 bg-slate-950/75 backdrop-blur-md z-40 flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 text-right animate-in zoom-in-95 duration-200">
              
              {/* Header */}
              <div className="bg-slate-50 dark:bg-slate-950 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-start gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-500 dark:text-cyan-400 shrink-0 shadow-xs overflow-hidden">
                    {selectedProductForOptions.image ? (
                      <img 
                        src={selectedProductForOptions.image} 
                        alt={selectedProductForOptions.nameAr}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <Boxes className="w-6 h-6" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-lg text-slate-900 dark:text-white leading-tight">
                        {selectedProductForOptions.nameAr}
                      </h3>
                      {selectedProductForOptions.categoryAr && (
                        <span className="text-[10px] font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-full">
                          {selectedProductForOptions.categoryAr}
                        </span>
                      )}
                    </div>
                    <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5 font-medium">
                      اختر التعبئة أو المقاس / الحجم المطلوب لإضافته للفاتورة مباشرة
                    </p>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedProductForOptions(null)} 
                  className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition cursor-pointer"
                  title="إغلاق"
                >
                  <X className="w-5 h-5"/>
                </button>
              </div>

              {/* Sub-bar showing base price & info */}
              <div className="bg-slate-100/70 dark:bg-slate-800/40 px-5 py-2.5 border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-cyan-500" />
                  <span>السعر الأساسي للصنف:</span>
                  <span className="font-mono font-black text-slate-900 dark:text-white inline-flex items-center gap-1">
                    {selectedProductForOptions.price.toFixed(2)}
                    <SaudiRiyalSymbol className="w-3 h-3 text-slate-500" />
                  </span>
                </span>

                {selectedProductForOptions.barcode && (
                  <span className="text-[11px] font-mono text-slate-400">
                    الباركود: {selectedProductForOptions.barcode}
                  </span>
                )}
              </div>

              {/* Options Grid */}
              <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[55vh] overflow-y-auto">
                
                {/* Base Product Option (when units are configured and none is base) */}
                {selectedProductForOptions.units && selectedProductForOptions.units.length > 0 && !selectedProductForOptions.units.some(u => u.price === selectedProductForOptions.price && (u.factor === 1 || !u.factor)) && (
                  <button 
                    onClick={() => addToCart(selectedProductForOptions, { 
                      id: 'base', 
                      name: 'حبة فردي (الأساسي)', 
                      price: selectedProductForOptions.price,
                      unitType: 'unit',
                      factor: 1
                    })} 
                    className="p-4 bg-white dark:bg-slate-800/90 border-2 border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-400 rounded-2xl flex flex-col justify-between gap-3 group transition-all text-right hover:shadow-lg cursor-pointer"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                          <Package className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="font-black text-sm text-slate-800 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors block">
                            حبة فردي (الأساسي)
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            الوحدة الافتراضية • 1 قطعة
                          </span>
                        </div>
                      </div>
                      <span className="text-[9.5px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-full">
                        أساسي
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80">
                      <span className="text-[10px] text-slate-400 font-bold">السعر:</span>
                      <span className="font-mono font-black text-base text-emerald-600 dark:text-emerald-400 inline-flex items-center gap-1">
                        <span>{selectedProductForOptions.price.toFixed(2)}</span>
                        <SaudiRiyalSymbol className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      </span>
                    </div>
                  </button>
                )}

                {/* Units List */}
                {selectedProductForOptions.units?.map(unit => {
                  const getUnitIconAndBadge = () => {
                    const t = unit.unitType || '';
                    const n = unit.name.toLowerCase();
                    if (t === 'size' || n.includes('صغير') || n.includes('وسط') || n.includes('كبير') || n.includes('مقاس') || n.includes('سنجل') || n.includes('دبل')) {
                      return { icon: <Ruler className="w-4 h-4 text-blue-500" />, badge: 'مقاس', color: 'blue' };
                    }
                    if (t === 'volume' || n.includes('مل') || n.includes('لتر') || n.includes('سعة') || n.includes('كوب') || n.includes('جالون')) {
                      return { icon: <Maximize2 className="w-4 h-4 text-emerald-500" />, badge: 'حجم / سعة', color: 'emerald' };
                    }
                    if (t === 'pack' || n.includes('كرتون') || n.includes('شدة') || n.includes('علبة') || n.includes('باكت') || n.includes('صندوق')) {
                      return { icon: <Boxes className="w-4 h-4 text-purple-500" />, badge: 'عبوة / كرتون', color: 'purple' };
                    }
                    if (t === 'weight' || n.includes('كيلو') || n.includes('جم') || n.includes('وزن')) {
                      return { icon: <Sliders className="w-4 h-4 text-amber-500" />, badge: 'وزن', color: 'amber' };
                    }
                    return { icon: <Package className="w-4 h-4 text-cyan-500" />, badge: 'تعبئة', color: 'cyan' };
                  };

                  const meta = getUnitIconAndBadge();
                  const priceDiff = unit.price - selectedProductForOptions.price;

                  return (
                    <button 
                      key={unit.id} 
                      onClick={() => addToCart(selectedProductForOptions, { 
                        id: unit.id, 
                        name: unit.name, 
                        price: unit.price,
                        unitType: unit.unitType,
                        factor: unit.factor
                      })} 
                      className="p-4 bg-white dark:bg-slate-800/90 border-2 border-slate-200 dark:border-slate-700 hover:border-cyan-500 dark:hover:border-cyan-400 rounded-2xl flex flex-col justify-between gap-3 group transition-all text-right hover:shadow-lg cursor-pointer"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-700/60 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                            {meta.icon}
                          </div>
                          <div>
                            <span className="font-black text-sm text-slate-800 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors block">
                              {unit.name}
                            </span>
                            {unit.factor && unit.factor > 1 && (
                              <span className="text-[10px] text-slate-400 font-medium">
                                تحتوي على {unit.factor} قطعة
                              </span>
                            )}
                          </div>
                        </div>

                        <span className="text-[9.5px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full shrink-0">
                          {meta.badge}
                        </span>
                      </div>

                      {unit.barcode && (
                        <div className="text-[10px] font-mono text-slate-400 bg-slate-50 dark:bg-slate-900/50 px-2 py-0.5 rounded-md inline-block self-start">
                          باركود: {unit.barcode}
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80">
                        {/* Price Difference Indicator */}
                        <div>
                          {priceDiff > 0 ? (
                            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 font-mono">
                              +{priceDiff.toFixed(2)} ﷼
                            </span>
                          ) : priceDiff < 0 ? (
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                              -{Math.abs(priceDiff).toFixed(2)} ﷼
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400">
                              السعر الأساسي
                            </span>
                          )}
                        </div>

                        {/* Price */}
                        <span className="font-mono font-black text-base text-cyan-600 dark:text-cyan-400 inline-flex items-center gap-1">
                          <span>{unit.price.toFixed(2)}</span>
                          <SaudiRiyalSymbol className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                        </span>
                      </div>
                    </button>
                  );
                })}

                {/* Variants List (fallback if no units configured) */}
                {(!selectedProductForOptions.units || selectedProductForOptions.units.length === 0) && selectedProductForOptions.variants?.map(variant => {
                  const priceDiff = variant.price - selectedProductForOptions.price;

                  return (
                    <button 
                      key={variant.id} 
                      onClick={() => addToCart(selectedProductForOptions, { 
                        id: variant.id, 
                        name: variant.name, 
                        price: variant.price,
                        unitType: 'size'
                      })} 
                      className="p-4 bg-white dark:bg-slate-800/90 border-2 border-slate-200 dark:border-slate-700 hover:border-cyan-500 dark:hover:border-cyan-400 rounded-2xl flex flex-col justify-between gap-3 group transition-all text-right hover:shadow-lg cursor-pointer"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                            <Ruler className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="font-black text-sm text-slate-800 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors block">
                              {variant.name}
                            </span>
                            <span className="text-[10px] text-slate-400 font-medium">
                              خيار / مقاس الصنف
                            </span>
                          </div>
                        </div>

                        <span className="text-[9.5px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full shrink-0">
                          مقاس
                        </span>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80">
                        <div>
                          {priceDiff > 0 ? (
                            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 font-mono">
                              +{priceDiff.toFixed(2)} ﷼
                            </span>
                          ) : priceDiff < 0 ? (
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                              -{Math.abs(priceDiff).toFixed(2)} ﷼
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400">
                              السعر الأساسي
                            </span>
                          )}
                        </div>

                        <span className="font-mono font-black text-base text-cyan-600 dark:text-cyan-400 inline-flex items-center gap-1">
                          <span>{variant.price.toFixed(2)}</span>
                          <SaudiRiyalSymbol className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                        </span>
                      </div>
                    </button>
                  );
                })}

              </div>

              {/* Footer Tip */}
              <div className="bg-slate-50 dark:bg-slate-950 px-5 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>يمكن مسح باركود التعبئة مباشرة بالماسح لإدراجها فوراً دون فتح النافذة.</span>
                </span>

                <button
                  type="button"
                  onClick={() => setSelectedProductForOptions(null)}
                  className="px-3 py-1 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-lg transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>

            </div>
          </div>
        )}

        {/* Modal: واجهة تطبيق الخصم على الفاتورة (مبلغ مالي ثابت أو نسبة مئوية) */}
        <DiscountModal
          isOpen={isDiscountModalOpen}
          onClose={() => setIsDiscountModalOpen(false)}
          rawSubtotal={rawSubtotal}
          taxRatePercent={companySettings.taxRate ?? 15}
          initialType={discountType}
          initialValue={discountValue}
          initialScope={discountScope}
          onApplyDiscount={(type, val, scope) => {
            setDiscountType(type);
            setDiscountValue(val);
            setDiscountScope(scope);
            if (val > 0) {
              triggerPrintNotification(
                type === 'fixed'
                  ? `تم تطبيق خصم بقيمة مالية ثابتة ${val} ﷼ ${scope === 'total' ? 'على إجمالي الفاتورة' : 'قبل الضريبة'}`
                  : `تم تطبيق خصم ${val}% على الفاتورة`
              );
            }
          }}
          onClearDiscount={() => {
            setDiscountValue(0);
            triggerPrintNotification('تم إلغاء وتصفير خصم الفاتورة');
          }}
        />

        {/* Modal 1: تعليق وحفظ الطلب الحالي (Park Order Modal) */}
        {isParkModalOpen && (
          <div 
            className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in"
            onClick={(e) => {
              if (e.target === e.currentTarget) setIsParkModalOpen(false);
            }}
          >
            <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-700">
              <div className="bg-amber-500 text-slate-950 p-4 flex justify-between items-center">
                <div className="flex items-center gap-2 font-black text-base">
                  <PauseCircle className="w-5 h-5" />
                  <span>تعليق وحفظ الطلب مؤقتاً (Park Order)</span>
                </div>
                <button 
                  type="button"
                  onClick={() => setIsParkModalOpen(false)}
                  className="p-1 hover:bg-black/10 rounded-lg transition cursor-pointer"
                  title="إغلاق النافذة"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleConfirmParkOrder} className="p-5 space-y-4">
                {/* Summary Info Box */}
                <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold space-y-1.5">
                  <div className="flex justify-between text-slate-500 dark:text-slate-400">
                    <span>عدد أصناف السلة:</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200">{cart.length} أصناف ({cart.reduce((s, i) => s + i.qty, 0)} قطعة)</span>
                  </div>
                  <div className="flex justify-between text-slate-500 dark:text-slate-400">
                    <span>الإجمالي المستحق:</span>
                    <span className="font-mono font-black text-cyan-600 dark:text-cyan-400 text-sm inline-flex items-center gap-1">{calculatedTotal.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 inline-block align-middle" /></span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-amber-600 dark:text-amber-400">
                      <span>الخصم المطبق:</span>
                      <span className="font-mono font-bold">- {discountAmount.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /> ({discountType === 'percent' ? `${cleanDiscountVal}%` : 'ثابت'})</span>
                    </div>
                  )}
                </div>

                {/* Input: Label */}
                <div>
                  <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-1">
                    عنوان أو مسمى الطلب المعلق
                  </label>
                  <input
                    type="text"
                    value={parkOrderLabel}
                    onChange={(e) => setParkOrderLabel(e.target.value)}
                    placeholder="مثال: طلب معلق #2، طاولة 5، طلب سيارة"
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                    autoFocus
                  />
                </div>

                {/* Input: Customer Name or Table */}
                <div>
                  <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-1">
                    اسم العميل أو رقم الطاولة (اختياري)
                  </label>
                  <input
                    type="text"
                    value={parkOrderCustomer}
                    onChange={(e) => setParkOrderCustomer(e.target.value)}
                    placeholder="مثال: خالد العتيبي / سفري / سيارة 3"
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Input: Note */}
                <div>
                  <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-1">
                    ملاحظة على الطلب (اختياري)
                  </label>
                  <input
                    type="text"
                    value={parkOrderNote}
                    onChange={(e) => setParkOrderNote(e.target.value)}
                    placeholder="مثال: العميل سيعود بعد 5 دقائق لإكمال الشراء"
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Input: Expected Return / Delivery Time & Due Date */}
                <div className="bg-amber-500/5 dark:bg-slate-900/60 p-3 rounded-xl border border-amber-500/20 dark:border-slate-700 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-500" />
                      <span>موعد العودة أو الاستلام المتوقع (Due Date / Pickup Time)</span>
                    </label>
                    {(parkOrderDueTime || parkOrderDueDate) && (
                      <button
                        type="button"
                        onClick={clearParkDue}
                        className="text-[11px] text-rose-500 hover:text-rose-600 font-bold transition cursor-pointer"
                      >
                        مسح الموعد
                      </button>
                    )}
                  </div>

                  {/* Quick Preset Buttons for Cashier */}
                  <div className="flex flex-wrap gap-1.5 items-center">
                    <span className="text-[10px] text-slate-400 font-bold ml-1">اختيار سريع:</span>
                    {[
                      { label: '+10 دقائق', mins: 10 },
                      { label: '+15 دقيقة', mins: 15 },
                      { label: '+30 دقيقة', mins: 30 },
                      { label: '+1 ساعة', mins: 60 },
                      { label: '+2 ساعة', mins: 120 },
                    ].map((preset) => (
                      <button
                        key={preset.mins}
                        type="button"
                        onClick={() => applyQuickDueMinutes(preset.mins)}
                        className="text-[11px] font-bold px-2 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/30 transition cursor-pointer active:scale-95"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>

                  {/* Date and Time Inputs */}
                  <div className="grid grid-cols-2 gap-2 pt-0.5">
                    <div>
                      <span className="block text-[11px] text-slate-600 dark:text-slate-400 font-bold mb-1">
                        تاريخ الاستلام (Due Date):
                      </span>
                      <input
                        type="date"
                        value={parkOrderDueDate}
                        onChange={(e) => setParkOrderDueDate(e.target.value)}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-600 dark:text-slate-400 font-bold mb-1">
                        وقت العودة (Pickup Time):
                      </span>
                      <input
                        type="time"
                        value={parkOrderDueTime}
                        onChange={(e) => setParkOrderDueTime(e.target.value)}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  {parkOrderDueTime && (
                    <div className="text-[11px] text-amber-800 dark:text-amber-300 font-bold bg-amber-500/15 px-2.5 py-1.5 rounded-lg border border-amber-500/30 flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-amber-500" />
                        <span>الموعد المحدد للعودة:</span>
                      </span>
                      <span className="font-mono font-black">{formatDueDateTime(parkOrderDueDate, parkOrderDueTime)}</span>
                    </div>
                  )}
                </div>

                <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-amber-500/10 border border-amber-500/20 p-2.5 rounded-xl">
                  💡 سيتم تفريغ السلة الحالية والبدء في طلب جديد للعميل التالي، ويمكنك استرجاع هذا الطلب لاحقاً بنقرة زر واحدة.
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 pt-2">
                  <button
                    type="button"
                    onClick={() => handleQuickParkOrder()}
                    className="w-full py-2.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-900 dark:text-amber-200 border border-amber-500/30 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                    title="تعليق الطلب مباشرة بالبيانات الافتراضية بدون ملء الحقول"
                  >
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>تعليق فوري وسريع (بدون تفاصيل إضافية)</span>
                  </button>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={(e) => handleConfirmParkOrder(e)}
                      className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-amber-500/20 active:scale-95"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>تأكيد وحفظ الطلب المعلق</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsParkModalOpen(false)}
                      className="px-4 py-3 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-sm transition cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal 2: إدارة واسترجاع الطلبات المعلقة (Parked Orders List) */}
        {isParkedOrdersModalOpen && (
          <div 
            className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in"
            onClick={(e) => {
              if (e.target === e.currentTarget) setIsParkedOrdersModalOpen(false);
            }}
          >
            <div className="bg-white dark:bg-slate-800 w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-700 flex flex-col max-h-[90vh]">
              {/* Header */}
              <div className="bg-slate-900 dark:bg-black text-white p-4 flex justify-between items-center border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-black text-base">الطلبات المعلقة (Parked Orders)</h3>
                      <span className="bg-amber-500 text-slate-950 text-xs font-black font-mono px-2 py-0.5 rounded-full">
                        {parkedOrders.length} طلبات
                      </span>
                      {overdueParkedOrdersCount > 0 && (
                        <span className="bg-rose-500 text-white text-[11px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                          <AlertCircle className="w-3 h-3" />
                          <span>{overdueParkedOrdersCount} طلب متأخر عن الموعد!</span>
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">استرجاع سلة المشتريات المعلقة للكاشير أو متابعة مواعيد عودة العملاء</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => setIsParkedOrdersModalOpen(false)}
                  className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body */}
              <div className="p-4 overflow-y-auto flex-1 space-y-3">
                {parkedOrders.length === 0 ? (
                  <div className="py-14 text-center space-y-3">
                    <div className="w-16 h-16 mx-auto bg-slate-100 dark:bg-slate-900 text-slate-400 rounded-2xl flex items-center justify-center">
                      <Clock className="w-8 h-8 opacity-60" />
                    </div>
                    <h4 className="font-black text-slate-700 dark:text-slate-300 text-base">لا توجد أي طلبات معلقة حالياً</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                      يمكنك تعليق أي طلب نشط في السلة بالضغط على زر <span className="font-bold text-amber-500">"تعليق الطلب (Park)"</span> عند رغبة العميل بالانتظار أو إحضار سلع أخرى.
                    </p>
                  </div>
                ) : (
                  parkedOrders.map((order) => (
                    <div 
                      key={order.id}
                      className="bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4 transition-all hover:border-amber-500/40 shadow-sm"
                    >
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-200/80 dark:border-slate-800 pb-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center font-mono font-black text-xs">
                            #{order.orderNumber}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="font-black text-sm text-slate-900 dark:text-white">{order.label}</h4>
                              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded">
                                تعليق: {order.createdAt}
                              </span>
                              {(order.dueTime || order.dueDate) && (() => {
                                const dueStatus = getDueStatus(order.dueDate, order.dueTime);
                                const formattedDue = formatDueDateTime(order.dueDate, order.dueTime);
                                
                                if (dueStatus.status === 'overdue') {
                                  return (
                                    <span className="text-[11px] font-black text-rose-600 dark:text-rose-400 bg-rose-500/15 border border-rose-500/30 px-2 py-0.5 rounded-md flex items-center gap-1 animate-pulse">
                                      <AlertCircle className="w-3 h-3 text-rose-500" />
                                      <span>العودة المتوقعة: <strong className="font-mono">{formattedDue}</strong></span>
                                      <span className="text-[9px] bg-rose-500 text-white px-1.5 py-0.2 rounded font-mono font-black">({dueStatus.text})</span>
                                    </span>
                                  );
                                } else if (dueStatus.status === 'soon') {
                                  return (
                                    <span className="text-[11px] font-black text-amber-700 dark:text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                                      <Clock className="w-3 h-3 text-amber-500" />
                                      <span>العودة المتوقعة: <strong className="font-mono">{formattedDue}</strong></span>
                                      <span className="text-[9px] bg-amber-500 text-slate-950 px-1.5 py-0.2 rounded font-mono font-black">({dueStatus.text})</span>
                                    </span>
                                  );
                                } else {
                                  return (
                                    <span className="text-[11px] font-bold text-cyan-700 dark:text-cyan-400 bg-cyan-500/15 border border-cyan-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                                      <Calendar className="w-3 h-3 text-cyan-500" />
                                      <span>العودة المتوقعة: <strong className="font-mono">{formattedDue}</strong></span>
                                    </span>
                                  );
                                }
                              })()}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                              <span>العميل: <strong className="text-slate-700 dark:text-slate-300">{order.customerName || 'نقدي'}</strong></span>
                              {order.note && (
                                <span className="text-amber-600 dark:text-amber-400 font-semibold">• {order.note}</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Pricing & Item Count */}
                        <div className="text-left font-mono" dir="ltr">
                          <span className="text-base font-black text-cyan-600 dark:text-cyan-400 block">
                            {order.total.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 text-cyan-400 inline-block align-middle" />
                          </span>
                          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-sans block">
                            {order.items.length} أصناف ({order.items.reduce((s, i) => s + i.qty, 0)} قطعة)
                            {order.discountAmount > 0 && (
                              <span className="text-amber-500 font-bold mr-1">
                                (خصم {order.discountType === 'percent' ? `${order.discountValue}%` : `${order.discountAmount.toFixed(2)} ﷼`})
                              </span>
                            )}
                          </span>
                        </div>
                      </div>

                      {/* Items Preview Chips */}
                      <div className="py-2.5 flex flex-wrap gap-1.5 items-center">
                        {order.items.slice(0, 4).map((it, idx) => (
                          <span 
                            key={idx}
                            className="text-[11px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2.5 py-1 rounded-lg text-slate-700 dark:text-slate-300 font-medium"
                          >
                            {it.name} <span className="font-mono font-bold text-cyan-600 dark:text-cyan-400">×{it.qty}</span>
                          </span>
                        ))}
                        {order.items.length > 4 && (
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold bg-slate-200/60 dark:bg-slate-800 px-2 py-1 rounded-lg">
                            +{order.items.length - 4} أصناف أخرى
                          </span>
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => handleRequestRestore(order)}
                          className="flex-1 py-2.5 bg-gradient-to-l from-emerald-500 to-green-600 hover:from-emerald-600 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition active:scale-95"
                        >
                          <RotateCcw className="w-4 h-4" />
                          <span>استرجاع الطلب إلى السلة الحالية</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setPreviewParkedOrder(order)}
                          className="px-3.5 py-2.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition border border-slate-300 dark:border-slate-700"
                          title="معاينة تفاصيل الأصناف"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>معاينة</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteParkedOrder(order.id)}
                          className="px-3.5 py-2.5 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition border border-rose-200 dark:border-rose-900/50"
                          title="حذف هذا الطلب المعلق نهائياً"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Footer */}
              <div className="p-3 bg-slate-100 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                <span className="text-slate-500">
                  إجمالي الطلبات المعلقة: <strong className="text-slate-900 dark:text-white font-mono">{parkedOrders.length}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setIsParkedOrdersModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-200 hover:bg-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  إغلاق النافذة
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal 3: تأكيد استرجاع الطلب عند وجود سلة نشطة */}
        {orderToRestore && (
          <div 
            className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-in fade-in"
            onClick={(e) => {
              if (e.target === e.currentTarget) setOrderToRestore(null);
            }}
          >
            <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl p-6 border border-slate-200 dark:border-slate-700 space-y-4 text-right">
              <div className="flex items-center gap-3 text-amber-500">
                <div className="p-3 bg-amber-500/20 rounded-xl">
                  <AlertCircle className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900 dark:text-white">السلة الحالية غير فارغة!</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">توجد أصناف مسبقة في سلة المبيعات</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 font-bold">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>السلة الحالية:</span>
                  <span className="font-mono text-slate-900 dark:text-white">{cart.length} أصناف ({calculatedTotal.toFixed(2)} ﷼)</span>
                </div>
                <div className="flex justify-between text-amber-600 dark:text-amber-400">
                  <span>الطلب المراد استرجاعه:</span>
                  <span className="font-mono text-amber-600 dark:text-amber-400">{orderToRestore.label} ({orderToRestore.total.toFixed(2)} ﷼)</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 font-bold">
                كيف ترغب في معالجة السلة الحالية مع الطلب المعلق المسترجع؟
              </p>

              <div className="flex flex-col gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => executeRestore(orderToRestore, 'replace')}
                  className="py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>استبدال السلة الحالية بالطلب المسترجع بالكامل</span>
                </button>

                <button
                  type="button"
                  onClick={() => executeRestore(orderToRestore, 'merge')}
                  className="py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>دمج أصناف الطلبين معاً في سلة واحدة</span>
                </button>

                <button
                  type="button"
                  onClick={() => setOrderToRestore(null)}
                  className="py-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 text-xs font-bold transition cursor-pointer"
                >
                  إلغاء الاسترجاع والاحتفاظ بالسلة الحالية
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal 4: تفاصيل ومعاينة الطلب المعلق */}
        {previewParkedOrder && (
          <div 
            className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-in fade-in"
            onClick={(e) => {
              if (e.target === e.currentTarget) setPreviewParkedOrder(null);
            }}
          >
            <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-700 flex flex-col max-h-[85vh]">
              <div className="bg-slate-900 text-white p-4 flex justify-between items-center border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Eye className="w-5 h-5 text-cyan-400" />
                  <h4 className="font-black text-sm">تفاصيل: {previewParkedOrder.label}</h4>
                </div>
                <button 
                  type="button"
                  onClick={() => setPreviewParkedOrder(null)}
                  className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 overflow-y-auto flex-1 space-y-3">
                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 font-bold">
                  <div>العميل: <strong className="text-slate-800 dark:text-slate-200">{previewParkedOrder.customerName || 'نقدي'}</strong></div>
                  <div>وقت التعليق: <span className="font-mono text-slate-800 dark:text-slate-200">{previewParkedOrder.createdAt}</span></div>
                  {(previewParkedOrder.dueTime || previewParkedOrder.dueDate) && (
                    <div className="col-span-2 flex items-center justify-between text-amber-700 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1.5 rounded-lg flex-wrap gap-1">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-500" />
                        <span>موعد العودة / الاستلام المتوقع:</span>
                        <strong className="font-mono font-black">{formatDueDateTime(previewParkedOrder.dueDate, previewParkedOrder.dueTime)}</strong>
                      </div>
                      {(() => {
                        const st = getDueStatus(previewParkedOrder.dueDate, previewParkedOrder.dueTime);
                        if (st.status === 'overdue') {
                          return <span className="text-[10px] bg-rose-500 text-white font-mono px-1.5 py-0.5 rounded font-black animate-pulse">{st.text}</span>;
                        } else if (st.status === 'soon') {
                          return <span className="text-[10px] bg-amber-500 text-slate-950 font-mono px-1.5 py-0.5 rounded font-black">{st.text}</span>;
                        }
                        return null;
                      })()}
                    </div>
                  )}
                  {previewParkedOrder.note && (
                    <div className="col-span-2 text-amber-600 dark:text-amber-400">ملاحظة: {previewParkedOrder.note}</div>
                  )}
                </div>

                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden text-xs">
                  <div className="grid grid-cols-12 gap-1 bg-slate-100 dark:bg-slate-900 p-2 font-black text-slate-600 dark:text-slate-400 text-center">
                    <div className="col-span-6 text-right pr-2">الصنف</div>
                    <div className="col-span-2">السعر</div>
                    <div className="col-span-2">الكمية</div>
                    <div className="col-span-2">المجموع</div>
                  </div>
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 font-bold">
                    {previewParkedOrder.items.map((it, idx) => (
                      <div key={idx} className="grid grid-cols-12 gap-1 p-2 text-center text-slate-800 dark:text-slate-200 items-center">
                        <div className="col-span-6 text-right pr-2">{it.name}</div>
                        <div className="col-span-2 font-mono">{it.price.toFixed(2)}</div>
                        <div className="col-span-2 font-mono">{it.qty}</div>
                        <div className="col-span-2 font-mono font-black">{it.total.toFixed(2)}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1 text-xs font-bold">
                  <div className="flex justify-between">
                    <span>المجموع قبل الخصم:</span>
                    <span className="font-mono inline-flex items-center gap-1">{previewParkedOrder.rawSubtotal.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span>
                  </div>
                  {previewParkedOrder.discountAmount > 0 && (
                    <div className="flex justify-between text-amber-500">
                      <span>الخصم ({previewParkedOrder.discountType === 'percent' ? `${previewParkedOrder.discountValue}%` : 'مبلغ ثابت'}):</span>
                      <span className="font-mono font-black inline-flex items-center gap-1">- {previewParkedOrder.discountAmount.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span>
                    </div>
                  )}
                  <div className="flex justify-between text-rose-500">
                    <span>الضريبة (15%):</span>
                    <span className="font-mono inline-flex items-center gap-1">{previewParkedOrder.tax.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 text-rose-400 inline-block align-middle" /></span>
                  </div>
                  <div className="flex justify-between text-sm font-black pt-1 border-t border-slate-200 dark:border-slate-700 text-cyan-600 dark:text-cyan-400">
                    <span>الإجمالي المستحق:</span>
                    <span className="font-mono inline-flex items-center gap-1">{previewParkedOrder.total.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 text-cyan-400 inline-block align-middle" /></span>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-100 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const ord = previewParkedOrder;
                    setPreviewParkedOrder(null);
                    handleRequestRestore(ord);
                  }}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>استرجاع هذا الطلب الآن</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewParkedOrder(null)}
                  className="px-4 py-2.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: تنبيه استرجاع الباقي للعميل (Cash Change Due) */}
        {lastCashChange && (
          <div 
            className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm z-[70] flex items-center justify-center p-4 animate-in fade-in zoom-in-95"
            onClick={(e) => {
              if (e.target === e.currentTarget) setLastCashChange(null);
            }}
          >
            <div className="bg-white dark:bg-slate-800 border-2 border-emerald-500 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 text-center text-slate-800 dark:text-white relative overflow-hidden" dir="rtl">
              {/* Top Accent Strip */}
              <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-emerald-400 via-teal-500 to-cyan-500" />
              
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2.5 text-right">
                  <div className="p-2.5 bg-emerald-500/15 text-emerald-500 rounded-2xl shadow-inner">
                    <Zap className="w-6 h-6 fill-current" />
                  </div>
                  <div>
                    <h3 className="font-black text-base text-slate-900 dark:text-white">
                      {lastCashChange.isQuickPay ? 'تم الدفع السريع بنجاح (Quick Pay)' : 'تم إتمام الدفع النقدي'}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                      فاتورة: #{lastCashChange.invoiceNumber} • {lastCashChange.timestamp}
                    </p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => setLastCashChange(null)}
                  className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl cursor-pointer transition"
                  title="إغلاق"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Big Prominent Cash Change Box */}
              <div className="bg-gradient-to-b from-emerald-50 to-emerald-100/50 dark:from-emerald-950/60 dark:to-emerald-900/40 border-2 border-emerald-500/60 rounded-2xl p-5 shadow-inner">
                <div className="text-xs font-black text-emerald-800 dark:text-emerald-300 mb-1 flex items-center justify-center gap-1.5">
                  <Coins className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>المبلغ المتبقي للعميل (الباقي)</span>
                </div>
                <div className="text-4xl sm:text-5xl font-black font-mono text-emerald-600 dark:text-emerald-400 tracking-tight my-1 inline-flex items-center justify-center gap-2">
                  <span>{lastCashChange.changeAmount.toFixed(2)}</span>
                  <SaudiRiyalSymbol className="w-8 h-8 text-emerald-600 dark:text-emerald-400" />
                </div>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-300 font-bold mt-1">
                  {lastCashChange.changeAmount > 0 ? '👈 يرجى تسليم هذا الباقي للعميل فوراً' : '✨ تم استلام المبلغ بالضبط - لا يوجد باقي'}
                </p>
              </div>

              {/* Summary breakdown: Total vs Paid */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-right">
                  <span className="text-slate-500 dark:text-slate-400 block mb-0.5 text-[11px]">إجمالي الفاتورة:</span>
                  <span className="font-mono text-base font-black text-slate-800 dark:text-slate-200 inline-flex items-center gap-1">
                    {lastCashChange.total.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 inline-block align-middle" />
                  </span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-right">
                  <span className="text-slate-500 dark:text-slate-400 block mb-0.5 text-[11px]">المبلغ المستلم كاش:</span>
                  <span className="font-mono text-base font-black text-cyan-600 dark:text-cyan-400 inline-flex items-center gap-1">
                    {lastCashChange.paidAmount.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 inline-block align-middle" />
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setLastCashChange(null)}
                  className="flex-1 py-3 bg-gradient-to-l from-emerald-500 to-teal-600 hover:from-emerald-600 text-white font-black rounded-xl text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-500/20 active:scale-95 transition"
                  autoFocus
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>تم تسليم الباقي (عميل جديد)</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderDashboardView = () => {
    switch (currentView) {
      case 'dailyReports':
        return (
          <div className="p-6 h-full flex flex-col animate-in fade-in zoom-in-95 max-w-7xl mx-auto dark:text-white">
            <div className="flex items-center justify-between mb-6 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-xl"><BarChart3 className="w-8 h-8"/></div>
                <div><h2 className="text-2xl font-black text-slate-800 dark:text-white">التقارير والإحصائيات</h2><p className="text-sm text-slate-500 dark:text-slate-400 font-semibold mt-1">تتبع أداء المبيعات، والضرائب.</p></div>
              </div>
              <div className="flex gap-2">
                 <input type="date" value={reportDateRange.from} onChange={e => setReportDateRange({...reportDateRange, from: e.target.value})} className="border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 rounded-xl px-4 py-2 font-mono text-sm outline-none" />
                 <span className="text-slate-400 mt-2">-</span>
                 <input type="date" value={reportDateRange.to} onChange={e => setReportDateRange({...reportDateRange, to: e.target.value})} className="border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 rounded-xl px-4 py-2 font-mono text-sm outline-none" />
                 <button className="bg-indigo-500 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2"><Search className="w-4 h-4"/> بحث</button>
              </div>
            </div>
            <div className="flex gap-4 mb-6">
              {[ { id: 'daily', label: 'التقرير اليومي', icon: <Calendar className="w-5 h-5"/> }, { id: 'monthly', label: 'التقرير الشهري', icon: <FileText className="w-5 h-5"/> }, { id: 'users', label: 'أداء المستخدمين', icon: <UserCircle className="w-5 h-5"/> }, { id: 'tax', label: 'الضريبة', icon: <Banknote className="w-5 h-5"/> } ].map(tab => (
                <button key={tab.id} onClick={() => setActiveReportTab(tab.id as any)} className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl font-bold transition-all border-2 ${activeReportTab === tab.id ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400' : 'border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:border-indigo-300'}`}>
                  {tab.icon} {tab.label}
                </button>
              ))}
            </div>
            <div className="flex-1 bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 p-6 overflow-y-auto">
               <h3 className="text-xl font-black mb-6 text-slate-800 dark:text-white border-b border-slate-100 dark:border-slate-700 pb-4">
                 {activeReportTab === 'daily' ? 'ملخص الحركة اليومية' : activeReportTab === 'monthly' ? 'إجمالي المبيعات الشهرية' : activeReportTab === 'users' ? 'مبيعات الكاشير والمستخدمين' : 'الإقرار الضريبي للمبيعات'}
               </h3>
               <div className="grid grid-cols-3 gap-6 mb-8">
                  <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-700"><p className="text-slate-500 dark:text-slate-400 font-bold mb-2">إجمالي المبيعات</p><p className="text-4xl font-black font-mono text-slate-800 dark:text-white"><span className="inline-flex items-center gap-2">{invoices.reduce((sum, inv) => sum + inv.total, 0).toFixed(2)} <SaudiRiyalSymbol className="w-7 h-7 text-slate-800 dark:text-white" /></span></p></div>
                  <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-700"><p className="text-slate-500 dark:text-slate-400 font-bold mb-2">إجمالي الضريبة</p><p className="text-4xl font-black font-mono text-rose-600 dark:text-rose-400"><span className="inline-flex items-center gap-2">{invoices.reduce((sum, inv) => sum + inv.tax, 0).toFixed(2)} <SaudiRiyalSymbol className="w-7 h-7 text-rose-600 dark:text-rose-400" /></span></p></div>
                  <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-700"><p className="text-slate-500 dark:text-slate-400 font-bold mb-2">عدد العمليات</p><p className="text-4xl font-black font-mono text-cyan-600 dark:text-cyan-400">{invoices.length} <span className="text-base">عملية</span></p></div>
               </div>
            </div>
          </div>
        );

      case 'dailyClosing':
        return (
          <ZReportManager 
            invoices={invoices}
            settings={companySettings}
            currentUser={users[0]}
            onPrintZReport={(record) => {
              setPrintZReportData(record);
              triggerPrintNotification(`جاري إرسال تقرير Z #${record.reportNumber} إلى طابعة الكاشير...`);
            }}
            onNotify={(msg) => triggerPrintNotification(msg)}
          />
        );

      case 'salesLog':
      case 'invoices':
        return (
          <InvoicesList 
            invoices={invoices} 
            onViewInvoice={(invoice) => setSelectedInvoiceForModal(invoice)} 
            onPrintInvoice={(invoice, currCode) => {
              setPrintInvoiceCurrency(currCode || 'SAR');
              setActivePrintTemplate('thermal80');
              triggerPrintNotification(`تم تجهيز الفاتورة ${invoice.invoiceNumber} للطباعة (${currCode || 'SAR'})`);
              setPrintInvoiceData(invoice);
            }} 
            multiCurrencySettings={companySettings.multiCurrency}
          />
        );

      case 'products':
        return (
          <ProductsManager 
            products={products}
            groups={productGroups}
            printers={printersList}
            initialTab="products"
            onAddProduct={(newProd) => setProducts(prev => [newProd, ...prev])}
            onUpdateProduct={(id, updated) => setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updated } : p))}
            onDeleteProduct={(id) => setProducts(prev => prev.filter(p => p.id !== id))}
            onAddGroup={handleAddGroup}
            onUpdateGroup={handleUpdateGroup}
            onDeleteGroup={handleDeleteGroup}
          />
        );

      case 'productGroups':
        return (
          <ProductsManager 
            products={products}
            groups={productGroups}
            printers={printersList}
            initialTab="groups"
            onAddProduct={(newProd) => setProducts(prev => [newProd, ...prev])}
            onUpdateProduct={(id, updated) => setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updated } : p))}
            onDeleteProduct={(id) => setProducts(prev => prev.filter(p => p.id !== id))}
            onAddGroup={handleAddGroup}
            onUpdateGroup={handleUpdateGroup}
            onDeleteGroup={handleDeleteGroup}
          />
        );

      case 'inventory':
        return (
          <InventoryManager 
            products={products}
            onUpdateStock={(prodId, newStock) => {
              setProducts(prev => prev.map(p => p.id === prodId ? { ...p, stock: newStock } : p));
              triggerPrintNotification('تم تحديث رصيد المخزون بنجاح');
            }}
            companySettings={companySettings}
          />
        );

      case 'customers':
        return (
          <CustomersManager 
            customers={customers}
            onAddCustomer={(newCust) => setCustomers(prev => [...prev, newCust])}
            onUpdateCustomer={(id, updated) => setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...updated } : c))}
            onDeleteCustomer={(id) => setCustomers(prev => prev.filter(c => c.id !== id))}
          />
        );

      case 'suppliers':
        return (
          <SuppliersManager 
            suppliers={suppliers}
            onAddSupplier={(newSup) => setSuppliers(prev => [...prev, newSup])}
            onUpdateSupplier={(id, updated) => setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s))}
            onDeleteSupplier={(id) => setSuppliers(prev => prev.filter(s => s.id !== id))}
          />
        );

      case 'purchases':
        return (
          <PurchasesManager 
            purchases={purchases}
            products={products}
            suppliers={suppliers}
            onAddPurchase={(newPur) => {
              setPurchases(prev => [newPur, ...prev]);
              // Auto-increment product stock!
              newPur.items.forEach(item => {
                setProducts(prevProds => prevProds.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
              });
            }}
            onDeletePurchase={(id) => setPurchases(prev => prev.filter(p => p.id !== id))}
          />
        );

      case 'users':
        return (
          <UsersManager 
            users={users}
            onAddUser={(newUser) => setUsers(prev => [...prev, newUser])}
            onUpdateUser={(id, updated) => setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updated } : u))}
            onDeleteUser={(id) => setUsers(prev => prev.filter(u => u.id !== id))}
          />
        );

      case 'settings':
        return (
          <SettingsView 
            settings={companySettings} 
            onSaveSettings={(updated) => {
              setCompanySettings(updated);
              triggerPrintNotification('تم حفظ إعدادات المنشأة بنجاح!');
            }} 
          />
        );

      case 'printers':
        return (
          <div className="p-6 h-full flex flex-col animate-in fade-in zoom-in-95 max-w-7xl mx-auto dark:text-white text-right">
            <div className="flex items-center justify-between mb-6 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-xl"><Printer className="w-8 h-8"/></div>
                <div><h2 className="text-2xl font-black text-slate-800 dark:text-white">طابعات ويندوز النشطة</h2><p className="text-sm text-slate-500 dark:text-slate-400 font-semibold mt-1">اربط طابعات نظام التشغيل للطباعة المباشرة.</p></div>
              </div>
              <button onClick={() => {
                const prName = prompt('أدخل اسم الطابعة للربط:');
                if (prName) {
                  const newPr: AppPrinter = {
                    id: `p-${Date.now()}`,
                    name: prName,
                    osPrinterName: prName,
                    type: 'cashier',
                    template: 'thermal80',
                    status: 'online'
                  };
                  setPrintersList(prev => [...prev, newPr]);
                  triggerPrintNotification(`تم ربط طابعة الويندوز ${prName} بنجاح!`);
                }
              }} className="bg-blue-500 hover:bg-blue-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2"><PlusCircle className="w-5 h-5"/> ربط طابعة جديدة</button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {printersList.map(printer => (
                <div key={printer.id} className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl"><Server className="w-8 h-8 text-blue-500" /></div>
                    <div>
                      <h3 className="font-black text-lg">{printer.name}</h3>
                      <span className="text-xs font-bold px-2.5 py-1 mt-1 bg-slate-100 dark:bg-slate-700 rounded-md text-slate-600 dark:text-slate-300">
                        {printer.type === 'kitchen' ? 'مطبخ / تحضير' : 'كاشير / إيصال'}
                      </span>
                    </div>
                  </div>
                  <div className="bg-blue-50 dark:bg-slate-900/50 p-3.5 rounded-xl flex flex-col gap-1 text-sm font-bold border border-blue-100 dark:border-slate-700 mb-4">
                    <span className="text-blue-500 dark:text-blue-400 text-xs">اسم الطابعة الحقيقي بويندوز (OS Printer Name)</span>
                    <span className="font-mono text-slate-800 dark:text-white" dir="ltr">{printer.osPrinterName}</span>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => triggerPrintNotification(`جاري طباعة ورقة اختبار على طابعة ${printer.osPrinterName}`)} className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg text-xs font-bold transition-all">طباعة اختبار</button>
                    <button onClick={() => {
                      const newOS = prompt('أدخل اسم طابعة ويندوز الحقيقي الجديد:', printer.osPrinterName);
                      if (newOS) {
                        setPrintersList(prev => prev.map(p => p.id === printer.id ? { ...p, osPrinterName: newOS } : p));
                        triggerPrintNotification('تم تحديث طابعة الويندوز بنجاح!');
                      }
                    }} className="px-3 py-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg text-xs font-bold"><Edit className="w-4 h-4"/></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'appSettings':
        return (
          <div className="p-6 h-full flex flex-col animate-in fade-in zoom-in-95 max-w-5xl mx-auto dark:text-white text-right">
            <div className="flex items-center gap-3 mb-6 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors">
              <div className="p-3 bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400 rounded-xl"><Palette className="w-8 h-8"/></div>
              <div><h2 className="text-2xl font-black text-slate-800 dark:text-white">إعدادات التطبيق والمظهر</h2></div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-100 dark:border-slate-700">
                    <div className="flex items-center gap-3">{isDarkMode ? <Moon className="w-6 h-6 text-indigo-400"/> : <Sun className="w-6 h-6 text-amber-500"/>} <p className="font-bold">الوضع الداكن</p></div>
                    <button onClick={() => setIsDarkMode(!isDarkMode)} className={`w-12 h-6 rounded-full relative ${isDarkMode ? 'bg-indigo-500' : 'bg-slate-300'}`}><div className={`w-4 h-4 bg-white rounded-full absolute top-1 ${isDarkMode ? 'left-1' : 'right-1'}`} /></button>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-100 dark:border-slate-700">
                    <div className="flex items-center gap-3"><ArrowRightLeft className="w-6 h-6 text-blue-500"/> <p className="font-bold">عكس اتجاه الشاشة (شمالي/يميني)</p></div>
                    <button onClick={() => setIsLayoutReversed(!isLayoutReversed)} className={`w-12 h-6 rounded-full relative ${isLayoutReversed ? 'bg-cyan-500' : 'bg-slate-300'}`}><div className={`w-4 h-4 bg-white rounded-full absolute top-1 ${isLayoutReversed ? 'left-1' : 'right-1'}`} /></button>
                  </div>
                </div>
              </div>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <button onClick={() => setBusinessType('restaurant')} className={`p-4 rounded-xl border-2 flex flex-col items-center justify-center gap-3 ${businessType === 'restaurant' ? 'border-cyan-500 bg-cyan-50 dark:bg-cyan-900/20 text-cyan-600' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}>
                    <Utensils className="w-8 h-8" /> <span className="font-bold">مطعم / كافيه</span>
                  </button>
                  <button onClick={() => setBusinessType('retail')} className={`p-4 rounded-xl border-2 flex flex-col items-center justify-center gap-3 ${businessType === 'retail' ? 'border-cyan-500 bg-cyan-50 dark:bg-cyan-900/20 text-cyan-600' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}>
                    <Store className="w-8 h-8" /> <span className="font-bold">تجزئة (كاشير ويندوز)</span>
                  </button>
                </div>
                {businessType === 'retail' && <p className="text-sm font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 p-3 rounded-lg border border-emerald-200">وضع كاشير التجزئة مفعل: توجيه الطباعة وقارئ الباركود النشط متاحان الآن.</p>}
              </div>
            </div>
          </div>
        );

      default:
        return (<div className="h-full flex items-center justify-center text-slate-500"><h2 className="text-2xl font-black">الواجهة: {currentView}</h2></div>);
    }
  };

  // Real browser system printing effect - keep preview open and allow stable printing
  useEffect(() => {
    if (printInvoiceData) {
      const timer = setTimeout(() => {
        try {
          window.print();
        } catch (e) {
          console.warn('System print notification:', e);
        }
      }, 450);
      return () => clearTimeout(timer);
    }
  }, [printInvoiceData]);

  // Support ESC key to safely close print previews, alerts, and parked order modals
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isDiscountModalOpen) setIsDiscountModalOpen(false);
        if (isParkModalOpen) setIsParkModalOpen(false);
        if (isParkedOrdersModalOpen) setIsParkedOrdersModalOpen(false);
        if (orderToRestore) setOrderToRestore(null);
        if (previewParkedOrder) setPreviewParkedOrder(null);
        if (lastCashChange) setLastCashChange(null);
        if (printInvoiceData) setPrintInvoiceData(null);
        if (printZReportData) setPrintZReportData(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [printInvoiceData, printZReportData, lastCashChange, isParkModalOpen, isParkedOrdersModalOpen, orderToRestore, previewParkedOrder, isDiscountModalOpen]);

  if (!isLoggedIn) {
    return (
      <div className={`font-sans ${isDarkMode ? 'dark' : ''}`}>
        <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 transition-colors" dir="rtl">
          <form onSubmit={handleLogin} className="bg-slate-800 border border-slate-700 w-full max-w-sm rounded-3xl p-8 shadow-2xl space-y-6 text-white text-right">
            <div className="flex flex-col items-center justify-center mb-8"><div className="bg-cyan-500 p-4 rounded-2xl mb-4"><ShoppingBag className="w-10 h-10" /></div><h1 className="text-2xl font-black">البدر كاشير</h1></div>
            <input type="text" placeholder="اسم المستخدم" onFocus={handleFocusSelect} className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none" defaultValue="admin" />
            <input type="password" placeholder="كلمة المرور" onFocus={handleFocusSelect} className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none" defaultValue="123" />
            <button type="submit" className="w-full py-4 bg-cyan-500 text-white font-black rounded-xl">دخول للنظام</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className={`font-sans ${isDarkMode ? 'dark' : ''}`}>
      {/* Dynamic layout container for desktop/tablet rendering */}
      <div className="print:hidden">
        {currentView === 'pos' ? renderPOS() : (
          <div className="min-h-screen bg-slate-100 dark:bg-slate-900 flex flex-col overflow-hidden transition-colors" dir="rtl">
            <TopBar onLogout={handleLogout} activeLanguage="ar" />
            <div className="flex flex-1 overflow-hidden h-[calc(100vh-4rem)]">
               <Sidebar currentView={currentView} onViewChange={(view) => setCurrentView(view as ExtendedViewType)} onLogout={handleLogout} />
               <main className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-900/50 relative p-4 transition-colors">
                 {renderDashboardView()}
               </main>
            </div>
          </div>
        )}
      </div>

      {/* Invoice Details view overlay modal */}
      {selectedInvoiceForModal && (
        <InvoiceView 
          invoice={selectedInvoiceForModal} 
          onClose={() => setSelectedInvoiceForModal(null)} 
          onPrint={(inv, currCode) => {
            setPrintInvoiceCurrency(currCode || 'SAR');
            setActivePrintTemplate('thermal80');
            setPrintInvoiceData(inv);
            triggerPrintNotification(`جاري تحويل الفاتورة ${inv.invoiceNumber} للمعاينة والطباعة (${currCode || 'SAR'})...`);
          }} 
          multiCurrencySettings={companySettings.multiCurrency}
          companySettings={companySettings}
        />
      )}

      {/* Real Windows Printer rendering container for Invoices */}
      {printInvoiceData && (
        <div 
          id="printable-invoice-container" 
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setPrintInvoiceData(null);
            }
          }}
          className="fixed inset-0 bg-black/75 backdrop-blur-sm z-[9999] overflow-y-auto p-4 sm:p-6 flex flex-col items-center justify-start print:static print:p-0 print:bg-white animate-in fade-in duration-150" 
          dir="rtl"
        >
          {/* Top Control Bar (Hidden when printing via print:hidden / no-print) */}
          <div className="no-print bg-slate-900 border border-slate-700 text-white p-3.5 rounded-2xl mb-4 max-w-[800px] w-full flex flex-wrap justify-between items-center gap-3 shadow-2xl">
            <div className="flex items-center gap-2.5 text-xs font-bold">
              <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-white font-black text-sm">
                  معاينة طباعة الفاتورة #{printInvoiceData.invoiceNumber || printInvoiceData.number}
                </span>
                <span className="text-[11px] text-slate-400">
                  متوافقة مع متطلبات هيئة الزكاة والضريبة والجمارك (ZATCA Phase 1)
                </span>
              </div>
            </div>

            {/* Template Selector & Action Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Switch between Thermal and A4 */}
              <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setActivePrintTemplate('thermal80')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                    activePrintTemplate === 'thermal80'
                      ? 'bg-cyan-500 text-slate-950 font-black shadow'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>إيصال حراري (80 مم)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActivePrintTemplate('A4')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                    activePrintTemplate === 'A4'
                      ? 'bg-cyan-500 text-slate-950 font-black shadow'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>فاتورة كاملة (A4)</span>
                </button>
              </div>

              {/* Print Now button */}
              <button 
                type="button"
                onClick={() => {
                  try {
                    window.print();
                  } catch (e) {
                    console.error('Print error:', e);
                  }
                }} 
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black rounded-xl text-xs cursor-pointer shadow-lg shadow-cyan-500/20 flex items-center gap-1.5 active:scale-95 transition"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة الآن (Print)</span>
              </button>

              {/* Close Button */}
              <button 
                type="button"
                onClick={() => setPrintInvoiceData(null)} 
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold rounded-xl text-xs cursor-pointer border border-slate-700 transition flex items-center gap-1"
                title="إغلاق المعاينة (Esc)"
              >
                <X className="w-4 h-4" />
                <span>إغلاق</span>
              </button>
            </div>
          </div>

          {/* Printable Invoice View */}
          <div className="w-full flex justify-center pb-8">
            <PrintableInvoice 
              invoice={printInvoiceData} 
              settings={companySettings} 
              printer={printersList.find(p => p.id === selectedRetailPrinterId)} 
              currencyCode={printInvoiceCurrency}
              templateOverride={activePrintTemplate}
            />
          </div>
        </div>
      )}

      {/* Real Windows Printer rendering container for Z-Report */}
      {printZReportData && (
        <div 
          id="printable-zreport-container" 
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setPrintZReportData(null);
            }
          }}
          className="fixed inset-0 bg-black/75 backdrop-blur-sm z-[9999] overflow-y-auto p-4 sm:p-6 flex flex-col items-center justify-start print:static print:p-0 print:bg-white animate-in fade-in duration-150" 
          dir="rtl"
        >
          <div className="no-print bg-slate-900 border border-slate-700 text-white p-3.5 rounded-2xl mb-4 max-w-[450px] w-full flex justify-between items-center shadow-2xl">
            <div className="flex items-center gap-2 text-xs font-bold">
              <div className="p-2 bg-rose-500/10 text-rose-400 rounded-xl">
                <Printer className="w-4 h-4" />
              </div>
              <div>
                <span className="block text-white font-black">معاينة تقرير الإقفال (Z-Report)</span>
                <span className="text-[11px] text-slate-400">معتمد برمز التدقيق والتوثيق المالي</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button 
                type="button"
                onClick={() => {
                  try {
                    window.print();
                  } catch (e) {
                    console.error('Print error:', e);
                  }
                }} 
                className="px-4 py-1.5 bg-rose-500 hover:bg-rose-400 text-white font-black rounded-lg text-xs cursor-pointer shadow flex items-center gap-1 active:scale-95 transition"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة</span>
              </button>
              <button 
                type="button"
                onClick={() => setPrintZReportData(null)} 
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg text-xs cursor-pointer border border-slate-700 flex items-center gap-1"
                title="إغلاق (Esc)"
              >
                <X className="w-3.5 h-3.5" />
                <span>إغلاق</span>
              </button>
            </div>
          </div>
          <PrintableZReport 
            record={printZReportData} 
            settings={companySettings}
            onClose={() => setPrintZReportData(null)}
          />
        </div>
      )}

      {/* Embedded print overrides styled to isolate printable invoices completely */}
      <style>{`
        @media print {
          body {
            background: #ffffff !important;
            color: #000000 !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          body * {
            visibility: hidden;
          }
          #printable-invoice-container, #printable-invoice-container *,
          #printable-zreport-container, #printable-zreport-container * {
            visibility: visible;
          }
          #printable-invoice-container, #printable-zreport-container {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            display: block !important;
            overflow: visible !important;
          }
          .no-print, .no-print * {
            display: none !important;
            visibility: hidden !important;
          }
          @page {
            margin: 3mm;
          }
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            height: auto !important;
            overflow: visible !important;
          }
        }
      `}</style>
    </div>
  );
}

// ==========================================
// REAL COMPLIANT WINDOWS PRINTABLE INVOICE RECEIPT TEMPLATE WITH MULTI-CURRENCY & ZATCA QR
// ==========================================
function PrintableZatcaQr({ payload, size = 110 }: { payload: string; size?: number }) {
  const [url, setUrl] = useState<string>('');
  useEffect(() => {
    let mounted = true;
    generateQrDataUrl(payload, { width: size * 2, margin: 1 }).then(u => {
      if (mounted) setUrl(u);
    });
    return () => { mounted = false; };
  }, [payload, size]);

  if (!url) {
    return <div style={{ width: size, height: size }} className="border border-black bg-gray-100 flex items-center justify-center mx-auto text-[9px] text-gray-500">جاري تجهيز الرمز...</div>;
  }
  return (
    <img 
      src={url} 
      alt="ZATCA Fatoora QR Code" 
      style={{ width: size, height: size }} 
      className="mx-auto block object-contain border border-black p-0.5 bg-white"
    />
  );
}

function PrintableInvoice({ 
  invoice, 
  settings, 
  printer, 
  currencyCode,
  templateOverride
}: { 
  invoice: Invoice; 
  settings: CompanySettings; 
  printer?: AppPrinter; 
  currencyCode?: string; 
  templateOverride?: 'thermal80' | 'A4';
}) {
  const invoiceNum = invoice.invoiceNumber || invoice.number || 'INV-0000';
  const subTotalAmount = invoice.subtotal !== undefined ? invoice.subtotal : (invoice.total / 1.15);
  const taxAmount = invoice.tax !== undefined ? invoice.tax : (invoice.total - subTotalAmount);
  const isA4 = templateOverride ? (templateOverride === 'A4') : (printer?.template === 'A4');

  // Multi-Currency configuration resolution
  const baseCurrencyCode = settings.multiCurrency?.baseCurrency || 'SAR';
  const currenciesList = settings.multiCurrency?.currencies || [];
  const activeCurrency = currenciesList.find(c => c.code === (currencyCode || invoice.currency || baseCurrencyCode)) 
    || { code: 'SAR', nameAr: 'ريال سعودي', symbol: '﷼', exchangeRate: 1.0, isBase: true, isEnabled: true };
  
  const isForeign = activeCurrency.code !== baseCurrencyCode;
  const rate = activeCurrency.exchangeRate || 1.0;
  const convert = (val: number) => (isForeign && rate > 0 ? val / rate : val);
  const currSym = activeCurrency.symbol;
  const isSar = activeCurrency.code === 'SAR' || activeCurrency.symbol === 'ر.س' || activeCurrency.symbol === '⃁' || activeCurrency.symbol === '﷼';
  const renderInvCurr = (className = "w-3 h-3 inline-block align-middle") => {
    if (isSar) {
      return <SaudiRiyalSymbol className={className} />;
    }
    return <span>{currSym}</span>;
  };

  // ZATCA Phase 1 TLV Base64 payload
  const zatcaQrPayload = generateZatcaTlvBase64({
    sellerName: settings.companyName,
    vatNumber: settings.vatNumber,
    timestamp: invoice.date || new Date().toISOString(),
    totalWithVat: invoice.total,
    vatAmount: taxAmount
  });

  if (isA4) {
    // Printable elegant A4 Invoice
    return (
      <div className="bg-white text-black p-8 w-full max-w-[800px] mx-auto border border-gray-300 font-sans text-sm text-right shadow-lg" dir="rtl">
        {/* Header */}
        <div className="flex justify-between items-center border-b-2 border-black pb-4 mb-4 gap-4">
          <div className="flex items-center gap-4">
            {settings.logoUrl && (
              <img 
                src={settings.logoUrl} 
                alt={settings.companyName || 'شعار الشركة'} 
                className="h-16 w-auto max-w-[120px] object-contain rounded p-0.5 border border-gray-300 bg-white"
                referrerPolicy="no-referrer"
              />
            )}
            <div className="space-y-1">
              <h2 className="text-xl font-black">{settings.companyName}</h2>
              <p className="text-xs text-gray-600">{settings.address}</p>
              <p className="text-xs text-gray-600">الهاتف: {settings.phone}</p>
              <p className="text-xs text-gray-600">الرقم الضريبي VAT: {settings.vatNumber}</p>
            </div>
          </div>
          <div className="text-left" dir="ltr">
            <h2 className="text-lg font-bold">INVOICE / فاتورة ضريبية</h2>
            <p className="text-xs">Date: {invoice.date}</p>
            <p className="text-xs">Invoice No: {invoiceNum}</p>
            {isForeign && (
              <p className="text-xs font-bold text-gray-800">
                Currency: {activeCurrency.code} ({currSym})
              </p>
            )}
          </div>
        </div>

        <div className="text-center font-bold text-lg border border-black py-1.5 my-4 w-1/3 mx-auto rounded-full bg-gray-50">
          فاتورة ضريبية مبسطة
        </div>

        {/* Foreign Currency Conversion Notification Banner */}
        {isForeign && (
          <div className="border border-black bg-gray-50 rounded-lg p-2.5 mb-4 text-xs font-bold flex justify-between items-center">
            <span>العملة المعتمدة للفاتورة: {activeCurrency.nameAr} ({activeCurrency.code})</span>
            <span className="font-mono">سعر الصرف: 1 {activeCurrency.code} = {rate} ﷼</span>
            <span className="font-mono">المعادل بالريال: <span className="inline-flex items-center gap-0.5">{invoice.total.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span></span>
          </div>
        )}

        {/* Customer details */}
        <div className="border border-black rounded-lg p-4 mb-6 grid grid-cols-2 gap-4">
          <div>
            <span className="font-bold text-xs text-gray-500 block mb-1">العميل / Customer</span>
            <span className="font-black text-sm">{invoice.customerName || 'عميل نقدي'}</span>
          </div>
          <div className="text-left" dir="ltr">
            <span className="font-bold text-xs text-gray-500 block mb-1">Payment Method / طريقة الدفع</span>
            <span className="font-black text-sm">{invoice.paymentMethod === 'cash' ? 'CASH / نقدي' : 'CARD / شبكة'}</span>
          </div>
        </div>

        {/* Items */}
        <table className="w-full border-collapse border border-black text-center mb-6">
          <thead className="bg-gray-100">
            <tr className="border-b border-black">
              <th className="border-r border-black p-2.5">م</th>
              <th className="border-r border-black p-2.5 text-right pr-4">الصنف / Item</th>
              <th className="border-r border-black p-2.5">السعر ({renderInvCurr("w-3 h-3 inline-block")})</th>
              <th className="border-r border-black p-2.5">الكمية / Qty</th>
              <th className="border-r border-black p-2.5">الضريبة ({renderInvCurr("w-3 h-3 inline-block")})</th>
              <th className="p-2.5">المجموع شامل الضريبة ({renderInvCurr("w-3 h-3 inline-block")})</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item, idx) => (
              <tr key={idx} className="border-b border-gray-300">
                <td className="border-r border-black p-2.5 font-mono">{idx + 1}</td>
                <td className="border-r border-black p-2.5 text-right pr-4 font-bold">{item.name}</td>
                <td className="border-r border-black p-2.5 font-mono">{convert(item.price || 0).toFixed(2)}</td>
                <td className="border-r border-black p-2.5 font-mono">{item.qty}</td>
                <td className="border-r border-black p-2.5 font-mono">{convert(item.tax || (item.total - (item.total / 1.15))).toFixed(2)}</td>
                <td className="p-2.5 font-mono font-bold inline-flex items-center gap-1">{convert(item.total || 0).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Total Summary and ZATCA QR Box */}
        <div className="flex justify-between items-end gap-6 mb-6">
          <div className="border border-black p-3 rounded-lg w-1/2 space-y-1 text-xs">
            <div className="flex justify-between"><span>الرقم الضريبى للمنشأة:</span> <span className="font-mono font-bold">{settings.vatNumber}</span></div>
            <div className="flex justify-between"><span>رقم سجل تجاري:</span> <span className="font-mono">{settings.grNumber || '١٠١٠٥٤٧٧٨٢'}</span></div>
            <div className="flex justify-between"><span>رقم رخصة البلدية:</span> <span className="font-mono">{settings.moNumber || '٤٤٠٩٦٧٣٣'}</span></div>
          </div>

          <div className="w-1/2 border border-black rounded-lg p-4 space-y-2">
            {invoice.discount && invoice.discount > 0 ? (
              <>
                <div className="flex justify-between text-xs">
                  <span>المجموع قبل الخصم:</span> 
                  <span className="font-mono font-bold inline-flex items-center gap-1">{convert(invoice.rawSubtotal || (subTotalAmount + invoice.discount)).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
                </div>
                <div className="flex justify-between text-xs text-amber-800 font-bold">
                  <span>الخصم ({invoice.discountType === 'percent' ? `${invoice.discountValue}%` : (invoice.discountScope === 'total' ? `مبلغ ثابت ${invoice.discountValue || invoice.discount} ﷼ من الإجمالي` : `مبلغ ثابت ${invoice.discountValue || invoice.discount} ﷼`)}):</span> 
                  <span className="font-mono font-black inline-flex items-center gap-1">- {convert(invoice.discount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span>المبلغ الخاضع للضريبة:</span> 
                  <span className="font-mono font-bold inline-flex items-center gap-1">{convert(subTotalAmount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
                </div>
              </>
            ) : (
              <div className="flex justify-between text-xs">
                <span>الإجمالي الخاضع للضريبة:</span> 
                <span className="font-mono font-bold inline-flex items-center gap-1">{convert(subTotalAmount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
              </div>
            )}
            <div className="flex justify-between text-xs text-rose-600">
              <span>ضريبة القيمة المضافة ({settings.taxRate}%):</span> 
              <span className="font-mono font-bold inline-flex items-center gap-1">{convert(taxAmount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
            </div>
            <div className="flex justify-between font-black text-base border-t border-dashed border-gray-400 pt-2 text-cyan-700">
              <span>الإجمالي المستحق شامل الضريبة:</span> 
              <span className="font-mono inline-flex items-center gap-1">{convert(invoice.total).toFixed(2)} {renderInvCurr("w-4 h-4 inline-block")}</span>
            </div>
            {invoice.paymentMethod === 'cash' && invoice.paidAmount !== undefined && (
              <div className="border-t border-dotted border-gray-400 pt-1.5 mt-1 space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>المبلغ المدفوع نقداً:</span>
                  <span className="font-mono font-bold inline-flex items-center gap-1">{convert(invoice.paidAmount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
                </div>
                <div className="flex justify-between font-black text-emerald-800">
                  <span>المتبقي (الباقي للعميل):</span>
                  <span className="font-mono font-black inline-flex items-center gap-1">{convert(invoice.changeAmount || 0).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
                </div>
                {invoice.isQuickPay && (
                  <div className="text-[10px] text-gray-500 text-center font-bold">
                    (دفع نقدي سريع - Quick Pay)
                  </div>
                )}
              </div>
            )}
            {isForeign && (
              <div className="flex justify-between text-xs text-gray-500 border-t pt-1">
                <span>ما يعادله بالريال السعودي:</span>
                <span className="font-mono inline-flex items-center gap-0.5">{invoice.total.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span>
              </div>
            )}
          </div>
        </div>

        {/* Official ZATCA Phase 1 QR Code Block */}
        <div className="border border-black rounded-xl p-4 bg-gray-50 flex items-center justify-between mb-6">
          <div className="space-y-1 text-xs">
            <h4 className="font-black text-sm">رمز الاستجابة السريعة لهيئة الزكاة والضريبة والجمارك (ZATCA)</h4>
            <p className="text-gray-600">مطابق لمتطلبات الفوترة الإلكترونية - المرحلة الأولى (فاتورة ضريبية مبسطة)</p>
            <p className="text-[11px] text-gray-500 font-mono">TLV Base64 Encoded (Tags 1 to 5)</p>
          </div>
          <PrintableZatcaQr payload={zatcaQrPayload} size={110} />
        </div>

        {/* Footer info */}
        <div className="text-center text-xs text-gray-500 border-t border-gray-300 pt-4 space-y-1">
          <p className="font-bold text-gray-800">{settings.footer}</p>
          <p>فاتورة ضريبية مبسطة معتمدة من الهيئة العامة للزكاة والضريبة والجمارك</p>
        </div>
      </div>
    );
  } else {
    // Printable dynamic 80mm Thermal Receipt (Xprinter / POS Windows Printers)
    return (
      <div className="bg-white text-black p-4 w-[290px] mx-auto border border-gray-300 font-sans text-xs text-right shadow-md" dir="rtl">
        <div className="text-center space-y-1 border-b-2 border-dashed border-gray-400 pb-3 mb-3">
          {settings.logoUrl && (
            <div className="flex justify-center mb-1.5">
              <img 
                src={settings.logoUrl} 
                alt={settings.companyName || 'شعار الشركة'} 
                className="h-12 w-auto max-w-[100px] object-contain mx-auto"
                referrerPolicy="no-referrer"
              />
            </div>
          )}
          <span className="font-bold border border-black px-2 py-0.5 rounded text-[10px]">فاتورة ضريبية مبسطة</span>
          <h2 className="font-black text-sm mt-1">{settings.companyName}</h2>
          <p className="text-[10px] text-gray-700">{settings.address}</p>
          <p className="font-mono text-[10px]">الرقم الضريبي: {settings.vatNumber}</p>
          <p className="text-[10px]">الهاتف: {settings.phone}</p>
        </div>

        <div className="space-y-1 mb-3 font-bold border-b border-gray-200 pb-2">
          <div className="flex justify-between"><span>رقم الفاتورة:</span> <span className="font-mono text-xs">{invoiceNum}</span></div>
          <div className="flex justify-between"><span>التاريخ والوقت:</span> <span className="font-mono">{invoice.date}</span></div>
          <div className="flex justify-between"><span>طريقة الدفع:</span> <span>{invoice.paymentMethod === 'cash' ? 'نقدي (CASH)' : 'شبكة (CARD)'}</span></div>
          <div className="flex justify-between"><span>العميل:</span> <span>{invoice.customerName || 'نقدي'}</span></div>
          {isForeign && (
            <div className="flex justify-between text-black border-t border-dashed pt-1">
              <span>العملة:</span> 
              <span className="font-mono">{activeCurrency.code} ({currSym})</span>
            </div>
          )}
        </div>

        {/* Table */}
        <table className="w-full text-center mb-3">
          <thead>
            <tr className="border-b border-black text-[10px] font-bold">
              <th className="text-right py-1">الصنف</th>
              <th className="py-1">السعر</th>
              <th className="py-1">الكمية</th>
              <th className="text-left py-1">المجموع ({renderInvCurr("w-2.5 h-2.5 inline-block")})</th>
            </tr>
          </thead>
          <tbody className="font-bold divide-y divide-gray-200">
            {invoice.items.map((item, idx) => (
              <tr key={idx} className="text-[11px]">
                <td className="text-right py-1.5 font-bold">{item.name}</td>
                <td className="py-1.5 font-mono">{convert(item.price).toFixed(2)}</td>
                <td className="py-1.5 font-mono">{item.qty}</td>
                <td className="text-left py-1.5 font-mono">{convert(item.total).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div className="border-t border-black pt-2 space-y-1 font-bold mb-4">
          {invoice.discount && invoice.discount > 0 ? (
            <>
              <div className="flex justify-between">
                <span>المجموع قبل الخصم:</span> 
                <span className="font-mono inline-flex items-center gap-1">{convert(invoice.rawSubtotal || (subTotalAmount + invoice.discount)).toFixed(2)} {renderInvCurr("w-2.5 h-2.5 inline-block")}</span>
              </div>
              <div className="flex justify-between text-amber-900">
                <span>الخصم ({invoice.discountType === 'percent' ? `${invoice.discountValue}%` : (invoice.discountScope === 'total' ? `مبلغ ثابت ${invoice.discountValue || invoice.discount} ﷼ من الإجمالي` : `مبلغ ثابت ${invoice.discountValue || invoice.discount} ﷼`)}):</span> 
                <span className="font-mono font-black inline-flex items-center gap-1">- {convert(invoice.discount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
              </div>
              <div className="flex justify-between">
                <span>المبلغ الخاضع للضريبة:</span> 
                <span className="font-mono inline-flex items-center gap-1">{convert(subTotalAmount).toFixed(2)} {renderInvCurr("w-2.5 h-2.5 inline-block")}</span>
              </div>
            </>
          ) : (
            <div className="flex justify-between">
              <span>المجموع (الخاضع للضريبة):</span> 
              <span className="font-mono inline-flex items-center gap-1">{convert(subTotalAmount).toFixed(2)} {renderInvCurr("w-2.5 h-2.5 inline-block")}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>الضريبة ({settings.taxRate}%):</span> 
            <span className="font-mono inline-flex items-center gap-1">{convert(taxAmount).toFixed(2)} {renderInvCurr("w-2.5 h-2.5 inline-block")}</span>
          </div>
          <div className="flex justify-between text-xs border-t-2 border-dashed border-black pt-1.5 mt-1 font-black">
            <span>الإجمالي الشامل:</span>
            <span className="font-mono inline-flex items-center gap-1">{convert(invoice.total).toFixed(2)} {renderInvCurr("w-4 h-4 inline-block")}</span>
          </div>
          {invoice.paymentMethod === 'cash' && invoice.paidAmount !== undefined && (
            <div className="border-t border-dotted border-gray-500 pt-1.5 mt-1 space-y-0.5 text-[11px]">
              <div className="flex justify-between">
                <span>المدفوع نقداً:</span>
                <span className="font-mono font-bold inline-flex items-center gap-1">{convert(invoice.paidAmount).toFixed(2)} {renderInvCurr("w-3 h-3 inline-block")}</span>
              </div>
              <div className="flex justify-between font-black">
                <span>الباقي للعميل:</span>
                <span className="font-mono inline-flex items-center gap-1">{convert(invoice.changeAmount || 0).toFixed(2)} {renderInvCurr("w-2.5 h-2.5 inline-block")}</span>
              </div>
              {invoice.isQuickPay && (
                <div className="text-[9px] text-gray-600 text-center font-bold">
                  * دفع كاش سريع (Quick Pay) *
                </div>
              )}
            </div>
          )}
          {isForeign && (
            <div className="flex justify-between text-[10px] text-gray-700 border-t border-dotted pt-1">
              <span>المعادل بالريال:</span>
              <span className="font-mono font-bold inline-flex items-center gap-0.5">{invoice.total.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span>
            </div>
          )}
        </div>

        {/* Official Real ZATCA Phase 1 QR Code */}
        <div className="flex flex-col items-center justify-center space-y-1.5 pt-2 border-t border-dashed border-gray-400">
          <p className="text-[9px] font-bold text-center">{settings.footer}</p>
          
          <PrintableZatcaQr payload={zatcaQrPayload} size={115} />
          
          <p className="text-[8px] text-gray-600 text-center font-bold">فاتورة ضريبية مبسطة معتمدة (هيئة الزكاة)</p>
          <p className="text-[7px] text-gray-400 text-center font-mono">ZATCA FATOORA PHASE 1</p>
        </div>
      </div>
    );
  }
}

// ==========================================
// REAL WINDOWS PRINTABLE Z-REPORT TEMPLATE
// ==========================================
function PrintableZReport({ 
  record, 
  settings, 
  onClose 
}: { 
  record: any; 
  settings: CompanySettings; 
  onClose: () => void; 
}) {
  return (
    <div className="bg-white text-black p-4 w-[300px] mx-auto border border-gray-300 font-sans text-xs text-right shadow-2xl relative" dir="rtl">
      <div className="text-center space-y-1 border-b-2 border-dashed border-gray-400 pb-3 mb-3">
        {settings.logoUrl && (
          <div className="flex justify-center mb-1.5">
            <img 
              src={settings.logoUrl} 
              alt={settings.companyName || 'شعار الشركة'} 
              className="h-12 w-auto max-w-[100px] object-contain mx-auto"
              referrerPolicy="no-referrer"
            />
          </div>
        )}
        <span className="font-black border border-black px-2 py-0.5 rounded text-[10px] bg-gray-100">
          تقرير الإقفال النهائي للوردية (Z-REPORT)
        </span>
        <h2 className="font-black text-sm mt-1">{settings.companyName}</h2>
        <p className="text-[10px] text-gray-700">{settings.address}</p>
        <p className="font-mono text-[10px]">الرقم الضريبي: {settings.vatNumber}</p>
      </div>

      <div className="space-y-1 mb-3 font-bold border-b border-gray-200 pb-2 text-[11px]">
        <div className="flex justify-between"><span>رقم التقرير:</span> <span className="font-mono">{record.reportNumber}</span></div>
        <div className="flex justify-between"><span>نقطة البيع:</span> <span className="font-mono">{record.posTerminalId}</span></div>
        <div className="flex justify-between"><span>الكاشير المسؤول:</span> <span>{record.cashierName}</span></div>
        <div className="flex justify-between"><span>تاريخ الإقفال:</span> <span className="font-mono text-[10px]">{record.shiftEnd || record.closedAt}</span></div>
        <div className="flex justify-between"><span>إجمالي الفواتير:</span> <span className="font-mono">{record.invoicesCount} فاتورة</span></div>
      </div>

      <div className="space-y-1.5 font-bold mb-3 border-b border-gray-200 pb-2 text-[11px]">
        <div className="flex justify-between"><span>مبيعات نقدي (CASH):</span> <span className="font-mono">{record.totalCash.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span></div>
        <div className="flex justify-between"><span>مبيعات شبكة (CARD):</span> <span className="font-mono">{record.totalCard.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span></div>
        <div className="flex justify-between text-gray-700"><span>المجموع غير شامل:</span> <span className="font-mono">{record.subtotal.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span></div>
        <div className="flex justify-between text-rose-600"><span>الضريبة (15%):</span> <span className="font-mono">{record.totalVat.toFixed(2)} <SaudiRiyalSymbol className="w-3 h-3 inline-block align-middle" /></span></div>
        <div className="flex justify-between text-xs border-t-2 border-black pt-1.5 font-black">
          <span>الإجمالي الشامل النهائي:</span>
          <span className="font-mono">{record.grandTotal.toFixed(2)} <SaudiRiyalSymbol className="w-3.5 h-3.5 inline-block align-middle" /></span>
        </div>
      </div>

      {/* ZATCA Audit QR Code */}
      <div className="flex flex-col items-center justify-center space-y-1.5 pt-2 border-t border-dashed border-gray-400">
        <p className="text-[9px] font-bold text-center">رمز التدقيق المالي والإقفال المعتمد</p>
        <PrintableZatcaQr payload={record.base64Payload} size={115} />
        <p className="text-[8px] text-gray-500 text-center font-mono">ZATCA AUDIT SIGNATURE VERIFIED</p>
      </div>

      <div className="mt-4 pt-3 border-t border-gray-300 grid grid-cols-2 gap-2 text-[9px] text-center">
        <div>
          <p className="font-bold">توقيع الكاشير</p>
          <div className="border-b border-gray-400 mt-4"></div>
        </div>
        <div>
          <p className="font-bold">اعتماد المشرف</p>
          <div className="border-b border-gray-400 mt-4"></div>
        </div>
      </div>
    </div>
  );
}