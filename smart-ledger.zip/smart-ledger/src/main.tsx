import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/inter/latin-400.css';
import '@fontsource/inter/latin-500.css';
import '@fontsource/inter/latin-600.css';
import '@fontsource/inter/latin-700.css';
import '@fontsource/inter/latin-900.css';
import '@fontsource/jetbrains-mono/latin-400.css';
import '@fontsource/jetbrains-mono/latin-700.css';
import '@fontsource/jetbrains-mono/latin-800.css';
import App from './App.tsx';
import UpdateBanner from './components/UpdateBanner.tsx';
import { hydrate } from './storage/persistence';
import './index.css';

// صور المنتجات القادمة من الإنترنت: إن لم يوجد اتصال نعرض بديلاً بدل صورة مكسورة
const PLACEHOLDER =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#e2e8f0"/>' +
      '<path d="M60 130l30-36 22 26 16-18 22 28z" fill="#94a3b8"/><circle cx="76" cy="76" r="12" fill="#94a3b8"/></svg>'
  );
window.addEventListener(
  'error',
  (e) => {
    const t = e.target;
    if (t instanceof HTMLImageElement && t.dataset.fallback !== '1') {
      t.dataset.fallback = '1';
      t.src = PLACEHOLDER;
    }
  },
  true
);

const root = createRoot(document.getElementById('root')!);

async function boot() {
  try {
    await hydrate(); // نحمّل البيانات من SQLite قبل رسم الواجهة
  } catch (err) {
    console.error(err);
    root.render(
      <div dir="rtl" style={{ padding: 40, fontFamily: 'sans-serif', color: '#b91c1c' }}>
        <h2>تعذر تحميل البيانات</h2>
        <p>لم يتم تشغيل البرنامج حمايةً لبياناتك من الكتابة فوقها. أغلق البرنامج وأعد فتحه، وإن استمرت المشكلة استعد آخر نسخة احتياطية من مجلد backups.</p>
        <pre style={{ direction: 'ltr', whiteSpace: 'pre-wrap' }}>{String((err as Error)?.message ?? err)}</pre>
      </div>
    );
    return;
  }
  root.render(
    <StrictMode>
      <App />
      <UpdateBanner />
    </StrictMode>
  );
}

void boot();
